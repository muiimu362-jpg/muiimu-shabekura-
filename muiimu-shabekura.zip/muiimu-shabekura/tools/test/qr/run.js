const fs=require('fs'); const src=fs.readFileSync('qr.js','utf8'); const QR=new Function(src+'; return QR;')();
const tests=["https://muiimu-shabekura.muiimu362.workers.dev/","https://muiimu-shabekura.muiimu362.workers.dev/?web=1","A","むいいむ しゃべくら へようこそ","https://example.com/"+"x".repeat(150),"https://muiimu-shabekura.workers.dev/"+"y".repeat(100)];
const out=tests.map(t=>({t, m:QR.make(t)}));
fs.writeFileSync('m.json', JSON.stringify(out));
console.log(out.map(o=>o.m.length).join(","));
