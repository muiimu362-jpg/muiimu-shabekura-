import { Room } from "./idx.mjs";
class WS { constructor(){this.readyState=1;this.sent=[];this.att=null;}
 send(m){this.sent.push(m)} close(c){this.readyState=3;this.closed=c}
 serializeAttachment(a){this.att=a} deserializeAttachment(){return this.att} }
let fails=0; const ok=(c,m)=>{ if(!c){fails++; console.log("FAIL:",m);} };
const sockets=[]; const store=new Map();
const ctx={ getWebSockets:()=>sockets, acceptWebSocket:(w)=>sockets.push(w), storage:{get:async k=>store.get(k), put:async(k,v)=>store.set(k,v)} };
globalThis.WebSocketPair=function(){ return {0:new WS(),1:new WS()}; }; globalThis.Response=class{constructor(b,o){}};
const r=new Room(ctx,{}); 
const join=async(n,k="")=>{ await r.fetch({url:`https://x/ws?room=AAAAAA&name=${n}&mc=${n}&dev=${k||("D-"+n)}`}); return sockets.at(-1); };
const bin=(w)=>w.sent.filter(x=>typeof x!=="string").length;
const talk=async(from,to)=>{ const b=bin(to); await r.webSocketMessage(from,new Uint8Array([1,2]).buffer); return bin(to)>b; };
const pos=(p)=>r.webSocketMessage(host, JSON.stringify({t:"pos",p}));
const host=await join("gopura777","KEY"), sub=await join("saradayou509");
// 1. /connect 前 → ふつうの通話
ok(await talk(sub,host) && await talk(host,sub), "connect前はふつうの通話");
// 2. /connect したけど、2人ともワールドで見つからない（名前違いなど）→ ふつうの通話のまま
await pos({});
ok(await talk(sub,host) && await talk(host,sub), "ワールド外どうしはふつうの通話");
// 3. 2人ともワールドの中、近い → 聞こえる
await pos({gopura777:{x:0,y:0,z:0,d:0}, saradayou509:{x:3,y:0,z:0,d:0}});
ok(await talk(sub,host) && await talk(host,sub), "ワールド内で近い→聞こえる");
// 4. 遠い → 聞こえない
await pos({gopura777:{x:0,y:0,z:0,d:0}, saradayou509:{x:100,y:0,z:0,d:0}});
ok(!(await talk(sub,host)) && !(await talk(host,sub)), "ワールド内で遠い→聞こえない");
// 5. サブがマイクラから落ちた → 中と外は聞こえない
await pos({gopura777:{x:0,y:0,z:0,d:0}});
ok(!(await talk(sub,host)), "中と外は聞こえない");
// 6. 両方ワールドから出た → ふつうの通話に戻る
await pos({});
ok(await talk(sub,host) && await talk(host,sub), "両方外→ふつうの通話に戻る");
// 7. 通話を抜ける → 誰とも話さない、戻ると話せる
await r.webSocketMessage(sub, JSON.stringify({t:"optout",on:true}));
ok(!(await talk(sub,host)) && !(await talk(host,sub)), "抜けたら無音");
await r.webSocketMessage(sub, JSON.stringify({t:"optout",on:false}));
ok(await talk(sub,host), "戻ったら聞こえる");
// 8. マイクラとの接続が切れた（mc off）→ みんなそのまま（遠い人は遠いまま、近い人は近いまま）
await pos({gopura777:{x:0,y:0,z:0,d:0}, saradayou509:{x:100,y:0,z:0,d:0}});
await r.webSocketMessage(host, JSON.stringify({t:"mc",on:false}));
ok(!(await talk(sub,host)), "マイクラ切断→そのまま（100ブロック離れた人は聞こえないまま）");
await pos({gopura777:{x:0,y:0,z:0,d:0}, saradayou509:{x:2,y:0,z:0,d:0}});
await r.webSocketMessage(host, JSON.stringify({t:"mc",on:false}));
ok(await talk(sub,host), "マイクラ切断→そのまま（近い人は聞こえるまま）");
// 9. 番号: 運営=1, サブ=2
await pos({gopura777:{x:0,y:0,z:0,d:0}, saradayou509:{x:1,y:0,z:0,d:0}});
ok(r.slots.get("gopura777")===1 && r.slots.get("saradayou509")===2, "番号 1と2");
console.log(fails===0 ? "ALL OK" : "FAILED "+fails);
