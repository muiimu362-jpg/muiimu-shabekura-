package com.muiimu.shabekura

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class MainActivity : Activity() {

    companion object {
        /** みんなが入る「近接VC待機所」（決まったコード） */
        const val LOBBY = "MUIIMU"
        const val APK_URL = "https://github.com/muiimu362-jpg/muiimu-shabekura-/releases/latest/download/MuiimuShabekura.apk"
        const val ROOMS = 20
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var etMc: EditText
    private lateinit var etDisplayName: EditText
    private lateinit var namePanel: LinearLayout
    private lateinit var setupPanel: LinearLayout
    private lateinit var joinForm: LinearLayout
    private lateinit var tvBridgeToggle: TextView
    private var bridgeChoice = false
    private lateinit var callPanel: LinearLayout
    private lateinit var tvRoom: TextView
    private lateinit var tvMc: TextView
    private lateinit var llChannels: LinearLayout
    private lateinit var tvStatus: TextView
    private lateinit var btnCopyCmd: Button
    private lateinit var btnMute: Button
    private lateinit var btnDeafen: Button
    private lateinit var btnOptOut: Button

    private val listener: () -> Unit = { render() }
    private var pendingStart: (() -> Unit)? = null
    private var linkCode: String? = null   // 招待リンクで別の部屋コードが来たとき

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("shabekura", Context.MODE_PRIVATE)

        etMc = findViewById(R.id.etMc)
        etDisplayName = findViewById(R.id.etDisplayName)
        namePanel = findViewById(R.id.namePanel)
        setupPanel = findViewById(R.id.setupPanel)
        joinForm = findViewById(R.id.joinForm)
        tvBridgeToggle = findViewById(R.id.tvBridgeToggle)
        callPanel = findViewById(R.id.callPanel)
        tvRoom = findViewById(R.id.tvRoom)
        tvMc = findViewById(R.id.tvMc)
        llChannels = findViewById(R.id.llChannels)
        tvStatus = findViewById(R.id.tvStatus)
        btnCopyCmd = findViewById(R.id.btnCopyCmd)
        btnMute = findViewById(R.id.btnMute)
        btnDeafen = findViewById(R.id.btnDeafen)
        btnOptOut = findViewById(R.id.btnOptOut)

        etMc.setText(prefs.getString("mc", ""))
        etDisplayName.setText(prefs.getString("displayName", ""))
        // 一番最初は「名前を決めてください」
        findViewById<Button>(R.id.btnSetName).setOnClickListener {
            val n = etDisplayName.text.toString().trim()
            if (n.isEmpty()) { toast("名前を入れてね"); return@setOnClickListener }
            prefs.edit().putString("displayName", n).apply()
            render()
        }
        findViewById<TextView>(R.id.tvMyName).setOnClickListener {
            // 名前を変える
            prefs.edit().remove("displayName").apply()
            render()
        }

        findViewById<TextView>(R.id.tvVersion).text = "バージョン " + BuildConfig.VERSION_NAME
        if (VoiceService.serverBase().isEmpty()) {
            findViewById<View>(R.id.serverWarn).visibility = View.VISIBLE
        }

        // 近接VC待機所をタップすると、名前とオーナーの入力欄が出る
        findViewById<TextView>(R.id.chLobby).setOnClickListener {
            joinForm.visibility = if (joinForm.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            if (joinForm.visibility == View.VISIBLE) etMc.requestFocus()
        }
        tvBridgeToggle.setOnClickListener { bridgeChoice = !bridgeChoice; updateOwnerUi() }
        updateOwnerUi()
        buildRoomsPreview()

        findViewById<Button>(R.id.btnJoin).setOnClickListener { join() }
        // 右上の「オーナーを渡す」
        findViewById<Button>(R.id.btnGiveOwner).setOnClickListener { chooseNewOwner() }
        btnCopyCmd.setOnClickListener {
            copy(McBridge.COMMAND)
            Toast.makeText(this, "コピーしたよ！マイクラのチャットに貼り付けて送信してね", Toast.LENGTH_LONG).show()
        }
        // アプリをシェア（LINE や Discord などに送れる）
        findViewById<Button>(R.id.btnInvite).setOnClickListener {
            val base = VoiceService.serverBase()
            val text = "むいいむ通話に来てね！\n" +
                "アプリを開いて名前を決めたら「近接VC待機所」をタップ →「入る」だけ！（マイクラの名前を入れると近接ボイスになるよ）\n" +
                "・ここを押すとアプリが開くよ（入ってない人はダウンロードされる）\n$base/\n" +
                "・アプリのダウンロード: $APK_URL"
            try {
                val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                startActivity(Intent.createChooser(send, "アプリをシェア"))
            } catch (e: Exception) {
                copy(text)
                Toast.makeText(this, "シェアできなかったので、招待メッセージをコピーしたよ", Toast.LENGTH_LONG).show()
            }
        }
        btnMute.setOnClickListener { VoiceService.instance?.setMuted(!AppState.muted) }
        btnDeafen.setOnClickListener { VoiceService.instance?.setDeafened(!AppState.deafened) }
        btnOptOut.setOnClickListener { VoiceService.instance?.setOptOut(!AppState.optOut) }

        findViewById<Button>(R.id.btnLeave).setOnClickListener { VoiceService.stop(this) }

        askPermissions()
        handleLink(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleLink(intent)
    }

    /** 招待リンク（shabekura://join?room=XXXXXX）から開かれたとき */
    private fun handleLink(i: Intent?) {
        val data = i?.data ?: return
        if (data.scheme != "shabekura") return
        val code = data.getQueryParameter("room")?.trim()?.uppercase().orEmpty()
        linkCode = if (Regex("^[A-Z0-9]{6}$").matches(code) && code != LOBBY) code else null
        if (AppState.running) return
        joinForm.visibility = View.VISIBLE
        toast("「近接VC待機所」の「入る」を押してね")
    }

    override fun onResume() {
        super.onResume()
        AppState.addListener(listener)
        render()
    }

    override fun onPause() {
        AppState.removeListener(listener)
        super.onPause()
    }

    private fun askPermissions() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val start = pendingStart
        pendingStart = null
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            start?.invoke()
        } else if (start != null) {
            toast("マイクの許可がないと通話できないよ（設定 → アプリ → 権限）")
        }
    }

    /** マイクの許可を確認してから通話を始める */
    private fun withMic(action: () -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            action()
        } else {
            pendingStart = action
            askPermissions()
        }
    }

    /** みんなに表示される名前（一番最初に決めたもの） */
    private fun myName(): String? {
        val name = prefs.getString("displayName", "").orEmpty().trim()
        if (name.isEmpty()) {
            render(); toast("先に名前を決めてね"); return null
        }
        return name
    }

    /** このスマホの端末ID（オーナーを覚えるのに使う。アプリを消さない限り変わらない） */
    private fun deviceId(): String {
        var d = prefs.getString("dev", "").orEmpty()
        if (d.isEmpty()) {
            d = java.util.UUID.randomUUID().toString()
            prefs.edit().putString("dev", d).apply()
        }
        return d
    }

    private fun join() {
        val name = myName() ?: return
        val mc = etMc.text.toString().trim()
        prefs.edit().putString("mc", mc).apply()
        if (bridgeChoice && mc.isEmpty()) {
            toast("配信用（連携だけ）は、マイクラの名前を入れてね"); return
        }
        val code = linkCode ?: LOBBY
        withMic { VoiceService.start(this, code, name, mc, deviceId(), bridgeChoice) }
    }

    /** オーナーを渡す相手を選ぶ（アプリやブラウザで入っている人の一覧） */
    private fun chooseNewOwner() {
        val others = AppState.members.filter { it.name != AppState.myName }
        if (others.isEmpty()) {
            toast("ほかに入っている人がいないよ"); return
        }
        val names = others.map { it.name }.toTypedArray<CharSequence>()
        android.app.AlertDialog.Builder(this)
            .setTitle("👑 だれにオーナーを渡す？")
            .setItems(names) { _, which ->
                val target = others[which]
                android.app.AlertDialog.Builder(this)
                    .setTitle("オーナーを渡す")
                    .setMessage("「${target.name}」にオーナーを渡すよ。\n渡したあとは、自分はふつうのメンバーになるよ。いい？")
                    .setPositiveButton("渡す") { _, _ -> VoiceService.instance?.giveOwner(target.id) }
                    .setNegativeButton("やめる", null)
                    .show()
            }
            .setNegativeButton("やめる", null)
            .show()
    }

    private fun updateOwnerUi() {
        tvBridgeToggle.text = (if (bridgeChoice) "☑" else "☐") + " 配信用：このスマホは連携だけ（オーナーだけ・声は別のスマホ）"
    }

    /** 入る前の画面に、部屋1〜20を並べておく（Discord と同じ見た目） */
    private fun buildRoomsPreview() {
        val box = findViewById<LinearLayout>(R.id.llRoomsPreview)
        box.removeAllViews()
        for (room in 1..ROOMS) {
            val t = TextView(this)
            t.text = "🔊  🎧▮部屋$room"
            t.textSize = 15f
            t.setPadding(dp(8), dp(7), dp(8), dp(7))
            t.setTextColor(Color.parseColor("#80848E"))
            box.addView(t)
        }
    }

    private fun render() {
        val s = AppState
        val hasName = prefs.getString("displayName", "").orEmpty().isNotBlank()
        namePanel.visibility = if (!s.running && !hasName) View.VISIBLE else View.GONE
        setupPanel.visibility = if (s.running || !hasName) View.GONE else View.VISIBLE
        findViewById<TextView>(R.id.tvMyName).text = "👤 " + prefs.getString("displayName", "").orEmpty() + "　（タップで名前を変える）"
        callPanel.visibility = if (s.running) View.VISIBLE else View.GONE
        tvStatus.text = s.status

        if (!s.running) return

        tvRoom.text = "むいいむ通話" + when {
            s.bridgeOnly -> "（連携だけ）"
            s.isHost -> "（オーナー）"
            else -> ""
        }
        btnCopyCmd.visibility = if (s.isHost) View.VISIBLE else View.GONE
        findViewById<Button>(R.id.btnInvite).visibility = if (s.isHost) View.VISIBLE else View.GONE
        findViewById<Button>(R.id.btnGiveOwner).visibility = if (s.isHost && !s.bridgeOnly) View.VISIBLE else View.GONE

        var card = when {
            !s.mcLinked && s.isHost && s.bridgeOpen -> "🟡 マイクラとつながった。位置を取得中…"
            !s.mcLinked && s.isHost -> "⚪ 今は待機所でふつうの通話\n下のボタンでコマンドをコピー → マイクラのチャットに貼って送信すると、ワールドに入った人が部屋に移動するよ"
            !s.mcLinked -> "⚪ 近接VC待機所にいるよ（ふつうの通話）\n運営がマイクラで準備すると、ワールドに入った人から部屋に移動するよ"
            s.optOut -> "⏸ 通話を抜けてるよ（「通話に戻る」で戻れる）"
            s.mySlot > 0 -> "🟢 部屋${s.mySlot} にいるよ：近くの人ほど大きく聞こえる"
            else -> "🟡 近接VC待機所にいるよ：待機所の人どうしでふつうに話せる\nマイクラのワールドに入ると、空いてる部屋に自動で移動するよ"
        }
        if (s.bridgeOnly) {
            card = "🔗 連携だけモード：このスマホはマイクもスピーカーも使っていないよ（配信アプリがマイクを使える）\n" +
                "声は別のスマホで、同じ名前「${s.myName}」・同じマイクラの名前で「入る」してね\n\n" +
                when {
                    s.mcLinked -> "🟢 マイクラと連携中"
                    s.bridgeOpen -> "🟡 マイクラとつながった。位置を取得中…"
                    else -> "⚪ 下のボタンでコマンドをコピー → マイクラのチャットに貼って送信"
                }
        }
        if (s.isHost && s.bridgeInfo.isNotEmpty()) card += "\n\n" + s.bridgeInfo
        tvMc.text = card

        btnMute.text = if (s.muted) "🎤 ミュート解除" else "🎤 ミュート"
        btnDeafen.text = if (s.deafened) "🎧 スピーカー解除" else "🎧 スピーカーミュート"
        btnOptOut.visibility = if (s.mcLinked && !s.bridgeOnly) View.VISIBLE else View.GONE
        val voiceBtns = if (s.bridgeOnly) View.GONE else View.VISIBLE
        btnMute.visibility = voiceBtns
        btnDeafen.visibility = voiceBtns
        btnOptOut.text = if (s.optOut) "通話に戻る" else "通話を抜ける"

        renderChannels()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    /** Discord みたいなボイスチャンネル一覧（近接VC待機所 ＋ 部屋1〜20） */
    private fun renderChannels() {
        val s = AppState
        // 部屋ごとに人を分ける（0 = 近接VC待機所）
        val byRoom = HashMap<Int, MutableList<Member>>()
        for (m in s.members) {
            val room = if (s.mcLinked && m.slot in 1..ROOMS) m.slot else 0
            byRoom.getOrPut(room) { ArrayList() }.add(m)
        }
        val myRoom = s.members.firstOrNull { it.name == s.myName }?.let { if (s.mcLinked && it.slot in 1..ROOMS) it.slot else 0 }

        llChannels.removeAllViews()
        for (room in 0..ROOMS) {
            val title = if (room == 0) "🎤▮近接VC待機所" else "🎧▮部屋$room"
            val people = byRoom[room].orEmpty()
            val head = TextView(this)
            head.text = "🔊  $title" + if (room > 0 && people.isNotEmpty()) "   1/1" else ""
            head.textSize = 15f
            head.setPadding(dp(8), dp(7), dp(8), dp(7))
            val mine = room == myRoom
            head.setTextColor(if (mine || people.isNotEmpty()) Color.parseColor("#F2F3F5") else Color.parseColor("#80848E"))
            if (mine) head.setBackgroundResource(R.drawable.channel_selected)
            llChannels.addView(head)

            for (m in people) {
                val me = m.name == s.myName
                val talking = if (me) s.selfTalking else m.id in s.talking
                val row = TextView(this)
                val sb = StringBuilder()
                sb.append(if (talking) "🟢 " else "⚫ ")
                sb.append(m.name)
                if (m.host) sb.append(" 👑")
                if (me && s.bridgeOnly) {
                    sb.append("（声は別のスマホ）")
                } else if (me) {
                    sb.append("（自分）")
                    if (s.deafened) sb.append("  🎧✕") else if (s.muted) sb.append("  🎤✕")
                    else sb.append("  ").append("■".repeat(s.micLevel)).append("□".repeat(5 - s.micLevel))
                } else if (m.out) {
                    sb.append("  （抜けてる）")
                } else if (s.mcLinked && room > 0) {
                    val d = m.distance
                    sb.append(
                        when {
                            d == null -> ""
                            m.gain <= 0.01f -> "  ${d.roundToInt()}m・聞こえない"
                            else -> "  ${d.roundToInt()}m"
                        }
                    )
                }
                row.text = sb.toString()
                row.textSize = 14f
                row.setPadding(dp(40), dp(3), dp(8), dp(3))
                row.setTextColor(Color.parseColor(if (talking) "#23A55A" else "#DBDEE1"))
                if (talking) row.setTypeface(null, Typeface.BOLD)
                llChannels.addView(row)
            }
        }
    }

    private fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("shabekura", text))
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
