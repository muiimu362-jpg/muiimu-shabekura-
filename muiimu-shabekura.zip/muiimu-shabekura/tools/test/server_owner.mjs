import { Room } from "./idx.mjs";
class WS { constructor(){this.readyState=1;this.sent=[];this.att=null;} send(m){this.sent.push(m)} close(c){this.readyState=3;this.closed=c} serializeAttachment(a){this.att=a} deserializeAttachment(){return this.att} }
globalThis.WebSocketPair=function(){ return {0:new WS(),1:new WS()}; }; globalThis.Response=class{constructor(b,o){}};
let fails=0; const ok=(c,m)=>{ if(!c){fails++; console.log("FAIL:",m);} };
const store=new Map();
function makeRoom(build){ const sockets=[]; const r=new Room({getWebSockets:()=>sockets,acceptWebSocket:w=>sockets.push(w),storage:{get:async k=>store.get(k),put:async(k,v)=>store.set(k,v)}},{BUILD_ID:build}); r.sockets=sockets; return r; }
let r=makeRoom("v1");
const join=async(n,dev,role="")=>{ await r.fetch({url:`https://x/ws?room=MUIIMU&name=${n}&dev=${dev}&role=${role}`}); return r.sockets.at(-1); };
const hello=(w)=>JSON.parse(w.sent.find(x=>x.includes('"hello"')));
const members=(w)=>JSON.parse(w.sent.filter(x=>typeof x==="string"&&x.includes('"members"')).at(-1)).list;

// 1. 最初に入った人がオーナー
const me=await join("gopura777","DEV-A"); ok(hello(me).host===true, "最初の人がオーナー");
const fr=await join("saradayou509","DEV-B"); ok(hello(fr).host===false, "2人目はオーナーじゃない");
ok(members(fr).find(m=>m.name==="gopura777").host===true, "オーナーに王冠");
// 2. オーナーが入り直してもオーナーのまま / 他の人が同じ名前で入ってもオーナーにならない
const me2=await join("gopura777","DEV-A"); ok(hello(me2).host===true, "入り直してもオーナー");
const imp=await join("gopura777x","DEV-C"); ok(hello(imp).host===false, "あとから来た人はオーナーにならない");
// 3. オーナーじゃない人は渡せない
await r.webSocketMessage(fr, JSON.stringify({t:"giveOwner", id: imp.att.id}));
ok(store.get("ownerDev2")==="DEV-A", "オーナー以外は渡せない");
// 4. 配信用（連携だけ）はオーナーの端末だけ
const br=await join("gopura777","DEV-A","bridge"); ok(br.readyState===1 && br.att.isHost, "オーナーは連携だけで入れる");
const brx=await join("saradayou509","DEV-B","bridge"); ok(brx.closed===4003, "オーナー以外は連携だけに入れない");
// 5. オーナーを渡す
await r.webSocketMessage(me2, JSON.stringify({t:"giveOwner", id: fr.att.id}));
ok(store.get("ownerDev2")==="DEV-B", "サブアカにオーナーを渡せた");
const lastOwnerMsg=(w)=>JSON.parse(w.sent.filter(x=>typeof x==="string"&&x.includes('"t":"owner"')).at(-1));
ok(lastOwnerMsg(fr).host===true && lastOwnerMsg(me2).host===false, "本人たちに知らせが届く");
ok(br.closed===4011, "前のオーナーの連携だけは終わる");
ok(members(fr).find(m=>m.name==="saradayou509").host===true && members(fr).find(m=>m.name==="gopura777").host===false, "王冠が移る");
// 新しいオーナーが入り直してもオーナー、前のオーナーは戻らない
const fr2=await join("saradayou509","DEV-B"); ok(hello(fr2).host===true, "新オーナーは入り直してもオーナー");
const me3=await join("gopura777","DEV-A"); ok(hello(me3).host===false, "前のオーナーは戻らない");
// 6. 新しい版になってもオーナーはそのまま（渡すまでずっと）
r=makeRoom("v2");
const first=await join("gopura777","DEV-A"); ok(hello(first).host===false, "新しい版でも、先に入った人がオーナーにならない");
const second=await join("saradayou509","DEV-B"); ok(hello(second).host===true, "新しい版でも、オーナーはずっと同じ人");
// オーナーが抜けても、ほかの人が入ってもオーナーにならない
second.readyState=3; await r.webSocketClose(second,1000,"bye");
const third=await join("友達","DEV-C"); ok(hello(third).host===false, "オーナーが抜けても、ほかの人はオーナーにならない");
// 8日たってもオーナーの端末が来なかったら（アプリを消した時の救済）次に入った人
const realNow=Date.now; Date.now=()=>realNow()+8*24*3600*1000;
const late=await join("むいいむ新","DEV-NEW"); ok(hello(late).host===true, "オーナーの端末が7日以上来なかったら、次に入った人がオーナー");
Date.now=realNow;
// 7. 端末IDがない（古いアプリ）人はオーナーにならない
store.clear();
r=makeRoom("v3"); const old=await join("someone",""); ok(hello(old).host===false, "端末IDなしはオーナーにならない");
const nx=await join("gopura777","DEV-A"); ok(hello(nx).host===true, "その次の端末IDありの人がオーナー");
// 休憩中: 抜けた人は覚えている
console.log(fails===0?"ALL OK":"FAILED "+fails);
