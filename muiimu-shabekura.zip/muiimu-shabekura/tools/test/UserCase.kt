import com.muiimu.shabekura.*
import kotlin.random.Random
fun main() {
    var allOk = true
    for (sel in SelMode.values()) for (victim in VictimStyle.values()) for (delay in 0..3) {
        val rnd = Random(sel.ordinal * 100 + victim.ordinal * 10 + delay)
        val cfg = Cfg(sel, victim, true, delay, 0.0, false, "yRot", false, 100)
        val host = P("gopura777", 0.0, 64.0, 0.0, 0, 0.0)
        val sub = P("saradayou509", 5.0, 64.0, 0.0, 0, 0.0)
        val mc = FakeMc(cfg, rnd, host); mc.players.addAll(listOf(host, sub))
        var id = 0; val logic = BridgeLogic { "r${id++}" }
        val members = listOf("gopura777", "saradayou509")
        var found = 0; var checks = 0
        for (tick in 1..100) {
            val now = tick * 200L
            mc.move()
            for (c in logic.tick(now, members)) mc.receive(c, tick)
            for (r in mc.deliver(tick)) logic.onMessage(r, now)
            val snap = logic.snapshot(now, members, "gopura777")
            if (tick > 10) {
                checks += 2
                if (snap["gopura777"] != null) found++
                if (snap["saradayou509"] != null) found++
            }
        }
        val line = "名前検索=$sel 名前一覧=$victim 遅れ=${delay * 200}ms → 見つかった ${found}/${checks}"
        if (found != checks) { allOk = false; println("NG " + line) }
    }
    println(if (allOk) "あなたの状況（全${SelMode.values().size * VictimStyle.values().size * 4}パターン）: 全部 100% 見つかった" else "見つからないパターンあり")
}
