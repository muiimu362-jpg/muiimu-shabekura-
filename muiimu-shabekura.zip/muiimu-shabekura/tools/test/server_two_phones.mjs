import { Room } from "./idx.mjs";
class WS { constructor(){this.readyState=1;this.sent=[];this.att=null;}
 send(m){this.sent.push(m)} close(c){this.readyState=3;this.closed=c}
 serializeAttachment(a){this.att=a} deserializeAttachment(){return this.att} }
let fails=0; const ok=(c,m)=>{ if(!c){fails++; console.log("FAIL:",m);} };
const sockets=[]; const store=new Map();
const ctx={ getWebSockets:()=>sockets, acceptWebSocket:(w)=>sockets.push(w), storage:{get:async k=>store.get(k), put:async(k,v)=>store.set(k,v)} };
globalThis.WebSocketPair=function(){ return {0:new WS(),1:new WS()}; }; globalThis.Response=class{constructor(b,o){}};
const r=new Room(ctx,{}); await r.init("KEY");
const join=async(n,k="",role="")=>{ await r.fetch({url:`https://x/ws?room=AAAAAA&name=${n}&key=${k}&role=${role}`}); return sockets.at(-1); };
const bin=(w)=>w.sent.filter(x=>typeof x!=="string").length;
const talk=async(from,to)=>{ const b=bin(to); await r.webSocketMessage(from,new Uint8Array([1,2]).buffer); return bin(to)>b; };
const lastMembers=(w)=>JSON.parse(w.sent.filter(x=>typeof x==="string"&&x.includes('"members"')).at(-1));

// 本アカ: 連携だけ（gopura777）
const bridge=await join("gopura777","KEY","bridge");
ok(bridge.readyState===1, "連携だけで入れる");
// 鍵なしの連携だけは入れない
const fake=await join("someone","","bridge"); ok(fake.closed===4003, "鍵なしの連携だけは拒否");
// サブのスマホ: 声担当 gopura777（鍵なし）、友達 saradayou509
const voice=await join("gopura777"); const friend=await join("saradayou509");
ok(bridge.readyState===1 && voice.readyState===1, "同じ名前でも 連携だけ と 声 は両立（追い出されない）");
let L=lastMembers(friend).list;
ok(L.length===2 && !L.some(m=>m.id===bridge.att.id), "メンバー一覧に連携だけの接続は出ない");
ok(L.find(m=>m.name==="gopura777").host===true, "声担当の gopura777 に王冠（運営）");
// /connect 前: ふつうの通話。連携だけには声が届かない
ok(await talk(friend,voice) && await talk(voice,friend), "connect前 ふつうの通話");
ok(!(await talk(friend,bridge)), "連携だけのスマホには声を流さない（配信のマイクを邪魔しない）");
const before=bin(friend); await r.webSocketMessage(bridge,new Uint8Array([1,2]).buffer); ok(bin(friend)===before, "連携だけからの音は流さない");
// 連携だけから位置
await r.webSocketMessage(bridge, JSON.stringify({t:"pos",p:{gopura777:{x:0,y:0,z:0,d:0}, saradayou509:{x:3,y:0,z:0,d:0}}}));
ok(r.slots.get("gopura777")===1 && r.slots.get("saradayou509")===2, "通話1=gopura777(声担当) 通話2=saradayou509");
ok(await talk(friend,voice) && await talk(voice,friend), "近い→聞こえる");
await r.webSocketMessage(bridge, JSON.stringify({t:"pos",p:{gopura777:{x:0,y:0,z:0,d:0}, saradayou509:{x:90,y:0,z:0,d:0}}}));
ok(!(await talk(friend,voice)), "遠い→聞こえない");
// 声担当が入り直しても連携だけは切れない
const voice2=await join("gopura777"); ok(voice.closed===4009 && bridge.readyState===1, "声担当の入り直しで連携だけは切れない");
// 連携だけが入り直すと古い連携だけだけ切れる
const bridge2=await join("gopura777","KEY","bridge"); ok(bridge.closed===4009 && voice2.readyState===1, "連携だけの入り直しで声担当は切れない");
// ふつうのホスト（1台運用）も今まで通り
console.log(fails===0?"ALL OK":"FAILED "+fails);
