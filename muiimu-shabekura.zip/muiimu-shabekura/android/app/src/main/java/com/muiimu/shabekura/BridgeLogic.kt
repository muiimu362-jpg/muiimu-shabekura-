package com.muiimu.shabekura

/**
 * マイクラとのやりとりの中身（通信の部分とは切り離してあるので、そのままテストできる）
 *
 * 位置の取り方を4通り用意して、使えるものを自動で使う:
 *  1. 名前で探す   querytarget @a[name="名前"]   … 書き方を2通り試して、通ったほうを使い続ける
 *  2. 並び順で組み合わせる  testfor @a（全員の名前）＋ querytarget @a（全員の位置）
 *     … 名前で探すのが全部失敗するマイクラでも動く
 *  3. 自分（ホスト）の位置   querytarget @s
 * マイクラ上の本当の名前は testfor @a で調べて、アプリの名前と
 * 「完全一致 → 大文字小文字の違い」で結びつける（それ以上はまちがえないよう結びつけない）。
 */
class BridgeLogic(private val newId: () -> String) {

    companion object {
        const val PENDING_TIMEOUT_MS = 3000L
        const val MAX_PENDING = 50
        const val FRESH_MS = 2000L
        const val LIST_EVERY_MS = 1000L
    }

    private enum class Kind { POS, NAMES, ALL, SELF, OTHER }

    private data class Req(val kind: Kind, val sentAt: Long, val member: String? = null, val form: Int = 0)

    private val pending = HashMap<String, Req>()
    private val byName = HashMap<String, Pair<Pos, Long>>()

    // testfor @a と querytarget @a は「同じ回」に送ったペアだけを組み合わせる
    private var round = 0
    private val roundNames = HashMap<Int, Pair<List<String>, Long>>()
    private val roundAll = HashMap<Int, Pair<List<Pos>, Long>>()
    private val roundSelf = HashMap<Int, Pos?>()   // その回の @s（失敗なら null）
    private val reqRound = HashMap<String, Int>()
    private var pairNames: List<String> = emptyList()
    private var pairAll: List<Pos> = emptyList()
    private var pairAt = 0L

    private var selfPos: Pos? = null
    private var selfAt = 0L

    /** マイクラ上の名前一覧（testfor @a の結果） */
    var mcNames: List<String> = emptyList(); private set
    private var mcNamesAt = 0L

    private var lastList = 0L
    private var formWorks = -1           // 名前で探す書き方: 0 = name="x", 1 = name=x
    private var formTry = 0
    var responses = 0; private set
    var lastError = ""; private set

    // ---------- 送るもの ----------

    fun commandJson(id: String, line: String): String =
        "{\"header\":{\"version\":1,\"requestId\":${MiniJson.quote(id)},\"messageType\":\"commandRequest\",\"messagePurpose\":\"commandRequest\"}," +
            "\"body\":{\"version\":1,\"commandLine\":${MiniJson.quote(line)},\"origin\":{\"type\":\"player\"}}}"

    /** 連携したときにマイクラのチャットに出すあいさつ */
    fun greeting(): String {
        val id = newId()
        pending[id] = Req(Kind.OTHER, 0)
        val raw = MiniJson.write(mapOf("rawtext" to listOf(mapOf("text" to "§a[むいいむ しゃべくら] マイクラと連携したよ！"))))
        return commandJson(id, "tellraw @s $raw")
    }

    /** 名前を選ぶ書き方。form 1（引用符なし）は使える文字だけのときにしか使わない */
    private fun selector(name: String, form: Int): String {
        return if (form == 1 && name.isNotEmpty() && name.all { it.isLetterOrDigit() || it == '_' }) {
            "@a[name=$name]"
        } else {
            "@a[name=" + MiniJson.quote(name) + "]"
        }
    }

    /**
     * 200ms ごとに呼ぶ。マイクラに送るコマンド（JSON文字列）のリストを返す。
     * members = 通話に入っている人のアプリ上の名前、hostName = ホスト（このスマホ）の名前
     */
    fun tick(now: Long, members: List<String>): List<String> {
        val it = pending.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            if (now - e.value.sentAt > PENDING_TIMEOUT_MS) { reqRound.remove(e.key); it.remove() }
        }
        val out = ArrayList<String>()
        if (pending.size >= MAX_PENDING) return out

        // @s の返事が届かなかった回は、@s なしで組み合わせる
        for (r in roundNames.keys.toList()) {
            if (roundAll.containsKey(r) && !roundSelf.containsKey(r)) {
                val t = maxOf(roundNames[r]!!.second, roundAll[r]!!.second)
                if (now - t > PENDING_TIMEOUT_MS) { roundSelf[r] = null; tryPair(r) }
            }
        }

        if (now - lastList >= LIST_EVERY_MS) {
            lastList = now
            round++
            val idN = newId(); pending[idN] = Req(Kind.NAMES, now); reqRound[idN] = round
            out.add(commandJson(idN, "testfor @a"))
            val idA = newId(); pending[idA] = Req(Kind.ALL, now); reqRound[idA] = round
            out.add(commandJson(idA, "querytarget @a"))
            val idS = newId(); pending[idS] = Req(Kind.SELF, now); reqRound[idS] = round
            out.add(commandJson(idS, "querytarget @s"))
            // 古い回は捨てる
            roundNames.keys.removeAll { it < round - 5 }
            roundAll.keys.removeAll { it < round - 5 }
            roundSelf.keys.removeAll { it < round - 5 }
        }

        for (m in members.distinct()) {
            if (pending.size >= MAX_PENDING) break
            val target = resolve(m) ?: m
            val form = if (formWorks >= 0) formWorks else (formTry++ % 2)
            val id = newId()
            pending[id] = Req(Kind.POS, now, m, form)
            out.add(commandJson(id, "querytarget " + selector(target, form)))
        }
        return out
    }

    // ---------- 受け取るもの ----------

    fun onMessage(text: String, now: Long) {
        val msg = try { MiniJson.parse(text).obj() } catch (e: Exception) { null } ?: return
        val header = msg["header"].obj() ?: return
        val purpose = header.str("messagePurpose") ?: return
        if (purpose != "commandResponse" && purpose != "error") return
        val id = header.str("requestId") ?: return
        val req = pending.remove(id) ?: return
        val r = reqRound.remove(id)
        responses++
        val body = msg["body"].obj() ?: emptyMap()
        val code = body.num("statusCode")?.toInt() ?: if (purpose == "error") -1 else 0
        val ok = purpose == "commandResponse" && code == 0

        when (req.kind) {
            Kind.POS -> {
                val list = if (ok) targets(body) else emptyList()
                if (list.size == 1) {
                    byName[req.member!!] = list[0] to now
                    formWorks = req.form
                } else if (list.size > 1) {
                    // 大文字小文字だけ違う人が2人いるなど → どちらか決められないので使わない
                    formWorks = req.form
                    byName.remove(req.member!!)
                } else if (!ok) {
                    noteError(body, code)
                }
            }
            Kind.NAMES -> {
                val names = if (ok) victims(body) else emptyList()
                // 失敗 = だれもいない（またはエラー）。どちらにしても名前は空
                if (ok || isNoTarget(body)) {
                    mcNames = names; mcNamesAt = now
                    if (r != null) { roundNames[r] = names to now; tryPair(r) }
                } else noteError(body, code)
            }
            Kind.ALL -> {
                val list = if (ok) targets(body) else emptyList()
                if (ok || isNoTarget(body)) {
                    if (r != null) { roundAll[r] = list to now; tryPair(r) }
                } else noteError(body, code)
            }
            Kind.SELF -> {
                val list = if (ok) targets(body) else emptyList()
                val p = if (list.size == 1) list[0] else null
                if (p != null) { selfPos = p; selfAt = now }
                if (r != null) { roundSelf[r] = p; tryPair(r) }
            }
            Kind.OTHER -> {}
        }
    }

    private fun tryPair(r: Int) {
        val n = roundNames[r] ?: return
        val a = roundAll[r] ?: return
        if (!roundSelf.containsKey(r)) return   // 同じ回の @s を待つ
        val self = roundSelf[r]
        // 人数が同じときだけ、並び順で組み合わせる
        if (n.first.size == a.first.size) {
            pairNames = n.first; pairAll = a.first; pairAt = maxOf(n.second, a.second)
            selfAtPair = self
        }
        roundNames.remove(r); roundAll.remove(r); roundSelf.remove(r)
    }

    private var selfAtPair: Pos? = null

    private fun isNoTarget(body: Map<String, Any?>): Boolean {
        val m = body.str("statusMessage") ?: return false
        return m.contains("No targets") || m.contains("対象がありません") || m.contains("見つかりません") ||
            m.contains("not found", ignoreCase = true)
    }

    private fun noteError(body: Map<String, Any?>, code: Int) {
        lastError = (body.str("statusMessage") ?: "エラー $code").take(80)
    }

    /** querytarget の結果（details）から位置の一覧を読む */
    private fun targets(body: Map<String, Any?>): List<Pos> {
        val raw: Any? = when (val d = body["details"]) {
            is String -> d.trim().let { if (it.startsWith("[")) try { MiniJson.parse(it) } catch (_: Exception) { null } else null }
            is List<*> -> d
            else -> null
        } ?: body.str("statusMessage")?.let { sm ->
            val a = sm.indexOf('['); val b = sm.lastIndexOf(']')
            if (a >= 0 && b > a) try { MiniJson.parse(sm.substring(a, b + 1)) } catch (_: Exception) { null } else null
        }
        val out = ArrayList<Pos>()
        for (t in raw.list() ?: return out) {
            val o = t.obj() ?: continue
            val p = o["position"].obj() ?: continue
            val x = p.num("x") ?: continue
            val y = p.num("y") ?: continue
            val z = p.num("z") ?: continue
            val dim = (o.num("dimension") ?: 0.0).toInt()
            val yaw = o.num("yRot") ?: o.num("y-rot") ?: o.num("yrot") ?: 0.0
            out.add(Pos(x, y, z, dim, yaw))
        }
        return out
    }

    /** testfor の結果から名前の一覧を読む */
    private fun victims(body: Map<String, Any?>): List<String> {
        body["victim"].list()?.let { l -> return l.mapNotNull { it as? String } }
        body["victims"].list()?.let { l -> return l.mapNotNull { it as? String } }
        // 配列が無いときは「Found a, b」「a, b を見つけました」のような文から読む
        val sm = body.str("statusMessage") ?: return emptyList()
        var s = sm
        val colon = maxOf(s.lastIndexOf(':'), s.lastIndexOf('：'))
        if (colon >= 0) s = s.substring(colon + 1)
        s = s.removePrefix("Found").trim()
        for (suffix in listOf("を見つけました", "が見つかりました", "を発見しました")) s = s.removeSuffix(suffix)
        return s.split(",", "、").map { it.trim() }.filter { it.isNotEmpty() }
    }

    // ---------- 名前の結びつけ ----------

    /**
     * アプリの名前 → マイクラ上の名前（見つからなければ null）
     * 完全に同じ名前か、大文字小文字だけ違う名前（ゲーマータグは大文字小文字を区別しないので同じ人）。
     * それ以上あいまいな結びつけはしない（別の人とまちがえないため）。
     */
    fun resolve(member: String): String? = resolveIn(member, mcNames)

    // ---------- まとめ ----------

    /** 今わかっている全員の位置（キーはアプリ上の名前） */
    fun snapshot(now: Long, members: List<String>, hostName: String): Map<String, Pos> {
        val out = HashMap<String, Pos>()
        for (m in members.distinct()) {
            // 1. 名前で探せた
            byName[m]?.let { (p, t) -> if (now - t < FRESH_MS) { out[m] = p; return@let } }
            if (out.containsKey(m)) continue
            // 2. 並び順で組み合わせ（ホストの位置で並び順が正しいか確かめてから）
            if (now - pairAt < FRESH_MS + LIST_EVERY_MS && pairTrusted(hostName)) {
                val mc = resolveIn(m, pairNames)
                if (mc != null) {
                    val i = pairNames.indexOf(mc)
                    if (i >= 0 && i < pairAll.size) { out[m] = pairAll[i]; continue }
                }
            }
            // 3. ホスト自身
            if (m == hostName) selfPos?.let { if (now - selfAt < FRESH_MS + LIST_EVERY_MS) out[m] = it }
        }
        return out
    }

    /** 並び順の組み合わせが正しそうか、ホスト自身の位置（@s）で確かめる */
    private fun pairTrusted(hostName: String): Boolean {
        val sp = selfAtPair ?: return true
        val mc = resolveIn(hostName, pairNames) ?: return true
        val i = pairNames.indexOf(mc)
        if (i < 0 || i >= pairAll.size) return true
        val p = pairAll[i]
        return p.d == sp.d && Spatial.distance(p, sp) < 0.5
    }

    private fun resolveIn(member: String, names: List<String>): String? {
        val m = member.trim()
        names.firstOrNull { it == m }?.let { return it }
        names.filter { it.equals(m, ignoreCase = true) }.let { if (it.size == 1) return it[0] }
        return null
    }

    /** ホストの画面に出す説明 */
    fun info(now: Long, members: List<String>, snap: Map<String, Pos>): String = buildString {
        append("マイクラで見つかった人: ${snap.size}人")
        if (responses == 0) append("（マイクラから返事がまだ無い）")
        if (now - mcNamesAt < 5000 && mcNames.isNotEmpty()) append("\nマイクラ上の名前: ${mcNames.joinToString(", ")}")
        val missing = members.distinct().filter { it !in snap.keys }
        if (missing.isNotEmpty()) {
            append("\n見つからない名前: ${missing.joinToString(", ")}")
            if (lastError.isNotEmpty()) append("\nマイクラの返事: $lastError")
        }
    }

    fun reset() {
        pending.clear(); byName.clear(); roundNames.clear(); roundAll.clear(); roundSelf.clear(); reqRound.clear(); selfAtPair = null
        pairNames = emptyList(); pairAll = emptyList(); pairAt = 0
        selfPos = null; selfAt = 0; mcNames = emptyList(); mcNamesAt = 0
        lastList = 0; responses = 0; lastError = ""
        // formWorks は残す（同じマイクラなら同じ書き方が通る）
    }
}
