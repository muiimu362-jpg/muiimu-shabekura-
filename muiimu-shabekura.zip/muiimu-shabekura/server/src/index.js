// むいいむ しゃべくら 中継サーバー (Cloudflare Workers + Durable Objects)
import { DurableObject } from "cloudflare:workers";
import { WEB_HTML, MANIFEST, ICON_SVG } from "./web.js";

// これより遠い人には音声そのものを送らない（ブロック）
const SERVER_CUTOFF = 26;
// ホストから座標が届かなくなったら、通話を止めるまでの時間
const POS_TIMEOUT_MS = 5000;
// 部屋の数（通話1 = 運営、通話2〜MAX_SLOT = プレイヤー。1部屋1人）
const MAX_SLOT = 20;

const CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function randomString(chars, len) {
  const bytes = new Uint8Array(len);
  crypto.getRandomValues(bytes);
  let s = "";
  for (const b of bytes) s += chars[b % chars.length];
  return s;
}

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/api/create" && request.method === "POST") {
      let body = {};
      try {
        body = await request.json();
      } catch (_) {}
      // 通話を作れるのはパスワードを知っている人（＝むいいむ）だけ
      if (!env.OWNER_PASSWORD || body.password !== env.OWNER_PASSWORD) {
        return json({ error: "パスワードが違います" }, 403);
      }
      // 決まった待機所（LOBBY_CODE）を開く。code を指定しなければ新しい部屋を作る
      const want = typeof body.code === "string" ? body.code.toUpperCase() : "";
      const code = /^[A-Z0-9]{6}$/.test(want) ? want : randomString(CODE_CHARS, 6);
      const hostKey = randomString("0123456789abcdef", 32);
      const stub = env.ROOM.get(env.ROOM.idFromName(code));
      await stub.init(hostKey);
      return json({ code, hostKey });
    }

    if (url.pathname === "/ws") {
      if (request.headers.get("Upgrade") !== "websocket") {
        return new Response("websocket only", { status: 426 });
      }
      const code = (url.searchParams.get("room") || "").toUpperCase();
      if (!/^[A-Z0-9]{6}$/.test(code)) return new Response("bad room", { status: 400 });
      const stub = env.ROOM.get(env.ROOM.idFromName(code));
      return stub.fetch(request);
    }

    if (url.pathname === "/manifest.json") {
      return new Response(MANIFEST, { headers: { "content-type": "application/manifest+json" } });
    }
    if (url.pathname === "/icon.svg") {
      return new Response(ICON_SVG, { headers: { "content-type": "image/svg+xml" } });
    }
    if (url.pathname === "/health") {
      return new Response("むいいむ しゃべくら server OK", {
        headers: { "content-type": "text/plain; charset=utf-8" },
      });
    }
    // それ以外は Web 版（iPhone・PC 用）を返す
    return new Response(WEB_HTML, {
      headers: { "content-type": "text/html; charset=utf-8" },
    });
  },
};

export class Room extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.positions = {}; // name -> {x,y,z,d,r}
    this.lastPosAt = 0;
    this.mcOnline = false;
    this.slots = new Map();   // name -> 部屋番号
    this.optOut = new Set();  // 「通話を抜ける」を押した人
  }

  async init(hostKey) {
    await this.ctx.storage.put("hostKey", hostKey);
  }

  openSockets(except) {
    return this.ctx
      .getWebSockets()
      .filter((s) => s !== except && s.readyState === 1);
  }

  async fetch(request) {
    const url = new URL(request.url);
    const hostKey = await this.ctx.storage.get("hostKey");
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    this.ctx.acceptWebSocket(server);

    if (!hostKey) {
      server.close(4004, "room not found");
      return new Response(null, { status: 101, webSocket: client });
    }

    const name = (url.searchParams.get("name") || "").trim().slice(0, 40);
    if (!name) {
      server.close(4001, "no name");
      return new Response(null, { status: 101, webSocket: client });
    }
    const isHost = url.searchParams.get("key") === hostKey;
    // 「連携だけ」の接続（マイクラの位置を送るだけ。声は別のスマホ）
    const bridge = url.searchParams.get("role") === "bridge";
    if (bridge && !isHost) {
      server.close(4003, "host only");
      return new Response(null, { status: 101, webSocket: client });
    }

    // 同じ名前・同じ役割で入り直したら古い接続を切る（連携だけ と 声 は同じ名前でも両立できる）
    const used = new Set();
    for (const s of this.openSockets(server)) {
      const a = s.deserializeAttachment();
      if (!a) continue;
      if (a.name === name && !!a.bridge === bridge) {
        try { s.close(4009, "replaced"); } catch (_) {}
      } else {
        used.add(a.id);
      }
    }
    let id = 1;
    while (used.has(id) && id < 250) id++;
    if (used.size >= 249) {
      server.close(4010, "room full");
      return new Response(null, { status: 101, webSocket: client });
    }

    server.serializeAttachment({ id, name, isHost, bridge });
    server.send(JSON.stringify({ t: "hello", id, host: isHost, bridge }));
    if (!bridge) this.optOut.delete(name);
    this.updateSlots();
    this.broadcastMembers();
    return new Response(null, { status: 101, webSocket: client });
  }

  posActive() {
    return this.mcOnline && Date.now() - this.lastPosAt < POS_TIMEOUT_MS;
  }

  // 聞こえるかどうか
  // ・運営が /connect する前 → 全員ふつうの通話
  // ・ワールドの外にいる人どうし → ふつうの通話
  // ・ワールドの中にいる人どうし → 近ければ聞こえる（部屋番号は違っても OK）
  // ・「通話を抜ける」中の人 → 誰とも話さない
  canHear(a, b) {
    if (this.optOut.has(a) || this.optOut.has(b)) return false;
    if (!this.posActive()) return true;
    const inA = this.slots.has(a), inB = this.slots.has(b);
    if (!inA && !inB) return !this.positions[a] && !this.positions[b];
    if (!inA || !inB) return false;
    const pa = this.positions[a];
    const pb = this.positions[b];
    if (!pa || !pb) return false;
    if (pa.d !== pb.d) return false;
    const dx = pa.x - pb.x, dy = pa.y - pb.y, dz = pa.z - pb.z;
    return dx * dx + dy * dy + dz * dz <= SERVER_CUTOFF * SERVER_CUTOFF;
  }

  // 声で参加している人（「連携だけ」の接続は入れない）
  memberAttachments(except) {
    const list = [];
    for (const s of this.openSockets(except)) {
      const a = s.deserializeAttachment();
      if (a && !a.bridge) list.push(a);
    }
    return list.sort((x, y) => x.id - y.id);
  }

  // 「連携だけ」の接続をしているホストの名前（小文字）
  bridgeNames(except) {
    const set = new Set();
    for (const s of this.openSockets(except)) {
      const a = s.deserializeAttachment();
      if (a && a.bridge) set.add(a.name.toLowerCase());
    }
    return set;
  }

  // 運営として扱うか（ホストの鍵で入った人、または「連携だけ」と同じ名前の声担当）
  isOperator(a, bridgeNames) {
    return a.isHost || bridgeNames.has(a.name.toLowerCase());
  }

  // ワールドにいる人に部屋番号を割り当てる。変わったらみんなに知らせる
  updateSlots(except) {
    const members = this.memberAttachments(except);
    const bn = this.bridgeNames(except);
    const next = new Map();
    if (this.posActive()) {
      const eligible = (a) => !!this.positions[a.name] && !this.optOut.has(a.name);
      // 運営は通話1
      for (const a of members) {
        if (this.isOperator(a, bn) && eligible(a) && ![...next.values()].includes(1)) next.set(a.name, 1);
      }
      // すでに部屋がある人はそのまま
      for (const a of members) {
        if (next.has(a.name) || !eligible(a)) continue;
        const old = this.slots.get(a.name);
        if (old && old !== 1 && ![...next.values()].includes(old)) next.set(a.name, old);
      }
      // 新しく入った人は空いている一番小さい番号へ
      for (const a of members) {
        if (next.has(a.name) || !eligible(a)) continue;
        const used = new Set(next.values());
        for (let n = 2; n <= MAX_SLOT; n++) {
          if (!used.has(n)) { next.set(a.name, n); break; }
        }
      }
    }
    let changed = next.size !== this.slots.size;
    if (!changed) {
      for (const [k, v] of next) if (this.slots.get(k) !== v) { changed = true; break; }
    }
    this.slots = next;
    if (changed) this.broadcastMembers(except);
  }

  broadcastText(obj, except) {
    const msg = JSON.stringify(obj);
    for (const s of this.openSockets(except)) {
      try { s.send(msg); } catch (_) {}
    }
  }

  broadcastMembers(except) {
    const bn = this.bridgeNames(except);
    const list = this.memberAttachments(except).map((a) => ({
      id: a.id,
      name: a.name,
      host: this.isOperator(a, bn),
      slot: this.slots.get(a.name) || 0,
      out: this.optOut.has(a.name),
      inWorld: !!this.positions[a.name],
    }));
    this.broadcastText({ t: "members", list, mc: this.posActive(), max: MAX_SLOT, bridges: [...bn] }, except);
  }

  async webSocketMessage(ws, message) {
    const a = ws.deserializeAttachment();
    if (!a) return;

    if (typeof message === "string") {
      let m;
      try { m = JSON.parse(message); } catch (_) { return; }
      if (m.t === "pos" && a.isHost && m.p && typeof m.p === "object") {
        this.positions = m.p;
        this.lastPosAt = Date.now();
        const wasActive = this.mcOnline;
        this.mcOnline = true;
        this.broadcastText({ t: "pos", p: m.p });
        this.updateSlots();
        if (!wasActive) this.broadcastMembers();
      } else if (m.t === "mc" && a.isHost) {
        this.mcOnline = !!m.on;
        if (!m.on) this.positions = {};
        this.broadcastText({ t: "mc", on: !!m.on });
        this.updateSlots();
        this.broadcastMembers();
      } else if (m.t === "optout" && !a.bridge) {
        // 「通話を抜ける」/「通話に戻る」
        if (m.on) this.optOut.add(a.name); else this.optOut.delete(a.name);
        this.updateSlots();
        this.broadcastMembers();
      } else if (m.t === "ping") {
        ws.send(JSON.stringify({ t: "pong" }));
      }
      return;
    }

    // 音声フレーム: 先頭1バイトに話している人のIDを付けて、聞こえる範囲の人にだけ送る
    if (a.bridge) return; // 「連携だけ」の接続は声を送らない
    const data = new Uint8Array(message);
    if (data.length === 0 || data.length > 4000) return;
    const out = new Uint8Array(data.length + 1);
    out[0] = a.id;
    out.set(data, 1);
    for (const s of this.openSockets(ws)) {
      const b = s.deserializeAttachment();
      if (!b || b.bridge) continue; // 「連携だけ」の接続には声を流さない
      if (this.canHear(a.name, b.name)) {
        try { s.send(out); } catch (_) {}
      }
    }
  }

  async webSocketClose(ws, code, reason) {
    try { ws.close(code, reason); } catch (_) {}
    this.updateSlots(ws);
    this.broadcastMembers(ws);
  }

  async webSocketError(ws) {
    this.updateSlots(ws);
    this.broadcastMembers(ws);
  }
}
