import com.muiimu.shabekura.*
import kotlin.random.Random
// サブアカで /connect して、本アカ（アプリの名前）で話すとき
fun main() {
    var allOk = true; var total = 0
    for (sel in SelMode.values()) for (victim in VictimStyle.values()) for (delay in 0..3) {
        total++
        val rnd = Random(sel.ordinal * 100 + victim.ordinal * 10 + delay + 3)
        val cfg = Cfg(sel, victim, true, delay, 0.0, false, "yRot", false, 100)
        val sub = P("muiimu_sub", 50.0, 64.0, 50.0, 0, 0.0)        // /connect したサブアカ（@s）
        val main = P("gopura777", 0.0, 64.0, 0.0, 0, 0.0)          // 本アカ（アプリで話す）
        val fr = P("saradayou509", 3.0, 64.0, 0.0, 0, 0.0)
        val mc = FakeMc(cfg, rnd, sub); mc.players.addAll(listOf(sub, main, fr))
        var id = 0; val logic = BridgeLogic { "r${id++}" }
        val members = listOf("gopura777", "saradayou509")
        var good = 0; var checks = 0; var wrong = 0
        for (tick in 1..100) {
            val now = tick * 200L
            for (c in logic.tick(now, members)) mc.receive(c, tick)
            for (r in mc.deliver(tick)) logic.onMessage(r, now)
            // アプリ側の「自分の名前」は本アカ
            val snap = logic.snapshot(now, members, "gopura777")
            if (tick > 15) {
                checks += 2
                for ((m, p) in listOf("gopura777" to main, "saradayou509" to fr)) {
                    val s = snap[m] ?: continue
                    if (Math.abs(s.x - p.x) < 0.01 && Math.abs(s.z - p.z) < 0.01) good++ else wrong++
                }
            }
        }
        if (good != checks || wrong != 0) { allOk = false; println("NG $sel $victim delay=$delay good=$good/$checks wrong=$wrong") }
    }
    println(if (allOk) "サブアカで /connect・本アカで話す: 全${total}パターン 本アカはいつも本アカの位置（サブアカと取り違え0）" else "まちがいあり")
}
