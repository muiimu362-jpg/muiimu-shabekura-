package com.muiimu.shabekura

/** この版の番号（サーバーの BUILD_ID と同じ。ちがえば「古いアプリだよ」と出す） */
object BuildStamp {
    const val ID = "20261128064011"
}
