package com.muiimu.shabekura

import android.os.Handler
import android.os.Looper

data class Member(
    val id: Int,
    val name: String,
    val host: Boolean,
    val distance: Double? = null,
    val gain: Float = 1f,
    val slot: Int = 0,          // 部屋番号（0 = 待機中）
    val out: Boolean = false,   // 「通話を抜ける」中
    val mc: String = "",        // マイクラの名前（なくても OK）
)

/** 画面とサービスで共有する状態 */
object AppState {
    // ---- 人ごとの音量（アイコン長押しで変える。0〜100%、ミュート）。名前ごとに覚えておく ----
    val userVol = java.util.concurrent.ConcurrentHashMap<String, Int>()
    val userMute: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    /** その人の音量（0.0〜1.0）。ミュートなら 0 */
    fun volOf(name: String): Float = if (name in userMute) 0f else (userVol[name] ?: 100).coerceIn(0, 100) / 100f

    @Volatile var running = false
    @Volatile var connected = false
    @Volatile var isHost = false
    @Volatile var muted = false
    @Volatile var deafened = false     // スピーカーミュート（話さない・聞かない）
    @Volatile var streamVoice = false  // 配信に自分の声ものせる（直接つながってない時はスマホの音に混ぜる）
    @Volatile var streamLinked = false // 配信アプリ（ShabekuraVoice）が直接つながってる
    @Volatile var mySlot = 0           // 自分の部屋番号（0 = 待機中）
    @Volatile var optOut = false       // 「通話を抜ける」中
    @Volatile var bridgeInfo = ""      // (ホスト) マイクラから位置が取れているか
    @Volatile var bridgeOnly = false   // 「連携だけ」モード（マイクもスピーカーも使わない）
    @Volatile var mcLinked = false      // マイクラから座標が届いているか
    @Volatile var bridgeOpen = false    // (ホストのみ) マイクラが /connect してきているか
    @Volatile var roomCode = ""
    @Volatile var myName = ""
    @Volatile var myMc = ""
    @Volatile var myId = 0
    @Volatile var status = "待機中"
    @Volatile var members: List<Member> = emptyList()
    @Volatile var talking: Set<Int> = emptySet()
    @Volatile var selfTalking = false
    @Volatile var micLevel = 0

    private val main = Handler(Looper.getMainLooper())
    private val listeners = mutableListOf<() -> Unit>()

    fun addListener(l: () -> Unit) { synchronized(listeners) { listeners.add(l) } }
    fun removeListener(l: () -> Unit) { synchronized(listeners) { listeners.remove(l) } }

    fun changed() {
        val copy = synchronized(listeners) { listeners.toList() }
        main.post { copy.forEach { it() } }
    }

    fun reset() {
        running = false; connected = false; isHost = false; muted = false; deafened = false; mySlot = 0; optOut = false; bridgeInfo = ""; bridgeOnly = false; streamVoice = false; streamLinked = false
        mcLinked = false; bridgeOpen = false; members = emptyList()
        talking = emptySet(); selfTalking = false; myId = 0; micLevel = 0
    }
}
