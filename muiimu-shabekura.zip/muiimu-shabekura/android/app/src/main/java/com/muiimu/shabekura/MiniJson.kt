package com.muiimu.shabekura

/**
 * 小さな JSON の読み書き。マイクラとのやりとり専用。
 * （Android の org.json に頼らないので、パソコン上でもそのままテストできる）
 * 読んだ結果: Map<String, Any?> / List<Any?> / String / Double / Boolean / null
 */
object MiniJson {

    class ParseException(msg: String) : Exception(msg)

    fun parse(text: String): Any? {
        val p = Parser(text)
        p.skipWs()
        val v = p.value()
        p.skipWs()
        if (p.i != text.length) throw ParseException("余分な文字があります（${p.i}文字目）")
        return v
    }

    /** 文字列を JSON の "..." にする */
    fun quote(s: String): String {
        val sb = StringBuilder(s.length + 2)
        sb.append('"')
        for (c in s) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append("\\f")
                else -> if (c < ' ') sb.append(String.format("\\u%04x", c.code)) else sb.append(c)
            }
        }
        sb.append('"')
        return sb.toString()
    }

    /** Map / List / String / 数字 / Boolean / null を JSON 文字列にする */
    fun write(v: Any?): String = when (v) {
        null -> "null"
        is String -> quote(v)
        is Boolean -> v.toString()
        is Int, is Long -> v.toString()
        is Number -> {
            val d = v.toDouble()
            if (d.isNaN() || d.isInfinite()) "0" else if (d == Math.floor(d) && Math.abs(d) < 1e15) d.toLong().toString() else d.toString()
        }
        is Map<*, *> -> v.entries.joinToString(",", "{", "}") { quote(it.key.toString()) + ":" + write(it.value) }
        is List<*> -> v.joinToString(",", "[", "]") { write(it) }
        else -> quote(v.toString())
    }

    private class Parser(val s: String) {
        var i = 0

        fun skipWs() {
            while (i < s.length && (s[i] == ' ' || s[i] == '\n' || s[i] == '\r' || s[i] == '\t')) i++
        }

        fun value(): Any? {
            if (i >= s.length) throw ParseException("途中で終わっています")
            return when (val c = s[i]) {
                '{' -> obj()
                '[' -> arr()
                '"' -> str()
                't' -> word("true", true)
                'f' -> word("false", false)
                'n' -> word("null", null)
                else -> if (c == '-' || c in '0'..'9') num() else throw ParseException("読めない文字 '$c'（${i}文字目）")
            }
        }

        fun word(w: String, v: Any?): Any? {
            if (!s.startsWith(w, i)) throw ParseException("読めない値（${i}文字目）")
            i += w.length
            return v
        }

        fun num(): Double {
            val start = i
            if (s[i] == '-') i++
            while (i < s.length && (s[i].isDigit() || s[i] == '.' || s[i] == 'e' || s[i] == 'E' || s[i] == '+' || s[i] == '-')) i++
            return s.substring(start, i).toDoubleOrNull() ?: throw ParseException("数字が読めません（${start}文字目）")
        }

        fun str(): String {
            i++ // "
            val sb = StringBuilder()
            while (true) {
                if (i >= s.length) throw ParseException("文字列が閉じていません")
                val c = s[i++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        if (i >= s.length) throw ParseException("文字列が閉じていません")
                        when (val e = s[i++]) {
                            '"' -> sb.append('"'); '\\' -> sb.append('\\'); '/' -> sb.append('/')
                            'n' -> sb.append('\n'); 'r' -> sb.append('\r'); 't' -> sb.append('\t')
                            'b' -> sb.append('\b'); 'f' -> sb.append('\u000C')
                            'u' -> {
                                if (i + 4 > s.length) throw ParseException("\\u が途中で終わっています")
                                val code = s.substring(i, i + 4).toIntOrNull(16) ?: throw ParseException("\\u が読めません")
                                sb.append(code.toChar()); i += 4
                            }
                            else -> throw ParseException("読めないエスケープ \\$e")
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }

        fun arr(): List<Any?> {
            i++ // [
            val out = ArrayList<Any?>()
            skipWs()
            if (i < s.length && s[i] == ']') { i++; return out }
            while (true) {
                skipWs(); out.add(value()); skipWs()
                if (i >= s.length) throw ParseException("配列が閉じていません")
                when (s[i++]) {
                    ',' -> continue
                    ']' -> return out
                    else -> throw ParseException("配列の区切りが変です（${i - 1}文字目）")
                }
            }
        }

        fun obj(): Map<String, Any?> {
            i++ // {
            val out = LinkedHashMap<String, Any?>()
            skipWs()
            if (i < s.length && s[i] == '}') { i++; return out }
            while (true) {
                skipWs()
                if (i >= s.length || s[i] != '"') throw ParseException("キーが文字列ではありません（${i}文字目）")
                val k = str()
                skipWs()
                if (i >= s.length || s[i] != ':') throw ParseException(": がありません（${i}文字目）")
                i++
                skipWs()
                out[k] = value()
                skipWs()
                if (i >= s.length) throw ParseException("オブジェクトが閉じていません")
                when (s[i++]) {
                    ',' -> continue
                    '}' -> return out
                    else -> throw ParseException("オブジェクトの区切りが変です（${i - 1}文字目）")
                }
            }
        }
    }
}

// 読んだ JSON から安全に値を取り出すための小さな道具
@Suppress("UNCHECKED_CAST")
internal fun Any?.obj(): Map<String, Any?>? = this as? Map<String, Any?>
internal fun Any?.list(): List<Any?>? = this as? List<Any?>
internal fun Map<String, Any?>.str(k: String): String? = this[k] as? String
internal fun Map<String, Any?>.num(k: String): Double? = when (val v = this[k]) {
    is Double -> v
    is Number -> v.toDouble()
    is String -> v.toDoubleOrNull()
    else -> null
}
