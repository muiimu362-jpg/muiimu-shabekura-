import asyncio, json, subprocess, sys, time
from playwright.async_api import async_playwright
FAKE_WS = """
window.__sent = []; window.__sockets = [];
class FakeWS {
  constructor(url){ this.url=url; this.readyState=0; this.binaryType='blob'; window.__sockets.push(this);
    setTimeout(()=>{ this.readyState=1; this.onopen && this.onopen({}); }, 50); }
  send(d){ window.__sent.push(typeof d === 'string' ? d : '[binary ' + (d.byteLength||d.length) + ']'); }
  close(){ this.readyState=3; }
  _recv(obj){ this.onmessage && this.onmessage({data: typeof obj==='string'?obj:JSON.stringify(obj)}); }
  _recvBin(arr){ this.onmessage && this.onmessage({data: new Uint8Array(arr).buffer}); }
}
window.WebSocket = FakeWS;
"""
async def main():
    srv = subprocess.Popen([sys.executable, "-m", "http.server", "8765"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(1)
    fails = []
    def ok(c, m):
        print(("OK   " if c else "FAIL ") + m)
        if not c: fails.append(m)
    try:
        async with async_playwright() as p:
            b = await p.chromium.launch(executable_path="/usr/bin/google-chrome",
                args=["--no-sandbox","--use-fake-device-for-media-stream","--use-fake-ui-for-media-stream","--autoplay-policy=no-user-gesture-required"])
            ctx = await b.new_context(viewport={"width":390,"height":844}, permissions=["microphone"])
            pg = await ctx.new_page()
            await pg.add_init_script(FAKE_WS)
            errors = []
            pg.on("pageerror", lambda e: errors.append(str(e)))
            await pg.goto("http://localhost:8765/index.html")
            # 最初の画面: どの端末でも「ブラウザ」「アプリ」を選ぶ
            await pg.wait_for_timeout(100)
            ok(await pg.is_visible("#useBrowser") and await pg.is_visible("#dlApk") and not await pg.is_visible("#namePanel"), "最初の画面は「ブラウザ」「アプリ」の2つ（PC/iPhoneでも）")
            href = await pg.evaluate("document.getElementById('dlApk').getAttribute('href')")
            ok("MuiimuShabekura.apk" in href or "__APK_URL__" in href, "「アプリ」はダウンロードリンク: " + href)
            await pg.click("#useBrowser")
            # 0. 一番最初は「名前を決めてください」
            ok(await pg.is_visible("#namePanel") and not await pg.is_visible("#setup"), "最初の画面は「名前を決めてください」")
            await pg.fill("#displayName", "サブ垢")
            await pg.click("#setName")
            ok(await pg.is_visible("#setup") and "サブ垢" in await pg.inner_text("#myNameLabel"), "名前を決めるとチャンネル一覧になる")
            # 1. 待機所をタップ → マイクラの名前（サブ） → 入る
            await pg.click("#chLobby")
            ok(await pg.is_visible("#joinForm"), "待機所をタップすると入力欄が出る")
            await pg.fill("#mcName", "saradayou509")
            await pg.click("#join")
            await pg.wait_for_timeout(800)
            url = await pg.evaluate("window.__sockets[0] && window.__sockets[0].url")
            import urllib.parse as up
            q = up.parse_qs(up.urlparse(url).query) if url else {}
            ok(q.get("room")==["MUIIMU"] and q.get("name")==["サブ垢"] and q.get("mc")==["saradayou509"] and q.get("dev",[""])[0].startswith("web-"), "呼び名とマイクラの名前を分けてつながる: " + str(q))
            ok(await pg.is_visible("#call"), "通話画面になる")
            # 2. サーバーから hello(オーナー) と members
            await pg.evaluate("""() => { const w=window.__sockets[0];
              w._recv({t:'hello', id:2, host:true});
              w._recv({t:'members', mc:false, list:[{id:1,name:'むいいむ',mc:'gopura777',host:false,slot:0},{id:2,name:'サブ垢',mc:'saradayou509',host:true,slot:0},{id:3,name:'見学の人',mc:'',host:false,slot:0}]}); }""")
            await pg.wait_for_timeout(300)
            ok(await pg.is_visible("#giveOwner"), "オーナーには右上に「オーナーを渡す」が出る")
            # 真ん中のタイル（待機所はふつうの通話なので全員）
            await pg.wait_for_timeout(300)
            tiles = await pg.inner_text("#tiles")
            ok("サブ垢" in tiles and "むいいむ" in tiles and "見学の人" in tiles, "タイルに自分と聞こえる人が出る: " + tiles.replace(chr(10)," | "))
            ok("近接VC待機所" in await pg.inner_text("#roomLabel"), "上の札に「近接VC待機所」")
            ok(await pg.is_visible("#shareTop") and await pg.is_visible("#invite"), "右上のシェアと「メンバーを追加」カードが出る（全員）")
            # マイク: 1回押すとミュート、もう1回で戻る
            m0 = await pg.inner_html("#mute"); await pg.click("#mute"); m1 = await pg.inner_html("#mute"); await pg.click("#mute"); m2 = await pg.inner_html("#mute")
            ok(m0 == m2 and m0 != m1 and "F23F43" in m1, "マイク: 1回でミュート（赤）、もう1回で戻る")
            d0 = await pg.inner_html("#deafen"); await pg.click("#deafen"); d1 = await pg.inner_html("#deafen"); await pg.click("#deafen")
            ok(d0 != d1 and "F23F43" in d1, "スピーカーミュート: 斜線付きヘッドホン（赤）に切り替わる")
            # ⌄ でチャンネル一覧
            await pg.click("#collapse")
            txt = await pg.inner_text("#members")
            ok("近接VC待機所" in txt and "部屋20" in txt and "むいいむ" in txt and "見学の人" in txt, "⌄でチャンネル一覧（待機所・部屋20・メンバー）")
            await pg.click("#collapse")
            ok(await pg.is_visible("#tiles") and not await pg.is_visible("#listView"), "もう一度⌄でタイルに戻る")
            # 3. 声が送られている（偽マイクの音）
            await pg.wait_for_timeout(1500)
            sent = await pg.evaluate("window.__sent")
            ok(any(s.startswith("[binary 640") for s in sent), "マイクの声が送られている（40msごとの音声）")
            # 4. オーナーを渡す
            pg.once("dialog", lambda d: asyncio.ensure_future(d.accept()))
            await pg.click("#giveOwner")
            ok(await pg.is_visible("#ownerPick"), "渡す相手の一覧が出る")
            names = await pg.inner_text("#ownerList")
            ok("むいいむ" in names and "見学の人" in names and "サブ垢" not in names, "一覧に自分以外のメンバー（呼び名）が出る")
            await pg.click("#ownerList button:has-text('むいいむ')")
            await pg.wait_for_timeout(300)
            sent = await pg.evaluate("window.__sent")
            ok(any('"giveOwner"' in s and '"id":1' in s for s in sent), "giveOwner(id=1) が送られる")
            await pg.evaluate("window.__sockets[0]._recv({t:'owner', host:false, ownerName:'むいいむ'})")
            await pg.wait_for_timeout(300)
            ok(not await pg.is_visible("#giveOwner"), "渡したら「オーナーを渡す」が消える")
            ok("むいいむ" in await pg.inner_text("#status"), "「オーナーが むいいむ に変わった」と出る")
            # 5. 部屋に移動（マイクラ連携後）
            await pg.evaluate("""() => { const w=window.__sockets[0];
              w._recv({t:'pos', p:{gopura777:{x:0,y:64,z:0,d:0,r:0}, saradayou509:{x:3,y:64,z:0,d:0,r:0}}});
              w._recv({t:'members', mc:true, list:[{id:1,name:'むいいむ',mc:'gopura777',host:true,slot:1},{id:2,name:'サブ垢',mc:'saradayou509',host:false,slot:2},{id:3,name:'見学の人',mc:'',host:false,slot:0}]}); }""")
            await pg.wait_for_timeout(400)
            ok("部屋2" in await pg.inner_text("#roomLabel"), "上の札が「部屋2」になる")
            tiles = await pg.inner_text("#tiles")
            ok("サブ垢" in tiles and "むいいむ" in tiles and "見学の人" in tiles, "タイルは通話にいる人がずっと出る（出たり消えたりしない）: " + tiles.replace(chr(10)," | "))
            import re as _re
            ok(not _re.search(r"\dm", tiles) and "聞こえ" not in tiles, "タイルに距離（○m）や「聞こえない」は出ない・名前だけ")
            order1 = await pg.evaluate("[...document.querySelectorAll('#tiles .chip')].map(e=>e.textContent)")
            await pg.evaluate("window.__sockets[0]._recv({t:'pos', p:{gopura777:{x:0,y:64,z:0,d:0,r:0}, saradayou509:{x:30,y:64,z:0,d:0,r:0}}})")
            await pg.wait_for_timeout(200)
            order2 = await pg.evaluate("[...document.querySelectorAll('#tiles .chip')].map(e=>e.textContent)")
            ok(order1 == order2, "離れてもタイルの並びは変わらない")
            await pg.evaluate("window.__sockets[0]._recv({t:'pos', p:{gopura777:{x:0,y:64,z:0,d:0,r:0}, saradayou509:{x:3,y:64,z:0,d:0,r:0}}})")
            # 聞こえる距離: 6ブロックくらいでやっと聞こえる、近いとふつうの声
            g = await pg.evaluate("[2,3,6,7,8,25].map(d => { var r = (function(){ var FULL=2, MAX=7.5; return d<=FULL?1:d>=MAX?0:Math.pow((MAX-d)/(MAX-FULL),2); })(); return r; })")
            ok(g[0] == 1 and g[1] > 0.6 and 0.03 < g[2] < 0.15 and g[3] < 0.02 and g[4] == 0 and g[5] == 0, "聞こえ方: 2ブロック=ふつう、6ブロック=小さく、8ブロック以上=聞こえない " + str([round(x,3) for x in g]))
            # チャットの読み上げ（近い人だけ、近いほど大きく）
            await pg.evaluate("() => { window.__spoken=[]; window.speechSynthesis.speak = (u) => { window.__spoken.push([u.text, u.volume, u.lang]); }; }")
            await pg.evaluate("""() => { const w=window.__sockets[0];
              w._recv({t:'chat', mc:'gopura777', text:'こんにちは', p:{x:0,y:64,z:0,d:0,r:0}});
              w._recv({t:'chat', mc:'遠い人', text:'とおいよ', p:{x:20,y:64,z:0,d:0,r:0}});
              w._recv({t:'chat', mc:'ぎりぎり', text:'ぎりぎり', p:{x:9,y:64,z:0,d:0,r:0}});
              w._recv({t:'chat', mc:'ネザー', text:'ちがう世界', p:{x:3,y:64,z:0,d:1,r:0}});
              w._recv({t:'chat', mc:'gopura777', text:'位置なし' }); }""")
            spoken = await pg.evaluate("window.__spoken")
            texts = [x[0] for x in spoken]
            ok("こんにちは" in texts and "とおいよ" not in texts and "ちがう世界" not in texts, "チャット読み上げ: 近い人だけ（遠い人・別の世界は読まない）: " + str(spoken))
            v = {x[0]: x[1] for x in spoken}
            ok(v.get("こんにちは", 0) > 0.6 and 0.02 <= v.get("ぎりぎり", 0) < 0.15, "近いと大きく、6ブロックくらいだと小さく読む: " + str(v))
            ok(v.get("位置なし", 0) > 0.6 and all(x[2] == "ja-JP" for x in spoken), "位置がなくても通話の人ならその人の位置で読む・日本語で読む")
            await pg.click("#deafen")
            await pg.evaluate("() => { window.__spoken=[]; window.__sockets[0]._recv({t:'chat', mc:'gopura777', text:'聞こえないはず', p:{x:0,y:64,z:0,d:0,r:0}}); }")
            ok(await pg.evaluate("window.__spoken.length") == 0, "スピーカーミュート中は読み上げない")
            await pg.click("#deafen")
            await pg.click("#collapse")
            txt = await pg.inner_text("#members")
            i1 = txt.index("部屋1"); i2 = txt.index("部屋2"); i3 = txt.index("部屋3")
            ok("むいいむ" in txt[i1:i2] and "サブ垢" in txt[i2:i3], "むいいむは部屋1、サブ垢は部屋2に表示")
            ok("見学の人" in txt[:i1], "マイクラの名前なしの人は待機所に表示")
            ok(not _re.search(r"\dm", txt) and "聞こえない" not in txt, "チャンネル一覧も名前だけ（距離・聞こえないの文字なし）")
            ok("部屋2 にいるよ" in await pg.inner_text("#mc"), "「部屋2 にいるよ」と出る（状態カードに表示）")
            await pg.click("#collapse")
            # 6. 相手の声が届いたら再生される（エラーなく）
            await pg.evaluate("window.__sockets[0]._recvBin([1].concat(Array(640).fill(0x80)))")
            await pg.wait_for_timeout(300)
            ok(not errors, "ページのエラーなし " + str(errors))
            ids = await pg.evaluate("() => { const all=[...document.querySelectorAll('[id]')].map(e=>e.id); return all.filter((x,i)=>all.indexOf(x)!==i); }")
            ok(not ids, "同じIDの重複なし " + str(ids))
            await pg.screenshot(path="/tmp/webtest/e2e.png", full_page=True)
            # 7. 退出するとチャンネル一覧に戻る（名前は覚えている）
            await pg.click("#leave")
            await pg.wait_for_timeout(200)
            ok(await pg.is_visible("#setup") and not await pg.is_visible("#namePanel"), "退出するとチャンネル一覧に戻る")
            # 入る前の画面: 右上のシェアはだれでも、「オーナーを渡す」はオーナーだけ
            gave = []
            state = {"isOwner": False, "hasOwner": True, "ownerName": "むいいむ", "members": []}
            async def api_state(route):
                await route.fulfill(status=200, content_type="application/json", body=__import__("json").dumps(state))
            async def api_give(route):
                gave.append((route.request.method, route.request.url)); state["isOwner"] = False; state["ownerName"] = "サブ垢"; state["members"] = []
                await route.fulfill(status=200, content_type="application/json", body='{"ok":true}')
            await pg.route("**/api/state*", api_state); await pg.route("**/api/give*", api_give)
            await pg.wait_for_timeout(4500)
            ok(await pg.is_visible("#shareLobby"), "入る前の画面の右上にシェアボタン（だれでも）")
            ok(not await pg.is_visible("#giveOwnerLobby") and "オーナー: むいいむ" in await pg.inner_text("#lobbyOwner"), "オーナーじゃない人には「オーナーを渡す」が出ない・だれがオーナーか出る")
            state.update({"isOwner": True, "ownerName": "サブ垢", "members": [{"id": 7, "name": "見学の人"}]})
            await pg.wait_for_timeout(4500)
            ok(await pg.is_visible("#giveOwnerLobby") and "あなたがオーナー" in await pg.inner_text("#lobbyOwner"), "オーナーには入る前の画面の右上に「オーナーを渡す」")
            await pg.click("#giveOwnerLobby")
            ok("見学の人" in await pg.inner_text("#lobbyList"), "渡す相手（今通話にいる人）が出る")
            pg.once("dialog", lambda d: asyncio.ensure_future(d.accept()))
            await pg.click("#lobbyList button")
            await pg.wait_for_timeout(500)
            ok(gave and gave[0][0] == "POST" and "id=7" in gave[0][1] and "dev=web-" in gave[0][1], "POST /api/give で渡す: " + str(gave))
            await pg.wait_for_timeout(300)
            ok(not await pg.is_visible("#giveOwnerLobby"), "渡したら「オーナーを渡す」が消える")
            # 8. Android のブラウザで開いたら、アプリを開く画面になる（名前の画面は出ない）
            actx = await b.new_context(user_agent="Mozilla/5.0 (Linux; Android 14) Chrome/120 Mobile")
            ap = await actx.new_page()
            await ap.add_init_script(FAKE_WS)
            await actx.grant_permissions(["microphone"])
            await ap.route("**/*", lambda route: route.continue_() if "localhost" in route.request.url else route.abort())
            await ap.goto("http://localhost:8765/index.html?room=MUIIMU")
            await ap.wait_for_timeout(100)
            ok(await ap.is_visible("#android") and not await ap.is_visible("#namePanel") and not await ap.is_visible("#setup"), "Androidでは最初に選ぶ画面が出る")
            ok(not await ap.is_visible("#openApp") and await ap.is_visible("#dlApk") and await ap.is_visible("#useBrowser"), "Androidでも「ブラウザ」「アプリ」が出る")
            await ap.wait_for_timeout(800)
            ok(ap.url.startswith("http://localhost"), "勝手にアプリへ飛ばない（選べる）")
            await ap.click("#useBrowser")
            ok(await ap.is_visible("#namePanel") and not await ap.is_visible("#android"), "「ブラウザで使う」で名前を決める画面になる")
            await ap.fill("#displayName", "スマホの人"); await ap.click("#setName"); await ap.click("#chLobby"); await ap.click("#join")
            await ap.wait_for_timeout(600)
            ok(await ap.is_visible("#mute") and await ap.is_visible("#leave"), "Androidのブラウザでも通話画面に入れる")
            # シェア = リンクをコピーするだけ（シェア画面は出さない）
            await ap.evaluate("""() => { window.__shared=null; window.__copied=null;
              navigator.share = (d) => { window.__shared = d.text; return Promise.resolve(); };
              Object.defineProperty(navigator, 'clipboard', { configurable: true, value: { writeText: (t) => { window.__copied = t; return Promise.resolve(); } } }); }""")
            await ap.click("#shareTop")
            await ap.wait_for_timeout(200)
            copied = await ap.evaluate("window.__copied") or ""
            ok(await ap.evaluate("window.__shared") is None, "シェアボタンでシェア画面は出さない")
            ok("http://localhost:8765/" in copied and copied.count("http") == 1 and ".apk" not in copied, "リンクをコピーする: " + copied.replace(chr(10), " "))
            ok(await ap.is_visible("#copied") and "コピーしたよ" in await ap.inner_text("#status"), "「コピーしたよ」と出る")
            await ap.click("#invite"); await ap.wait_for_timeout(200)
            ok((await ap.evaluate("window.__copied") or "") == copied, "「メンバーを追加」でも同じリンクをコピー")
            # 「ブラウザ」を押した瞬間にブラウザで使える（ページ移動なし）
            ok(ap.url.startswith("http://localhost"), "「ブラウザ」を押してもページは移動しない")
            # マイクが使えないブラウザでも「聞くだけ」で入れる
            nctx = await b.new_context()
            np_ = await nctx.new_page()
            await np_.add_init_script(FAKE_WS)
            await np_.add_init_script("Object.defineProperty(navigator, 'mediaDevices', { configurable: true, value: undefined });")
            await np_.goto("http://localhost:8765/index.html")
            await np_.click("#useBrowser"); await np_.fill("#displayName", "Discordの中"); await np_.click("#setName"); await np_.click("#chLobby"); await np_.click("#join")
            await np_.wait_for_timeout(600)
            ok(await np_.is_visible("#leave") and await np_.evaluate("window.__sockets.length") >= 1, "マイクが使えないブラウザでも通話に入れる（聞くだけ）")
            ok("聞くだけ" in await np_.inner_text("#status") and "Chrome" in await np_.inner_text("#status"), "どうすればいいか表示: " + await np_.inner_text("#status"))
            # マイクを拒否しても入れる
            dctx = await b.new_context()
            dp = await dctx.new_page()
            await dp.add_init_script(FAKE_WS)
            await dp.add_init_script("navigator.mediaDevices.getUserMedia = () => Promise.reject(Object.assign(new Error('x'), {name:'NotAllowedError'}));")
            await dp.goto("http://localhost:8765/index.html")
            await dp.click("#useBrowser"); await dp.fill("#displayName", "拒否した人"); await dp.click("#setName"); await dp.click("#chLobby"); await dp.click("#join")
            await dp.wait_for_timeout(600)
            ok(await dp.is_visible("#leave") and "許可" in await dp.inner_text("#status"), "マイクを拒否しても入れて、許可のしかたが出る")
            # AudioWorklet がない古いブラウザでも入れる（マイクあり）
            octx = await b.new_context(permissions=["microphone"])
            op = await octx.new_page()
            await op.add_init_script(FAKE_WS)
            await op.add_init_script("window.AudioWorkletNode = undefined;")
            await op.goto("http://localhost:8765/index.html")
            await op.click("#useBrowser"); await op.fill("#displayName", "古いスマホ"); await op.click("#setName"); await op.click("#chLobby"); await op.click("#join")
            await op.wait_for_timeout(1500)
            osent = await op.evaluate("window.__sent")
            ok(await op.is_visible("#leave") and "聞くだけ" not in await op.inner_text("#status") and any(x.startswith("[binary 640") for x in osent), "AudioWorkletがない古いブラウザでも声が送れる")
            # 声がちゃんと鳴る（届いた声を再生している・音量1）
            hctx = await b.new_context(permissions=["microphone"])
            hp = await hctx.new_page()
            await hp.add_init_script(FAKE_WS)
            await hp.add_init_script("""window.__played=0; window.__peak=0; const _st=AudioBufferSourceNode.prototype.start;
              AudioBufferSourceNode.prototype.start=function(){ window.__played++; try{ const d=this.buffer.getChannelData(0); for(let i=0;i<d.length;i++) window.__peak=Math.max(window.__peak,Math.abs(d[i])); }catch(e){} return _st.apply(this,arguments); };""")
            await hp.goto("http://localhost:8765/index.html")
            await hp.click("#useBrowser"); await hp.fill("#displayName", "聞く人"); await hp.click("#setName"); await hp.click("#chLobby"); await hp.click("#join")
            await hp.wait_for_timeout(500)
            await hp.evaluate("""() => { const w=window.__sockets[0];
              w._recv({t:'hello', id:5, host:false});
              w._recv({t:'members', mc:false, list:[{id:5,name:'聞く人',mc:'聞く人'},{id:2,name:'話す人',mc:'話す人'}]});
              let n=0; const f=()=>{ if(n++<25){ w._recvBin([2].concat(Array(640).fill(0x10))); setTimeout(f,40);} }; f(); }""")
            await hp.wait_for_timeout(500)
            talk_green = await hp.evaluate("document.querySelector('.tile.talk') !== null")
            await hp.wait_for_timeout(1000)
            played = await hp.evaluate("window.__played"); peak = await hp.evaluate("window.__peak")
            ok(played >= 20 and peak > 0.3, f"ブラウザで相手の声を再生している（{played}回・音の大きさ {peak:.2f}）")
            ok(talk_green, "話している人のタイルが緑になる")
            # iPhone: マナーモードでも鳴るように <audio> を通して鳴らす
            ictx = await b.new_context(permissions=["microphone"], user_agent="Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1")
            ip = await ictx.new_page()
            await ip.add_init_script(FAKE_WS)
            await ip.goto("http://localhost:8765/index.html")
            await ip.click("#useBrowser"); await ip.fill("#displayName", "iPhoneの人"); await ip.click("#setName"); await ip.click("#chLobby"); await ip.click("#join")
            await ip.wait_for_timeout(800)
            ok(await ip.evaluate("(() => { const a=document.getElementById('voiceOut'); return !!a.srcObject && !a.paused; })()"), "iPhoneでは<audio>で鳴らす（マナーモード対策）")
            # 退出すると止まる
            await ip.click("#leave"); await ip.wait_for_timeout(200)
            ok(await ip.evaluate("document.getElementById('voiceOut').srcObject === null"), "退出すると<audio>も止まる")
            await b.close()
    finally:
        srv.terminate()
    print("ALL OK" if not fails else f"FAILED {len(fails)}")
asyncio.run(main())
