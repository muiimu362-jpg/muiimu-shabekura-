import com.muiimu.shabekura.*
fun main() {
    var fails = 0
    fun ok(c: Boolean, m: String) { if (!c) { fails++; println("FAIL: $m") } }
    // 統合版のチャットイベント（新しい形: eventName が header）
    val a = """{"body":{"message":"こんにちは","receiver":"","sender":"Sarada Gamer12","type":"chat"},"header":{"eventName":"PlayerMessage","messagePurpose":"event","version":17039360}}"""
    ok(BridgeLogic.parseChat(a) == ("Sarada Gamer12" to "こんにちは"), "新しい形のチャット")
    // 古い形: eventName が body
    val b = """{"body":{"eventName":"PlayerMessage","properties":{},"message":"hi","sender":"gopura777","type":"chat"},"header":{"messagePurpose":"event","version":1}}"""
    ok(BridgeLogic.parseChat(b) == ("gopura777" to "hi"), "古い形のチャット")
    // 読まないもの
    ok(BridgeLogic.parseChat(a.replace("\"type\":\"chat\"", "\"type\":\"tell\"")) == null, "ささやき(tell)は読まない")
    ok(BridgeLogic.parseChat(a.replace("こんにちは", "/tp @s ~ ~ ~")) == null, "コマンドは読まない")
    ok(BridgeLogic.parseChat(a.replace("\"type\":\"chat\"", "\"type\":\"tellraw\"")) == null, "アプリのあいさつ(tellraw)は読まない")
    ok(BridgeLogic.parseChat(a.replace("Sarada Gamer12", "外部")) == null, "外部(コマンド)は読まない")
    ok(BridgeLogic.parseChat(a.replace("PlayerMessage", "PlayerTravelled")) == null, "ほかのイベントは読まない")
    ok(BridgeLogic.parseChat("""{"header":{"messagePurpose":"commandResponse","requestId":"x"},"body":{"statusCode":0}}""") == null, "コマンドの返事は読まない")
    ok(BridgeLogic.parseChat("こわれた") == null, "こわれた文字でも落ちない")
    ok(BridgeLogic.parseChat(a.replace("こんにちは", "あ".repeat(300)))!!.second.length == 120, "長すぎる文は120文字まで")
    // 申し込み
    val sub = BridgeLogic { "id1" }.subscribeChat()
    ok(sub.contains("\"messagePurpose\":\"subscribe\"") && sub.contains("\"eventName\":\"PlayerMessage\""), "チャットの申し込み")
    // 聞こえる距離
    fun g(d: Double) = Spatial.compute(Pos(0.0, 64.0, 0.0, 0, 0.0), Pos(d, 64.0, 0.0, 0, 0.0)).first
    ok(g(1.0) == 1f && g(2.0) == 1f, "2ブロックまでふつうの声")
    ok(g(3.0) > 0.6f, "3ブロックは大きめ")
    ok(g(6.0) in 0.03f..0.15f, "6ブロックでやっと聞こえる: ${g(6.0)}")
    ok(g(8.0) == 0f && g(25.0) == 0f, "8ブロック以上は聞こえない")
    println(if (fails == 0) "ALL OK" else "FAILED $fails")
}
