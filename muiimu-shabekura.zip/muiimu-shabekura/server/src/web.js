// iPhone・PC 用の Web 版（サーバーから配る）
// 注意: このファイルの中のスクリプトではバッククォートと「ドル記号+波かっこ」を使わないこと
// Android 用 APK の直接ダウンロード先（GitHub のリリース）
const APK_URL = "https://github.com/muiimu362-jpg/muiimu-shabekura-/releases/latest/download/MuiimuShabekura.apk";
const WEB_HTML_RAW = `<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="しゃべくら">
<meta name="theme-color" content="#2E5E2A">
<link rel="manifest" href="/manifest.json">
<link rel="apple-touch-icon" href="/icon.svg">
<title>むいいむ しゃべくら</title>
<style>
  * { box-sizing: border-box; }
  body { margin:0; background:#2B2D31; color:#DBDEE1;
    font-family: -apple-system, "Hiragino Sans", "Noto Sans JP", sans-serif; }
  main { max-width: 480px; margin: 0 auto; padding: 20px 16px calc(24px + env(safe-area-inset-bottom)); }
  h1 { color:#F2F3F5; font-size:22px; margin:8px 0 2px; }
  .sub { color:#80848E; font-size:12px; margin-bottom:14px; }
  label { display:block; color:#B5BAC1; font-weight:700; font-size:12px; margin-top:16px; }
  input { width:100%; font-size:16px; padding:12px; border:0; border-radius:6px; margin-top:6px; background:#1E1F22; color:#F2F3F5; }
  button { width:100%; font-size:15px; padding:13px; border:0; border-radius:8px; margin-top:10px;
    background:#5865F2; color:#fff; font-weight:700; }
  button.sec { background:#383A40; color:#DBDEE1; font-weight:500; }
  button.red { background:#DA373C; color:#fff; }
  .row { display:flex; gap:6px; } .row button { flex:1; font-size:12px; padding:12px 2px; white-space:nowrap; }
  .room { font-size:16px; font-weight:700; color:#F2F3F5; }
  .mc { margin-top:8px; padding:12px; border-radius:8px; background:#232428; font-size:13px; line-height:1.6; }
  .ch { padding:7px 8px; font-size:15px; color:#80848E; border-radius:6px; }
  .ch.has { color:#F2F3F5; } .ch.mine { background:#404249; color:#F2F3F5; }
  .ch .cnt { float:right; font-size:12px; color:#80848E; }
  .mem { padding:3px 8px 3px 40px; font-size:14px; color:#DBDEE1; }
  .mem.talk { color:#23A55A; font-weight:700; }
  #status { color:#949BA4; margin-top:16px; min-height:1.2em; }
  .note { color:#6D6F78; font-size:12px; margin-top:12px; line-height:1.6; }
  .hidden { display:none !important; }
  .topbar { display:flex; align-items:center; gap:8px; }
  .ib { width:44px; height:44px; padding:10px; margin:0; border-radius:14px; background:#1E1F22; flex:none; }
  .ib svg, .bb svg { width:100%; height:100%; }
  .pill { height:44px; line-height:44px; padding:0 14px; border-radius:14px; background:#1E1F22; color:#F2F3F5; font-weight:700; font-size:17px; cursor:pointer; white-space:nowrap; }
  .ownerbtn { width:auto; height:44px; margin:0; padding:0 12px; border-radius:14px; background:#1E1F22; color:#F0B232; font-size:12px; }
  .subline { color:#B5BAC1; font-size:12px; margin-top:8px; white-space:pre-line; }
  #tiles { margin-top:12px; display:grid; grid-template-columns:1fr 1fr; gap:10px; }
  .tile { background:#45474C; border-radius:20px; display:flex; flex-direction:column; align-items:center; justify-content:center; height:180px; border:3px solid transparent; }
  .tile.one { grid-column:1 / span 2; height:360px; } .tile.wide { grid-column:1 / span 2; height:220px; }
  .tile.talk { border-color:#23A55A; }
  .av { width:72px; height:72px; border-radius:50%; display:flex; align-items:center; justify-content:center; color:#fff; font-weight:700; font-size:28px; }
  .tile.one .av { width:110px; height:110px; font-size:44px; }
  .chip { margin-top:14px; background:rgba(17,18,20,.9); color:#F2F3F5; font-weight:700; font-size:15px; padding:6px 14px; border-radius:12px; }
  .tile.talk .chip { color:#23A55A; }
  .empty { grid-column:1 / span 2; color:#80848E; padding:40px 8px; }
  .invite { display:flex; align-items:center; margin-top:16px; padding:16px; border-radius:22px; background:#0B0C0E; cursor:pointer; }
  .bar { display:flex; gap:12px; margin-top:14px; padding:12px; border-radius:22px; background:#1E1F22; border:1px solid #3A3C42; }
  .bb { flex:1; height:60px; margin:0; padding:14px; border-radius:14px; background:#2B2D31; }
  .bb.red { background:#DA373C; border-radius:18px; }
</style>
</head>
<body>
<main>
  <h1>むいいむ しゃべくら</h1>
  <div class="sub">むいいむ通話 ・ 近づくと聞こえるボイスチャット（Web版）</div>

  <section id="android" class="hidden">
    <div class="room" id="aRoom"></div>
    <div style="color:#F2F3F5;font-weight:700;font-size:18px;margin-top:14px">どっちで入る？</div>
    <button id="openApp">📱 アプリで開く</button>
    <a id="dlApk" href="__APK_URL__"><button class="sec">⬇ アプリを入れる（初めての人）</button></a>
    <button id="useBrowser" class="sec">🌐 ブラウザでこのまま使う</button>
    <div class="note">
      ・アプリが入っていれば「アプリで開く」で、ルームコード入りでアプリが開きます。<br>
      ・入っていない人は「アプリを入れる」→ ダウンロードしたファイルを開いてインストール →もう一度このページの「アプリで開く」を押してね。<br>
      ・インストール時に「提供元不明のアプリ」の許可を聞かれたら許可してください。<br>
      ・アプリを入れたくない人は「ブラウザでこのまま使う」でOK。ただしブラウザは画面を消したり別のアプリに切り替えると声が止まりやすいので、アプリのほうが安定するよ。
    </div>
  </section>

  <section id="namePanel" class="hidden">
    <div class="mc" style="margin-top:20px">
      <div style="color:#F2F3F5;font-weight:700;font-size:18px">名前を決めてください</div>
      <div class="note" style="margin-top:4px">マイクラの名前じゃなくてOK。みんなに表示される名前だよ</div>
      <input id="displayName" autocomplete="off" placeholder="例: むいいむ">
      <button id="setName">決定</button>
    </div>
  </section>

  <section id="setup" class="hidden">
    <div class="topbar">
      <div id="lobbyOwner" style="flex:1;color:#949BA4;font-size:12px;padding-left:6px"></div>
      <button id="shareLobby" class="ib"><svg viewBox="0 0 24 24"><path fill="#fff" d="M15,12c2.21,0 4,-1.79 4,-4s-1.79,-4 -4,-4 -4,1.79 -4,4 1.79,4 4,4zM6,10V7H4v3H1v2h3v3h2v-3h3v-2H6zM15,14c-2.67,0 -8,1.34 -8,4v2h16v-2c0,-2.66 -5.33,-4 -8,-4z"/></svg></button>
      <button id="giveOwnerLobby" class="ownerbtn hidden">👑 オーナーを渡す</button>
    </div>
    <div id="lobbyPick" class="mc hidden">
      <div style="color:#F2F3F5;font-weight:700">👑 だれにオーナーを渡す？</div>
      <div id="lobbyList"></div>
      <button id="lobbyCancel" class="sec">やめる</button>
    </div>
    <div id="myNameLabel" style="color:#B5BAC1;font-size:13px;padding:6px;cursor:pointer"></div>
    <label>ボイスチャンネル</label>
    <div class="ch mine" id="chLobby" style="cursor:pointer">🔊  🎤▮近接VC待機所　（タップして入る）</div>
    <div class="mc hidden" id="joinForm">
      <div style="color:#F2F3F5;font-weight:700;font-size:15px">マイクラの名前（サブの名前）</div>
      <div class="note" style="margin-top:2px">入れるとマイクラと連携して、近くの人の声が聞こえるよ。なくてもOK（待機所でふつうに話せる）。Switch・PS の人は、そのマイクラで表示される名前をそのまま入れてね</div>
      <input id="mcName" autocomplete="off" autocapitalize="off" placeholder="例: gopura777（なくてもOK）">
      <input id="room" type="hidden">
      <button id="join">入る</button>
    </div>
    <div id="roomsPreview"></div>
  </section>

  <section id="call" class="hidden">
    <div class="topbar">
      <button id="collapse" class="ib"><svg viewBox="0 0 24 24"><path fill="#fff" d="M16.59,8.59L12,13.17 7.41,8.59 6,10l6,6 6,-6z"/></svg></button>
      <div class="pill" id="roomLabel"></div>
      <div style="flex:1"></div>
      <button id="shareTop" class="ib"><svg viewBox="0 0 24 24"><path fill="#fff" d="M15,12c2.21,0 4,-1.79 4,-4s-1.79,-4 -4,-4 -4,1.79 -4,4 1.79,4 4,4zM6,10V7H4v3H1v2h3v3h2v-3h3v-2H6zM15,14c-2.67,0 -8,1.34 -8,4v2h16v-2c0,-2.66 -5.33,-4 -8,-4z"/></svg></button>
      <button id="giveOwner" class="ownerbtn hidden">👑 オーナーを渡す</button>
    </div>
    <div id="ownerPick" class="mc hidden">
      <div style="color:#F2F3F5;font-weight:700">👑 だれにオーナーを渡す？</div>
      <div id="ownerList"></div>
      <button id="ownerCancel" class="sec">やめる</button>
    </div>
    <div class="subline" id="sub"></div>
    <div id="tiles"></div>
    <div id="listView" class="hidden">
      <div class="mc" id="mc"></div>
      <label>ボイスチャンネル</label>
      <div id="members"></div>
      <button id="optout" class="sec hidden">通話を抜ける</button>
    </div>
    <div class="invite" id="invite"><svg style="width:30px;height:30px;flex:none" viewBox="0 0 24 24"><path fill="#fff" d="M15,12c2.21,0 4,-1.79 4,-4s-1.79,-4 -4,-4 -4,1.79 -4,4 1.79,4 4,4zM6,10V7H4v3H1v2h3v3h2v-3h3v-2H6zM15,14c-2.67,0 -8,1.34 -8,4v2h16v-2c0,-2.66 -5.33,-4 -8,-4z"/></svg>
      <div style="flex:1;margin-left:14px"><div style="color:#F2F3F5;font-weight:700;font-size:16px">ボイスチャットにメンバーを追加</div>
      <div style="color:#949BA4;font-size:12px">アプリをシェアして、配信をもっと盛り上げよう！</div></div>
      <div style="color:#949BA4;font-size:24px">›</div>
    </div>
    <div class="bar">
      <button id="deafen" class="bb"></button>
      <button id="mute" class="bb"></button>
      <button id="leave" class="bb red" style="flex:1.2"><svg viewBox="0 0 24 24"><path fill="#fff" d="M12,9c-1.6,0 -3.15,0.25 -4.6,0.72v3.1c0,0.39 -0.23,0.74 -0.56,0.9 -0.98,0.49 -1.87,1.12 -2.66,1.85 -0.18,0.18 -0.43,0.28 -0.7,0.28 -0.28,0 -0.53,-0.11 -0.71,-0.29L0.29,13.08c-0.18,-0.17 -0.29,-0.42 -0.29,-0.7 0,-0.28 0.11,-0.53 0.29,-0.71C3.34,8.78 7.46,7 12,7s8.66,1.78 11.71,4.67c0.18,0.18 0.29,0.43 0.29,0.71 0,0.28 -0.11,0.53 -0.29,0.71l-2.48,2.48c-0.18,0.18 -0.43,0.29 -0.71,0.29 -0.27,0 -0.52,-0.11 -0.7,-0.28 -0.79,-0.74 -1.69,-1.36 -2.67,-1.85 -0.33,-0.16 -0.56,-0.5 -0.56,-0.9v-3.1C15.15,9.25 13.6,9 12,9z"/></svg></button>
    </div>
  </section>

  <div id="status"></div>
  <div class="note" id="webNote">
    ・このページは開いたまま（画面をつけたまま）にしてね。別のアプリに切り替えると声が止まります。<br>
    ・iPhoneで同じ端末のマイクラを遊ぶ場合は声が止まるので、Switch・PS・PCで遊ぶときの「横に置く用」に使ってね。<br>
    ・Safariの共有ボタン →「ホーム画面に追加」でアプリみたいに使えます。<br>
    ・イヤホン推奨。
  </div>
</main>

<script>
(function () {
  var RATE = 16000, FRAME = 640, VAD_LEVEL = 280, VAD_HANG = 8;
  var FULL = 3, MAX = 24;
  function $(id) { return document.getElementById(id); }

  // ---- μ-law ----
  var DEC = new Float32Array(256);
  (function () {
    for (var u = 0; u < 256; u++) {
      var x = (~u) & 0xFF, sign = x & 0x80, e = (x >> 4) & 7, m = x & 0x0F;
      var mag = (((m << 3) + 0x84) << e) - 0x84;
      DEC[u] = (sign ? -mag : mag) / 32768;
    }
  })();
  function enc(s) {
    var sign = 0;
    if (s < 0) { s = -s; sign = 0x80; }
    if (s > 32635) s = 32635;
    s += 0x84;
    var e = 7, mask = 0x4000;
    while ((s & mask) === 0 && e > 0) { e--; mask >>= 1; }
    var m = (s >> (e + 3)) & 0x0F;
    return (~(sign | (e << 4) | m)) & 0xFF;
  }

  // ---- 状態 ----
  var ws = null, ctx = null, stream = null, running = false, retry = 0;
  var myName = "", myMc = "", room = "", muted = false, deafened = false, mySlot = 0, optOut = false, selfTalking = false, hang = 0;
  var members = {}, positions = {}, mcOn = false, lastPos = 0;
  var speakers = {};
  var inBuf = [], rpos = 0, frame = new Int16Array(FRAME), fpos = 0;
  var wakeLock = null;

  try {
    $("mcName").value = localStorage.getItem("mc") || "";
    $("room").value = localStorage.getItem("room") || "";
  } catch (e) {}
  var qp = new URLSearchParams(location.search).get("room");
  if (qp) $("room").value = qp.toUpperCase();

  // Android は「アプリで開く／アプリを入れる／ブラウザで使う」を選べる
  var ICON_MIC = '<svg viewBox="0 0 24 24"><path fill="#fff" d="M12,14c1.66,0 3,-1.34 3,-3V5c0,-1.66 -1.34,-3 -3,-3S9,3.34 9,5v6c0,1.66 1.34,3 3,3zM17.3,11c0,3 -2.54,5.1 -5.3,5.1S6.7,14 6.7,11H5c0,3.41 2.72,6.23 6,6.72V21h2v-3.28c3.28,-0.48 6,-3.3 6,-6.72h-1.7z"/></svg>', ICON_MICOFF = '<svg viewBox="0 0 24 24"><path fill="#F23F43" d="M19,11h-1.7c0,0.74 -0.16,1.43 -0.43,2.05l1.23,1.23c0.56,-0.98 0.9,-2.09 0.9,-3.28zM14.98,11.17c0,-0.06 0.02,-0.11 0.02,-0.17V5c0,-1.66 -1.34,-3 -3,-3S9,3.34 9,5v0.18l5.98,5.99zM4.27,3L3,4.27l6.01,6.01V11c0,1.66 1.33,3 2.99,3 0.22,0 0.44,-0.03 0.65,-0.08l1.66,1.66c-0.71,0.33 -1.5,0.52 -2.31,0.52 -2.76,0 -5.3,-2.1 -5.3,-5.1H5c0,3.41 2.72,6.23 6,6.72V21h2v-3.28c0.91,-0.13 1.77,-0.45 2.54,-0.9L19.73,21 21,19.73 4.27,3z"/></svg>', ICON_HEAD = '<svg viewBox="0 0 24 24"><path fill="#fff" d="M12,2C7.03,2 3,6.03 3,11v6.5C3,19.43 4.57,21 6.5,21H9v-8H5v-2c0,-3.87 3.13,-7 7,-7s7,3.13 7,7v2h-4v8h2.5c1.93,0 3.5,-1.57 3.5,-3.5V11c0,-4.97 -4.03,-9 -9,-9z"/></svg>', ICON_HEADOFF = '<svg viewBox="0 0 24 24"><path fill="#F23F43" d="M12,2C7.03,2 3,6.03 3,11v6.5C3,19.43 4.57,21 6.5,21H9v-8H5v-2c0,-3.87 3.13,-7 7,-7s7,3.13 7,7v2h-4v8h2.5c1.93,0 3.5,-1.57 3.5,-3.5V11c0,-4.97 -4.03,-9 -9,-9z"/><path stroke="#1E1F22" stroke-width="4" stroke-linecap="round" d="M3.5,3.5L20.5,20.5"/><path stroke="#F23F43" stroke-width="2" stroke-linecap="round" d="M3.5,3.5L20.5,20.5"/></svg>';
  // ?web=1 のリンクは、Android でもアプリの画面を出さずにそのままブラウザで使う
  var forceWeb = new URLSearchParams(location.search).get("web") === "1";
  var androidPage = /Android/i.test(navigator.userAgent) && !forceWeb;
  if (androidPage) {
    var code = (qp || "").toUpperCase();
    var valid = /^[A-Z0-9]{6}$/.test(code);
    $("setup").classList.add("hidden");
    $("webNote").classList.add("hidden");
    $("android").classList.remove("hidden");
    $("aRoom").textContent = valid ? ("ルームコード: " + code) : "むいいむ通話";
    var apk = $("dlApk").getAttribute("href");
    var intentUrl = "intent://join" + (valid ? ("?room=" + code) : "") +
      "#Intent;scheme=shabekura;package=com.muiimu.shabekura;S.browser_fallback_url=" +
      encodeURIComponent(apk) + ";end";
    $("openApp").onclick = function () { location.href = intentUrl; };
    // ブラウザでそのまま使う
    $("useBrowser").onclick = function () {
      androidPage = false;
      $("android").classList.add("hidden");
      $("webNote").classList.remove("hidden");
      showStart();
    };
  }

  function setStatus(t) { $("status").textContent = t; }

  // このブラウザの端末ID（オーナーを覚えるのに使う）
  function deviceId() {
    var d = "";
    try { d = localStorage.getItem("dev") || ""; } catch (e) {}
    if (!d) {
      d = "web-" + Math.random().toString(36).slice(2) + Date.now().toString(36);
      try { localStorage.setItem("dev", d); } catch (e) {}
    }
    return d;
  }
  var isOwner = false;
  $("giveOwner").onclick = function () {
    var list = $("ownerList"); list.textContent = "";
    Object.keys(members).forEach(function (id) {
      var x = members[id];
      if (x.name === myName) return;
      var b = document.createElement("button"); b.className = "sec"; b.textContent = x.name;
      b.onclick = function () {
        if (!confirm("「" + x.name + "」にオーナーを渡すよ。渡したあとは、自分はふつうのメンバーになるよ。いい？")) return;
        if (ws && ws.readyState === 1) ws.send(JSON.stringify({ t: "giveOwner", id: Number(id) }));
        $("ownerPick").classList.add("hidden");
      };
      list.appendChild(b);
    });
    if (!list.childNodes.length) list.textContent = "ほかに入っている人がいないよ";
    $("ownerPick").classList.remove("hidden");
  };
  $("ownerCancel").onclick = function () { $("ownerPick").classList.add("hidden"); };

  // 入る前の画面: 右上のシェア（だれでも）と「オーナーを渡す」（オーナーだけ）
  var lobbyMembers = [], lobbyIsOwner = false;
  function lobbyRoom() { return ($("room").value || "MUIIMU").toUpperCase(); }
  function refreshLobbyOwner() {
    if ($("setup").classList.contains("hidden")) return;
    fetch("/api/state?room=" + encodeURIComponent(lobbyRoom()) + "&dev=" + encodeURIComponent(deviceId()), { cache: "no-store" })
      .then(function (r) { return r.json(); })
      .then(function (m) {
        lobbyIsOwner = !!m.isOwner; lobbyMembers = m.members || [];
        $("giveOwnerLobby").classList.toggle("hidden", !lobbyIsOwner);
        $("lobbyOwner").textContent = lobbyIsOwner ? "👑 あなたがオーナー" :
          m.ownerName ? ("👑 オーナー: " + m.ownerName) :
          !m.hasOwner ? "👑 まだオーナーなし（最初に入った人がオーナー）" : "";
      }).catch(function () {});
  }
  setInterval(refreshLobbyOwner, 4000);
  $("shareLobby").onclick = function () { shareApp(); };
  $("giveOwnerLobby").onclick = function () {
    var list = $("lobbyList"); list.textContent = "";
    lobbyMembers.forEach(function (x) {
      var b = document.createElement("button"); b.className = "sec"; b.textContent = x.name;
      b.onclick = function () {
        if (!confirm("「" + x.name + "」にオーナーを渡すよ。渡したあとは、自分はふつうのメンバーになるよ。いい？")) return;
        fetch("/api/give?room=" + encodeURIComponent(lobbyRoom()) + "&id=" + x.id + "&dev=" + encodeURIComponent(deviceId()), { method: "POST" })
          .then(function (r) { setStatus(r.ok ? ("「" + x.name + "」にオーナーを渡したよ") : "渡せなかった。もう一度やってみてね"); refreshLobbyOwner(); })
          .catch(function () { setStatus("渡せなかった。もう一度やってみてね"); });
        $("lobbyPick").classList.add("hidden");
      };
      list.appendChild(b);
    });
    if (!list.childNodes.length) list.textContent = "今、通話に入っている人がいないよ。渡したい人に先に入ってもらってね";
    $("lobbyPick").classList.remove("hidden");
  };
  $("lobbyCancel").onclick = function () { $("lobbyPick").classList.add("hidden"); };

  // 一番最初は「名前を決めてください」
  function savedName() { try { return localStorage.getItem("displayName") || ""; } catch (e) { return ""; } }
  function showStart() {
    if (androidPage) { $("namePanel").classList.add("hidden"); $("setup").classList.add("hidden"); return; }
    var n = savedName();
    $("namePanel").classList.toggle("hidden", !!n);
    $("setup").classList.toggle("hidden", !n);
    $("myNameLabel").textContent = "👤 " + n + "　（タップで名前を変える）";
    refreshLobbyOwner();
  }
  $("setName").onclick = function () {
    var n = $("displayName").value.trim();
    if (!n) { setStatus("名前を入れてね"); return; }
    try { localStorage.setItem("displayName", n); } catch (e) {}
    setStatus(""); showStart();
  };
  $("myNameLabel").onclick = function () {
    $("displayName").value = savedName();
    try { localStorage.removeItem("displayName"); } catch (e) {}
    showStart();
  };
  showStart();
  $("chLobby").onclick = function () { $("joinForm").classList.toggle("hidden"); $("mcName").focus(); };
  (function () {
    var box = $("roomsPreview");
    for (var r = 1; r <= 20; r++) { var d = document.createElement("div"); d.className = "ch"; d.textContent = "🔊  🎧▮部屋" + r; box.appendChild(d); }
  })();
  $("join").onclick = function () { join().catch(function (e) { setStatus("開始できませんでした: " + e.message); stop(); }); };
  $("leave").onclick = function () { stop(); setStatus("退出しました"); };
  $("mute").onclick = function () { muted = !muted; render(); };
  var showList = false;
  $("collapse").onclick = $("roomLabel").onclick = function () { showList = !showList; render(); };
  function shareApp() {
    var text = "むいいむ通話に来てね！名前を決めて「近接VC待機所」をタップ →「入る」だけ！（マイクラの名前を入れると近接ボイスになるよ）\\n" +
      "🌐 ブラウザで入る（ダウンロードなし）: " + location.origin + "/?web=1\\n" +
      "📱 アプリで入る・アプリを入れる: " + location.origin + "/";
    if (navigator.share) { navigator.share({ title: "むいいむ しゃべくら", text: text }).catch(function () {}); }
    else { try { navigator.clipboard.writeText(text); setStatus("招待メッセージをコピーしたよ"); } catch (e) {} }
  }
  $("shareTop").onclick = $("invite").onclick = shareApp;
  $("optout").onclick = function () {
    optOut = !optOut;
    if (ws && ws.readyState === 1) ws.send(JSON.stringify({ t: "optout", on: optOut }));
    render();
  };
  $("deafen").onclick = function () {
    deafened = !deafened;
    for (var id in speakers) speakers[id].next = 0;
    render();
  };

  async function join() {
    myName = savedName().trim();
    myMc = $("mcName").value.trim();
    room = ($("room").value.trim().toUpperCase()) || "MUIIMU";
    if (!myName) { showStart(); setStatus("先に名前を決めてね"); return; }
    if (!/^[A-Z0-9]{6}$/.test(room)) room = "MUIIMU";
    try { localStorage.setItem("mc", myMc); localStorage.setItem("room", room); } catch (e) {}

    try { if (navigator.audioSession) navigator.audioSession.type = "play-and-record"; } catch (e) {}
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    await ctx.resume();
    stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 }
    });
    var code = "class C extends AudioWorkletProcessor{process(i){var c=i[0]&&i[0][0];if(c)this.port.postMessage(c.slice(0));return true}}registerProcessor('cap',C);";
    await ctx.audioWorklet.addModule(URL.createObjectURL(new Blob([code], { type: "application/javascript" })));
    var src = ctx.createMediaStreamSource(stream);
    var node = new AudioWorkletNode(ctx, "cap");
    var sink = ctx.createGain(); sink.gain.value = 0;
    src.connect(node); node.connect(sink); sink.connect(ctx.destination);
    node.port.onmessage = function (e) { onMic(e.data); };

    running = true; retry = 0;
    $("setup").classList.add("hidden");
    $("call").classList.remove("hidden");
    keepAwake();
    connect();
    render();
  }

  function onMic(chunk) {
    var ratio = ctx.sampleRate / RATE;
    for (var i = 0; i < chunk.length; i++) inBuf.push(chunk[i]);
    while (rpos + 1 < inBuf.length) {
      var k = Math.floor(rpos), t = rpos - k;
      var v = inBuf[k] * (1 - t) + inBuf[k + 1] * t;
      frame[fpos++] = Math.max(-32768, Math.min(32767, Math.round(v * 32767)));
      rpos += ratio;
      if (fpos === FRAME) { fpos = 0; onFrame(); }
    }
    var drop = Math.floor(rpos);
    if (drop > 0) { inBuf = inBuf.slice(drop); rpos -= drop; }
  }

  function onFrame() {
    var sum = 0;
    for (var i = 0; i < FRAME; i++) sum += frame[i] * frame[i];
    var rms = Math.sqrt(sum / FRAME);
    if (rms > VAD_LEVEL) hang = VAD_HANG; else if (hang > 0) hang--;
    selfTalking = !muted && !deafened && hang > 0;
    if (!selfTalking || optOut || !ws || ws.readyState !== 1) return;
    var out = new Uint8Array(FRAME);
    for (var j = 0; j < FRAME; j++) out[j] = enc(frame[j]);
    ws.send(out);
  }

  function connect() {
    if (!running) return;
    var url = location.origin.replace(/^http/, "ws") + "/ws?room=" + encodeURIComponent(room) +
      "&name=" + encodeURIComponent(myName) + "&mc=" + encodeURIComponent(myMc) + "&dev=" + encodeURIComponent(deviceId());
    var s = new WebSocket(url);
    s.binaryType = "arraybuffer";
    ws = s;
    setStatus("接続中…");
    s.onopen = function () { if (ws === s) { retry = 0; setStatus("通話中"); } };
    s.onmessage = function (e) {
      if (ws !== s) return;
      if (typeof e.data === "string") onText(e.data);
      else onAudio(new Uint8Array(e.data));
    };
    s.onclose = function (e) {
      if (ws !== s) return;
      if (e.code === 4004) { setStatus("運営がまだ近接VC待機所を開いてないよ（開くまで待ってね）"); stop(); return; }
      if (e.code === 4009) { setStatus("別の端末から同じ名前で入りました"); stop(); return; }
      if (e.code === 4010) { setStatus("通話が満員です"); stop(); return; }
      if (!running) return;
      retry++;
      setStatus("再接続中…");
      setTimeout(connect, Math.min(10000, 1000 * retry));
    };
  }

  function onText(text) {
    var m; try { m = JSON.parse(text); } catch (e) { return; }
    if (m.t === "hello") { isOwner = !!m.host; render(); }
    else if (m.t === "owner") {
      isOwner = !!m.host;
      setStatus(isOwner ? "あなたがオーナーになったよ 👑" : "オーナーが「" + (m.ownerName || "") + "」に変わったよ");
      render();
    }
    else if (m.t === "members") {
      members = {};
      mySlot = 0;
      (m.list || []).forEach(function (x) {
        members[x.id] = x;
        if (x.name === myName) { mySlot = x.slot || 0; optOut = !!x.out; }
      });
      if (m.mc === false) mcOn = false;
      for (var id in speakers) if (!members[id]) delete speakers[id];
      recompute();
    } else if (m.t === "pos") {
      positions = m.p || {}; mcOn = true; lastPos = Date.now(); recompute();
    } else if (m.t === "mc") {
      mcOn = !!m.on; if (!mcOn) positions = {}; recompute();
    }
  }

  function speaker(id) {
    var s = speakers[id];
    if (s) return s;
    var g = ctx.createGain();
    var p = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
    if (p) { g.connect(p); p.connect(ctx.destination); } else g.connect(ctx.destination);
    s = speakers[id] = { gain: g, pan: p, next: 0, last: 0, g: 1 };
    return s;
  }

  function onAudio(u8) {
    if (u8.length < 2 || !ctx || deafened) return;
    var id = u8[0], n = u8.length - 1, sr = ctx.sampleRate;
    var outLen = Math.round(n * sr / RATE);
    var buf = ctx.createBuffer(1, outLen, sr);
    var d = buf.getChannelData(0), step = RATE / sr;
    for (var i = 0; i < outLen; i++) {
      var x = i * step, k = Math.floor(x), t = x - k;
      var a = DEC[u8[1 + Math.min(k, n - 1)]], b = DEC[u8[1 + Math.min(k + 1, n - 1)]];
      d[i] = a * (1 - t) + b * t;
    }
    var s = speaker(id);
    var now = ctx.currentTime;
    if (s.next < now + 0.02 || s.next > now + 0.5) s.next = now + 0.1;
    var node = ctx.createBufferSource();
    node.buffer = buf;
    node.connect(s.gain);
    node.start(s.next);
    s.next += buf.duration;
    s.last = Date.now();
  }

  function compute(me, o) {
    if (!me || !o || me.d !== o.d) return [0, 0];
    var dx = o.x - me.x, dy = o.y - me.y, dz = o.z - me.z;
    var dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
    var g = dist <= FULL ? 1 : dist >= MAX ? 0 : Math.pow((MAX - dist) / (MAX - FULL), 2);
    var yaw = (me.r || 0) * Math.PI / 180;
    var rx = -Math.cos(yaw), rz = -Math.sin(yaw);
    var len = Math.sqrt(dx * dx + dz * dz);
    var pan = len < 0.5 ? 0 : ((dx * rx + dz * rz) / len) * 0.8;
    return [g, pan, dist];
  }

  function recompute() {
    if (!ctx) return;
    var me = myMc ? positions[myMc] : undefined;
    for (var id in members) {
      var mem = members[id];
      if (mem.name === myName) continue;
      // サーバーと同じルール
      var other = mem.mc ? positions[mem.mc] : undefined;
      var r;
      if (optOut || mem.out) r = [0, 0];
      else if (!mcOn) r = [1, 0];                                   // /connect 前はふつうの通話
      else if (mySlot > 0 && mem.slot > 0) r = compute(me, other);  // ワールドの中どうしは距離で
      else if (!me && !other && !mem.slot) r = [1, 0];              // ワールドの外どうしはふつうの通話
      else r = [0, 0];
      var full = compute(me, other);
      var s = speaker(id);
      s.g = r[0]; s.dist = full.length > 2 ? full[2] : null;
      s.gain.gain.setTargetAtTime(r[0], ctx.currentTime, 0.05);
      if (s.pan) s.pan.pan.setTargetAtTime(r[1], ctx.currentTime, 0.05);
    }
    render();
  }

  function render() {
    var roomName = (mcOn && mySlot > 0 && !optOut) ? ("部屋" + mySlot) : "近接VC待機所";
    $("roomLabel").textContent = (isOwner ? "👑 " : "") + roomName + "  ›";
    $("giveOwner").classList.toggle("hidden", !isOwner);
    $("mute").innerHTML = (muted || deafened) ? ICON_MICOFF : ICON_MIC;
    $("deafen").innerHTML = deafened ? ICON_HEADOFF : ICON_HEAD;
    var mc = $("mc");
    if (!mcOn) { mc.textContent = "⚪ 近接VC待機所にいるよ（ふつうの通話）。運営がマイクラで準備すると、ワールドに入った人から部屋に移動するよ"; mc.className = "mc"; }
    else if (optOut) { mc.textContent = "⏸ 通話を抜けてるよ（「通話に戻る」で戻れる）"; mc.className = "mc"; }
    else if (mySlot > 0) { mc.textContent = "🟢 部屋" + mySlot + " にいるよ：近くの人ほど大きく聞こえる"; mc.className = "mc on"; }
    else { mc.textContent = "🟡 近接VC待機所にいるよ：待機所の人どうしでふつうに話せる。マイクラのワールドに入ると、空いてる部屋に自動で移動するよ（名前がマイクラと同じか確認してね）"; mc.className = "mc"; }
    $("optout").classList.toggle("hidden", !mcOn);
    $("optout").textContent = optOut ? "通話に戻る" : "通話を抜ける";
    // Discord みたいなボイスチャンネル一覧（近接VC待機所 ＋ 部屋1〜20）
    var box = $("members");
    box.textContent = "";
    var byRoom = {}, myRoom = 0, now = Date.now();
    Object.keys(members).forEach(function (id) {
      var x = members[id];
      var r = (mcOn && x.slot >= 1 && x.slot <= 20) ? x.slot : 0;
      (byRoom[r] = byRoom[r] || []).push(id);
      if (x.name === myName) myRoom = r;
    });
    for (var r = 0; r <= 20; r++) {
      var people = byRoom[r] || [];
      var head = document.createElement("div");
      head.className = "ch" + (people.length ? " has" : "") + (r === myRoom ? " mine" : "");
      head.textContent = "🔊  " + (r === 0 ? "🎤▮近接VC待機所" : "🎧▮部屋" + r);
      if (r > 0 && people.length) {
        var c = document.createElement("span"); c.className = "cnt"; c.textContent = "1/1"; head.appendChild(c);
      }
      box.appendChild(head);
      people.forEach(function (id) {
        var mem = members[id], me = mem.name === myName, s = speakers[id];
        var talking = me ? selfTalking : (s && now - s.last < 350 && s.g > 0.01);
        var line = (talking ? "🟢 " : "⚫ ") + mem.name + (mem.host ? " 👑" : "");
        if (me) line += "（自分）" + (deafened ? "  🎧✕" : muted ? "  🎤✕" : "");
        else if (mem.out) line += "  （抜けてる）";
        else if (mcOn && r > 0 && s && s.dist != null) line += "  " + Math.round(s.dist) + "m" + (s.g <= 0.01 ? "・聞こえない" : "");
        var div = document.createElement("div");
        div.className = "mem" + (talking ? " talk" : "");
        div.textContent = line;
        box.appendChild(div);
      });
    }
      // 上のバーの下の短い説明
    $("sub").textContent = mc.textContent.split("。")[0];
    // ⌄ で「タイル」と「チャンネル一覧」を切り替え
    $("listView").classList.toggle("hidden", !showList);
    $("tiles").classList.toggle("hidden", showList);
    renderTiles(now);
  }

  var AV_COLORS = ["#5865F2", "#EB459E", "#3BA55C", "#FAA61A", "#ED4245", "#9B59B6"];
  function hashName(n) { var h = 0; for (var i = 0; i < n.length; i++) h = (h * 31 + n.charCodeAt(i)) | 0; return Math.abs(h); }
  // 真ん中のタイル: 自分と、今声が聞こえる相手
  function renderTiles(now) {
    var box = $("tiles"); box.textContent = "";
    var people = [];
    Object.keys(members).forEach(function (id) {
      var x = members[id], s = speakers[id];
      if (x.name === myName) people.unshift(id);
      else if (!x.out && s && s.g > 0.01) people.push(id);
    });
    if (!people.length) { var e = document.createElement("div"); e.className = "empty"; e.textContent = "まだ誰の声も聞こえないよ"; box.appendChild(e); return; }
    people.forEach(function (id) {
      var x = members[id], me = x.name === myName, s = speakers[id];
      var talking = me ? selfTalking : (s && now - s.last < 350 && s.g > 0.01);
      var t = document.createElement("div");
      t.className = "tile" + (people.length === 1 ? " one" : people.length === 2 ? " wide" : "") + (talking ? " talk" : "");
      var av = document.createElement("div"); av.className = "av";
      av.style.background = AV_COLORS[hashName(x.name) % AV_COLORS.length];
      av.textContent = x.name.slice(0, 1).toUpperCase();
      var chip = document.createElement("div"); chip.className = "chip";
      var label = (x.host ? "👑 " : "") + x.name;
      if (me && deafened) label += "  🎧✕"; else if (me && muted) label += "  🎤✕";
      if (!me && mcOn && x.slot > 0 && s && s.dist != null) label += "  " + Math.round(s.dist) + "m";
      chip.textContent = label;
      t.appendChild(av); t.appendChild(chip); box.appendChild(t);
    });
  }

  setInterval(function () {
    if (!running) return;
    if (mcOn && Date.now() - lastPos > 5000) { mcOn = false; positions = {}; recompute(); }
    else render();
  }, 250);

  async function keepAwake() {
    try { if (navigator.wakeLock) wakeLock = await navigator.wakeLock.request("screen"); } catch (e) {}
  }
  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible" && running) {
      keepAwake();
      if (ctx && ctx.state !== "running") ctx.resume();
    }
  });

  function stop() {
    running = false;
    var s = ws; ws = null;
    try { if (s) s.close(1000); } catch (e) {}
    try { if (stream) stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
    try { if (ctx) ctx.close(); } catch (e) {}
    try { if (wakeLock) wakeLock.release(); } catch (e) {}
    ctx = null; stream = null; speakers = {}; members = {}; positions = {}; mcOn = false; mySlot = 0; optOut = false;
    inBuf = []; rpos = 0; fpos = 0; selfTalking = false; muted = false; deafened = false;
    showStart();
    $("call").classList.add("hidden");
  }
})();
</script>
</body>
</html>`;

export const WEB_HTML = WEB_HTML_RAW.replace("__APK_URL__", APK_URL);

export const MANIFEST = JSON.stringify({
  name: "むいいむ しゃべくら",
  short_name: "しゃべくら",
  start_url: "/",
  display: "standalone",
  background_color: "#F4F7F2",
  theme_color: "#2E5E2A",
  icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml" }],
});

export const ICON_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 108">
<rect width="108" height="108" rx="22" fill="#7EC8E3"/>
<path fill="#8B5A2B" d="M32,38h44v38h-44z"/>
<path fill="#5DAE3B" d="M32,38h44v12h-44z"/>
<path fill="#4A9130" d="M32,50h6v4h-6zM44,50h6v6h-6zM58,50h6v3h-6zM70,50h6v5h-6z"/>
<path fill="#FFFFFF" d="M56,24h26a6,6 0,0 1,6 6v12a6,6 0,0 1,-6 6h-14l-8,7v-7h-4a6,6 0,0 1,-6 -6v-12a6,6 0,0 1,6 -6z"/>
<path fill="#5DAE3B" d="M61,34h4v4h-4zM67,34h4v4h-4zM73,34h4v4h-4z"/>
</svg>`;
