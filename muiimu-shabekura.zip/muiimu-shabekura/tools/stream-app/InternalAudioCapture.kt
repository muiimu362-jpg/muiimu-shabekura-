// むいいむ配信アプリ用: スマホの中の音（内部音声）を拾うクラス
// しゃべくらの「みんなの声＋自分の声（📺 配信に自分の声ものせる）」と、マイクラのゲーム音が取れる。
//
// 必要なもの
//  - Android 10 以上
//  - 画面配信で使っている MediaProjection（画面の録画の許可）をそのまま渡す
//  - RECORD_AUDIO の権限（マイクの許可。マイクそのものは使わない）
//  - AndroidManifest.xml:
//      <uses-permission android:name="android.permission.RECORD_AUDIO" />
//      配信のサービスに android:foregroundServiceType="mediaProjection"
//
// 使い方
//   val cap = InternalAudioCapture(mediaProjection, onlyShabekura = false) { pcm, n ->
//       // pcm[0 until n] = 48kHz・ステレオ・16bit の音。配信の音声エンコーダーに渡す
//       audioEncoder.feed(pcm, n)
//   }
//   cap.start()
//   ...
//   cap.stop()
//
// onlyShabekura = true にすると、しゃべくらの音（通話の声）だけを拾う（ゲーム音は入らない）。
// gameOnly = true（context も渡す）にすると、しゃべくらの音を外してゲーム音だけ拾う。
//   → 声は ShabekuraVoice（反響しない直接の受け取り）からもらって mixInto で足す。

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.annotation.RequiresPermission

@RequiresApi(Build.VERSION_CODES.Q)
class InternalAudioCapture(
    private val projection: MediaProjection,
    private val context: Context? = null,
    private val onlyShabekura: Boolean = false,
    /** true: しゃべくらの音を外す（声は ShabekuraVoice から直接もらうので、2重にならない） */
    private val gameOnly: Boolean = false,
    private val onAudio: (pcm: ShortArray, count: Int) -> Unit,
) {
    companion object {
        const val SAMPLE_RATE = 48000
        const val SHABEKURA_PACKAGE = "com.muiimu.shabekura"
    }

    @Volatile private var running = false
    private var thread: Thread? = null
    private var record: AudioRecord? = null

    @SuppressLint("MissingPermission")
    @RequiresPermission(Manifest.permission.RECORD_AUDIO)
    fun start() {
        if (running) return
        val config = AudioPlaybackCaptureConfiguration.Builder(projection).apply {
            if (onlyShabekura && context != null) {
                // しゃべくらの音だけ
                val uid = context.packageManager.getApplicationInfo(SHABEKURA_PACKAGE, 0).uid
                addMatchingUid(uid)
            } else {
                // しゃべくら（USAGE_MEDIA）＋ マイクラのゲーム音（USAGE_GAME）など
                addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                addMatchingUsage(AudioAttributes.USAGE_GAME)
                addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                if (gameOnly && context != null) {
                    // しゃべくらの音は外す（ShabekuraVoice で直接もらう）
                    try { excludeUid(context.packageManager.getApplicationInfo(SHABEKURA_PACKAGE, 0).uid) } catch (_: Exception) {}
                }
            }
        }.build()

        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
            .build()
        val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)

        val rec = AudioRecord.Builder()
            .setAudioFormat(format)
            .setBufferSizeInBytes(maxOf(minBuf, SAMPLE_RATE / 5 * 4)) // 約200ms
            .setAudioPlaybackCaptureConfig(config)
            .build()
        record = rec
        running = true
        rec.startRecording()

        thread = Thread({
            val buf = ShortArray(SAMPLE_RATE / 50 * 2) // 20ms・ステレオ
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) onAudio(buf, n)
            }
        }, "internal-audio").also { it.start() }
    }

    fun stop() {
        running = false
        thread?.join(500)
        thread = null
        try { record?.stop() } catch (_: Exception) {}
        record?.release()
        record = null
    }
}
