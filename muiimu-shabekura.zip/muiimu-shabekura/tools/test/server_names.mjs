import { Room } from "./idx.mjs";
class WS { constructor(){this.readyState=1;this.sent=[];this.att=null;} send(m){this.sent.push(m)} close(c){this.readyState=3;this.closed=c} serializeAttachment(a){this.att=a} deserializeAttachment(){return this.att} }
globalThis.WebSocketPair=function(){ return {0:new WS(),1:new WS()}; }; globalThis.Response=class{constructor(b,o){}};
let fails=0; const ok=(c,m)=>{ if(!c){fails++; console.log("FAIL:",m);} };
const sockets=[],store=new Map();
const r=new Room({getWebSockets:()=>sockets,acceptWebSocket:w=>sockets.push(w),storage:{get:async k=>store.get(k),put:async(k,v)=>store.set(k,v)}},{});
const join=async(n,mc,dev)=>{ await r.fetch({url:`https://x/ws?room=MUIIMU&name=${encodeURIComponent(n)}&mc=${encodeURIComponent(mc)}&dev=${dev}`}); return sockets.at(-1); };
const bin=(w)=>w.sent.filter(x=>typeof x!=="string").length;
const talk=async(f,t)=>{ const b=bin(t); await r.webSocketMessage(f,new Uint8Array([1]).buffer); return bin(t)>b; };
const members=(w)=>JSON.parse(w.sent.filter(x=>typeof x==="string"&&x.includes('"members"')).at(-1)).list;
// 呼び名とマイクラの名前が違う
const owner=await join("むいいむ","gopura777","D1");
const sub=await join("サブ垢","saradayou509","D2");
const nomc=await join("見学の人","","D3");       // マイクラの名前なし
const pos=(p)=>r.webSocketMessage(owner, JSON.stringify({t:"pos",p}));
await pos({gopura777:{x:0,y:64,z:0,d:0}, saradayou509:{x:3,y:64,z:0,d:0}});
const L=members(owner);
ok(L.find(m=>m.name==="むいいむ").slot===1, "オーナー(むいいむ/gopura777)は部屋1");
ok(L.find(m=>m.name==="サブ垢").slot===2, "サブ垢(saradayou509)は部屋2");
ok(L.find(m=>m.name==="見学の人").slot===0, "マイクラの名前なしは待機所");
ok(L.find(m=>m.name==="サブ垢").mc==="saradayou509", "マイクラの名前がメンバー情報に入る");
ok(await talk(sub,owner) && await talk(owner,sub), "部屋どうし近い→聞こえる");
ok(!(await talk(nomc,owner)) && !(await talk(owner,nomc)), "待機所とワールドの中は聞こえない");
await pos({gopura777:{x:0,y:64,z:0,d:0}, saradayou509:{x:100,y:64,z:0,d:0}});
ok(!(await talk(sub,owner)), "遠い→聞こえない");
// マイクラの名前が同じでも、呼び名が違えば別人として入れる（追い出されない）
const sub2=await join("サブ垢2","Steve","D4"); ok(sub.readyState===1 && sub2.readyState===1, "呼び名が違えば両方入れる");
console.log(fails===0?"ALL OK":"FAILED "+fails);
