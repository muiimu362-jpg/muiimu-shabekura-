package com.muiimu.shabekura

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var etName: EditText
    private lateinit var etRoom: EditText
    private lateinit var etPass: EditText
    private lateinit var setupPanel: LinearLayout
    private lateinit var hostPanel: LinearLayout
    private lateinit var callPanel: LinearLayout
    private lateinit var tvRoom: TextView
    private lateinit var tvMc: TextView
    private lateinit var tvMembers: TextView
    private lateinit var tvStatus: TextView
    private lateinit var btnCopyCmd: Button
    private lateinit var btnMute: Button

    private val listener: () -> Unit = { render() }
    private var pendingStart: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("shabekura", Context.MODE_PRIVATE)

        etName = findViewById(R.id.etName)
        etRoom = findViewById(R.id.etRoom)
        etPass = findViewById(R.id.etPass)
        setupPanel = findViewById(R.id.setupPanel)
        hostPanel = findViewById(R.id.hostPanel)
        callPanel = findViewById(R.id.callPanel)
        tvRoom = findViewById(R.id.tvRoom)
        tvMc = findViewById(R.id.tvMc)
        tvMembers = findViewById(R.id.tvMembers)
        tvStatus = findViewById(R.id.tvStatus)
        btnCopyCmd = findViewById(R.id.btnCopyCmd)
        btnMute = findViewById(R.id.btnMute)

        etName.setText(prefs.getString("name", ""))
        etRoom.setText(prefs.getString("room", ""))
        etPass.setText(prefs.getString("pass", ""))

        if (VoiceService.serverBase().isEmpty()) {
            findViewById<View>(R.id.serverWarn).visibility = View.VISIBLE
        }

        val hostToggle = findViewById<TextView>(R.id.hostToggle)
        if (prefs.getString("hostKey", "").orEmpty().isNotEmpty()) {
            hostPanel.visibility = View.VISIBLE
            hostToggle.text = "▼ ホスト用（むいいむ専用）"
        }
        hostToggle.setOnClickListener {
            val show = hostPanel.visibility != View.VISIBLE
            hostPanel.visibility = if (show) View.VISIBLE else View.GONE
            hostToggle.text = if (show) "▼ ホスト用（むいいむ専用）" else "▶ ホスト用（むいいむ専用）"
        }

        findViewById<Button>(R.id.btnJoin).setOnClickListener { join() }
        findViewById<Button>(R.id.btnHost).setOnClickListener { host(forceNew = false) }
        findViewById<Button>(R.id.btnNewRoom).setOnClickListener { host(forceNew = true) }
        btnCopyCmd.setOnClickListener {
            copy(McBridge.COMMAND)
            Toast.makeText(this, "コピーしたよ！マイクラのチャットに貼り付けて送信してね", Toast.LENGTH_LONG).show()
        }
        findViewById<Button>(R.id.btnInvite).setOnClickListener {
            val code = AppState.roomCode
            val base = VoiceService.serverBase()
            copy(
                "むいいむ通話に来てね！ルームコード【$code】\n" +
                    "・Android: 「むいいむ しゃべくら」アプリで入ってね\n" +
                    "・iPhone・PC: $base/?room=$code を開いてね"
            )
            Toast.makeText(this, "招待メッセージをコピーしたよ", Toast.LENGTH_SHORT).show()
        }
        btnMute.setOnClickListener { VoiceService.instance?.setMuted(!AppState.muted) }
        findViewById<Button>(R.id.btnLeave).setOnClickListener { VoiceService.stop(this) }

        askPermissions()
    }

    override fun onResume() {
        super.onResume()
        AppState.addListener(listener)
        render()
    }

    override fun onPause() {
        AppState.removeListener(listener)
        super.onPause()
    }

    private fun askPermissions() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val start = pendingStart
        pendingStart = null
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            start?.invoke()
        } else if (start != null) {
            toast("マイクの許可がないと通話できないよ（設定 → アプリ → 権限）")
        }
    }

    /** マイクの許可を確認してから通話を始める */
    private fun withMic(action: () -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            action()
        } else {
            pendingStart = action
            askPermissions()
        }
    }

    private fun myName(): String? {
        val name = etName.text.toString().trim()
        if (name.isEmpty()) {
            toast("マイクラの名前を入れてね"); return null
        }
        prefs.edit().putString("name", name).apply()
        return name
    }

    private fun join() {
        val name = myName() ?: return
        val code = etRoom.text.toString().trim().uppercase()
        if (code.length != 6) {
            toast("ルームコードは6文字だよ"); return
        }
        prefs.edit().putString("room", code).apply()
        withMic { VoiceService.start(this, code, name, null) }
    }

    private fun host(forceNew: Boolean) {
        val name = myName() ?: return
        val savedRoom = prefs.getString("hostRoom", "").orEmpty()
        val savedKey = prefs.getString("hostKey", "").orEmpty()
        if (!forceNew && savedRoom.isNotEmpty() && savedKey.isNotEmpty()) {
            // いつものルームコードをそのまま使う（友達はコードを覚え直さなくていい）
            withMic { VoiceService.start(this, savedRoom, name, savedKey) }
            return
        }
        val pass = etPass.text.toString()
        if (pass.isEmpty()) {
            toast("ホストのパスワードを入れてね"); return
        }
        val base = VoiceService.serverBase()
        if (base.isEmpty()) {
            toast("サーバーのURLが入っていないよ"); return
        }
        toast("通話を作ってるよ…")
        Thread {
            try {
                val body = JSONObject().put("password", pass).toString()
                    .toRequestBody("application/json".toMediaType())
                val req = Request.Builder().url("$base/api/create").post(body).build()
                OkHttpClient().newCall(req).execute().use { res ->
                    val text = res.body?.string().orEmpty()
                    val j = try { JSONObject(text) } catch (_: Exception) { JSONObject() }
                    if (!res.isSuccessful) {
                        val err = j.optString("error", "作れませんでした（${res.code}）")
                        runOnUiThread { toast(err) }
                        return@use
                    }
                    val code = j.getString("code")
                    val key = j.getString("hostKey")
                    prefs.edit()
                        .putString("pass", pass)
                        .putString("hostRoom", code)
                        .putString("hostKey", key)
                        .apply()
                    runOnUiThread {
                        etRoom.setText(code)
                        withMic { VoiceService.start(this, code, name, key) }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("サーバーにつながりません: ${e.message}") }
            }
        }.start()
    }

    private fun render() {
        val s = AppState
        setupPanel.visibility = if (s.running) View.GONE else View.VISIBLE
        callPanel.visibility = if (s.running) View.VISIBLE else View.GONE
        tvStatus.text = s.status

        if (!s.running) return

        tvRoom.text = "ルームコード: ${s.roomCode}" + if (s.isHost) "（ホスト）" else ""
        btnCopyCmd.visibility = if (s.isHost) View.VISIBLE else View.GONE

        when {
            s.mcLinked -> {
                tvMc.text = "🟢 マイクラ連携中：近いほど大きく聞こえるよ"
                tvMc.setBackgroundColor(0xFFDDF3D3.toInt())
            }
            s.isHost && s.bridgeOpen -> {
                tvMc.text = "🟡 マイクラとつながった。座標を取得中…"
                tvMc.setBackgroundColor(0xFFFFF4CC.toInt())
            }
            s.isHost -> {
                tvMc.text = "⚪ マイクラ未連携（今は普通の通話）\n下のボタンでコマンドをコピー → マイクラのチャットに貼って送信"
                tvMc.setBackgroundColor(0xFFEDEDED.toInt())
            }
            else -> {
                tvMc.text = "⚪ ホストがマイクラ連携するまでは普通の通話だよ"
                tvMc.setBackgroundColor(0xFFEDEDED.toInt())
            }
        }

        btnMute.text = if (s.muted) "ミュート解除" else "ミュート"

        val sb = StringBuilder()
        for (m in s.members) {
            val me = m.name == s.myName
            val talking = if (me) s.selfTalking else m.id in s.talking
            sb.append(if (talking) "🔊 " else "　 ")
            sb.append(m.name)
            if (m.host) sb.append(" 👑")
            if (me) sb.append("（自分）")
            if (s.mcLinked && !me) {
                val d = m.distance
                sb.append(
                    when {
                        d == null -> "  — ワールドにいない"
                        m.gain <= 0.01f -> "  ${d.roundToInt()}m（遠くて聞こえない）"
                        else -> "  ${d.roundToInt()}m"
                    }
                )
            }
            sb.append('\n')
        }
        if (s.members.isEmpty()) sb.append("接続中…")
        tvMembers.text = sb.toString().trimEnd()
    }

    private fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("shabekura", text))
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
