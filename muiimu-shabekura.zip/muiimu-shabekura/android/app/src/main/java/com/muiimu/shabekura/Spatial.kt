package com.muiimu.shabekura

import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class Pos(val x: Double, val y: Double, val z: Double, val d: Int, val r: Double)

/** 距離と向きから、音量(0〜1)と左右(-1=左, 1=右)を決める */
object Spatial {
    const val FULL = 1.0   // 1ブロックまでは ふつうの声
    const val MAX = 7.0    // 7ブロックで聞こえない

    /**
     * ブロックごとの音量（むいいむさんの決めた聞こえ方）
     * 1ブロック = ふつうの声、2ブロック = 半分、3〜5ブロックで少しずつ小さく、6ブロック = ほんとに薄い声、7ブロックで聞こえない
     * あいだはなめらかにつなぐ
     */
    val STEPS = doubleArrayOf(1.0, 1.0, 0.5, 0.32, 0.2, 0.11, 0.05, 0.0)  // 0〜7ブロック

    fun gainAt(dist: Double): Double {
        if (dist <= 1.0) return 1.0
        if (dist >= 7.0) return 0.0
        val i = dist.toInt()
        val t = dist - i
        return STEPS[i] * (1 - t) + STEPS[i + 1] * t
    }

    fun distance(a: Pos, b: Pos): Double {
        val dx = a.x - b.x; val dy = a.y - b.y; val dz = a.z - b.z
        return sqrt(dx * dx + dy * dy + dz * dz)
    }

    /** @return Pair(gain, pan) */
    fun compute(me: Pos?, other: Pos?): Pair<Float, Float> {
        if (me == null || other == null) return 0f to 0f
        if (me.d != other.d) return 0f to 0f
        val dist = distance(me, other)
        val gain = gainAt(dist)
        // マイクラの向き: yRot=0 が南(+Z)、90 が西(-X)
        val yaw = Math.toRadians(me.r)
        val rightX = -cos(yaw)
        val rightZ = -sin(yaw)
        val dx = other.x - me.x
        val dz = other.z - me.z
        val len = sqrt(dx * dx + dz * dz)
        val pan = if (len < 0.5) 0.0 else ((dx * rightX + dz * rightZ) / len) * 0.8
        return gain.toFloat() to pan.toFloat()
    }
}
