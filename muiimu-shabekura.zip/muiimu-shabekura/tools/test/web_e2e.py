import asyncio, json, subprocess, sys, time
from playwright.async_api import async_playwright
FAKE_WS = """
window.__sent = []; window.__sockets = [];
class FakeWS {
  constructor(url){ this.url=url; this.readyState=0; this.binaryType='blob'; window.__sockets.push(this);
    setTimeout(()=>{ this.readyState=1; this.onopen && this.onopen({}); }, 50); }
  send(d){ window.__sent.push(typeof d === 'string' ? d : '[binary ' + (d.byteLength||d.length) + ']'); }
  close(){ this.readyState=3; }
  _recv(obj){ this.onmessage && this.onmessage({data: typeof obj==='string'?obj:JSON.stringify(obj)}); }
  _recvBin(arr){ this.onmessage && this.onmessage({data: new Uint8Array(arr).buffer}); }
}
window.WebSocket = FakeWS;
"""
async def main():
    srv = subprocess.Popen([sys.executable, "-m", "http.server", "8765"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(1)
    fails = []
    def ok(c, m):
        print(("OK   " if c else "FAIL ") + m)
        if not c: fails.append(m)
    try:
        async with async_playwright() as p:
            b = await p.chromium.launch(executable_path="/usr/bin/google-chrome",
                args=["--no-sandbox","--use-fake-device-for-media-stream","--use-fake-ui-for-media-stream","--autoplay-policy=no-user-gesture-required"])
            ctx = await b.new_context(viewport={"width":390,"height":844}, permissions=["microphone"])
            pg = await ctx.new_page()
            await pg.add_init_script(FAKE_WS)
            errors = []
            pg.on("pageerror", lambda e: errors.append(str(e)))
            await pg.goto("http://localhost:8765/index.html")
            # 最初の画面: どの端末でも「ブラウザ」「アプリ」を選ぶ
            await pg.wait_for_timeout(100)
            ok(await pg.is_visible("#useBrowser") and await pg.is_visible("#dlApk") and not await pg.is_visible("#namePanel"), "最初の画面は「ブラウザ」「アプリ」の2つ（PC/iPhoneでも）")
            href = await pg.evaluate("document.getElementById('dlApk').getAttribute('href')")
            ok("MuiimuShabekura.apk" in href or "__APK_URL__" in href, "「アプリ」はダウンロードリンク: " + href)
            await pg.click("#useBrowser")
            # 0. 一番最初は「名前を決めてください」
            ok(await pg.is_visible("#namePanel") and not await pg.is_visible("#setup"), "最初の画面は「名前を決めてください」")
            await pg.fill("#displayName", "サブ垢")
            await pg.click("#setName")
            ok(await pg.is_visible("#setup") and "サブ垢" in await pg.inner_text("#myNameLabel"), "名前を決めるとチャンネル一覧になる")
            # 1. 待機所をタップ → マイクラの名前（サブ） → 入る
            await pg.click("#chLobby")
            ok(await pg.is_visible("#joinForm"), "待機所をタップすると入力欄が出る")
            await pg.fill("#mcName", "saradayou509")
            await pg.click("#join")
            await pg.wait_for_timeout(800)
            url = await pg.evaluate("window.__sockets[0] && window.__sockets[0].url")
            import urllib.parse as up
            q = up.parse_qs(up.urlparse(url).query) if url else {}
            ok(q.get("room")==["MUIIMU"] and q.get("name")==["サブ垢"] and q.get("mc")==["saradayou509"] and q.get("dev",[""])[0].startswith("web-"), "呼び名とマイクラの名前を分けてつながる: " + str(q))
            ok(await pg.is_visible("#call"), "通話画面になる")
            # 2. サーバーから hello(オーナー) と members
            await pg.evaluate("""() => { const w=window.__sockets[0];
              w._recv({t:'hello', id:2, host:true});
              w._recv({t:'members', mc:false, list:[{id:1,name:'むいいむ',mc:'gopura777',host:false,slot:0},{id:2,name:'サブ垢',mc:'saradayou509',host:true,slot:0},{id:3,name:'見学の人',mc:'',host:false,slot:0}]}); }""")
            await pg.wait_for_timeout(300)
            ok(await pg.is_visible("#giveOwner"), "オーナーには右上に「オーナーを渡す」が出る")
            # 真ん中のタイル（待機所はふつうの通話なので全員）
            await pg.wait_for_timeout(300)
            tiles = await pg.inner_text("#tiles")
            ok("サブ垢" in tiles and "むいいむ" in tiles and "見学の人" in tiles, "タイルに自分と聞こえる人が出る: " + tiles.replace(chr(10)," | "))
            ok("近接VC待機所" in await pg.inner_text("#roomLabel"), "上の札に「近接VC待機所」")
            ok(await pg.is_visible("#shareTop") and await pg.is_visible("#invite"), "右上のシェアと「メンバーを追加」カードが出る（全員）")
            # マイク: 1回押すとミュート、もう1回で戻る
            m0 = await pg.inner_html("#mute"); await pg.click("#mute"); m1 = await pg.inner_html("#mute"); await pg.click("#mute"); m2 = await pg.inner_html("#mute")
            ok(m0 == m2 and m0 != m1 and "F23F43" in m1, "マイク: 1回でミュート（赤）、もう1回で戻る")
            d0 = await pg.inner_html("#deafen"); await pg.click("#deafen"); d1 = await pg.inner_html("#deafen"); await pg.click("#deafen")
            ok(d0 != d1 and "F23F43" in d1, "スピーカーミュート: 斜線付きヘッドホン（赤）に切り替わる")
            # ⌄ でチャンネル一覧
            await pg.click("#collapse")
            txt = await pg.inner_text("#members")
            ok("近接VC待機所" in txt and "部屋20" in txt and "むいいむ" in txt and "見学の人" in txt, "⌄でチャンネル一覧（待機所・部屋20・メンバー）")
            await pg.click("#collapse")
            ok(await pg.is_visible("#tiles") and not await pg.is_visible("#listView"), "もう一度⌄でタイルに戻る")
            # 3. 声が送られている（偽マイクの音）
            await pg.wait_for_timeout(1500)
            sent = await pg.evaluate("window.__sent")
            ok(any(s.startswith("[binary 640") for s in sent), "マイクの声が送られている（40msごとの音声）")
            # 4. オーナーを渡す
            pg.once("dialog", lambda d: asyncio.ensure_future(d.accept()))
            await pg.click("#giveOwner")
            ok(await pg.is_visible("#ownerPick"), "渡す相手の一覧が出る")
            names = await pg.inner_text("#ownerList")
            ok("むいいむ" in names and "見学の人" in names and "サブ垢" not in names, "一覧に自分以外のメンバー（呼び名）が出る")
            await pg.click("#ownerList button:has-text('むいいむ')")
            await pg.wait_for_timeout(300)
            sent = await pg.evaluate("window.__sent")
            ok(any('"giveOwner"' in s and '"id":1' in s for s in sent), "giveOwner(id=1) が送られる")
            await pg.evaluate("window.__sockets[0]._recv({t:'owner', host:false, ownerName:'むいいむ'})")
            await pg.wait_for_timeout(300)
            ok(not await pg.is_visible("#giveOwner"), "渡したら「オーナーを渡す」が消える")
            ok("むいいむ" in await pg.inner_text("#status"), "「オーナーが むいいむ に変わった」と出る")
            # 5. 部屋に移動（マイクラ連携後）
            await pg.evaluate("""() => { const w=window.__sockets[0];
              w._recv({t:'pos', p:{gopura777:{x:0,y:64,z:0,d:0,r:0}, saradayou509:{x:3,y:64,z:0,d:0,r:0}}});
              w._recv({t:'members', mc:true, list:[{id:1,name:'むいいむ',mc:'gopura777',host:true,slot:1},{id:2,name:'サブ垢',mc:'saradayou509',host:false,slot:2},{id:3,name:'見学の人',mc:'',host:false,slot:0}]}); }""")
            await pg.wait_for_timeout(400)
            ok("部屋2" in await pg.inner_text("#roomLabel"), "上の札が「部屋2」になる")
            tiles = await pg.inner_text("#tiles")
            ok("サブ垢" in tiles and "むいいむ" in tiles and "見学の人" in tiles, "タイルは通話にいる人がずっと出る（出たり消えたりしない）: " + tiles.replace(chr(10)," | "))
            import re as _re
            ok(not _re.search(r"\dm", tiles) and "聞こえ" not in tiles, "タイルに距離（○m）や「聞こえない」は出ない・名前だけ")
            order1 = await pg.evaluate("[...document.querySelectorAll('#tiles .chip')].map(e=>e.textContent)")
            await pg.evaluate("window.__sockets[0]._recv({t:'pos', p:{gopura777:{x:0,y:64,z:0,d:0,r:0}, saradayou509:{x:30,y:64,z:0,d:0,r:0}}})")
            await pg.wait_for_timeout(200)
            order2 = await pg.evaluate("[...document.querySelectorAll('#tiles .chip')].map(e=>e.textContent)")
            ok(order1 == order2, "離れてもタイルの並びは変わらない")
            await pg.evaluate("window.__sockets[0]._recv({t:'pos', p:{gopura777:{x:0,y:64,z:0,d:0,r:0}, saradayou509:{x:3,y:64,z:0,d:0,r:0}}})")
            # 聞こえ方（ブロックごと）: チャットの読み上げの音量で実際の計算を確かめる（自分は x=3）
            await pg.evaluate("() => { window.__spoken=[]; window.speechSynthesis.speak = (u) => { window.__spoken.push([u.text, u.volume, u.lang]); }; }")
            await pg.evaluate("() => { const w=window.__sockets[0]; [1,2,3,4,5,6,7,8].forEach(d => w._recv({t:'chat', mc:'b'+d, text:'d'+d, p:{x:3+d,y:64,z:0,d:0,r:0}})); }")
            # 読み上げの音量 = 0.55 + 0.45 × 声の音量 → 声の音量に戻して確かめる
            vol = {x[0]: round((x[1] - 0.55) / 0.45, 3) for x in await pg.evaluate("window.__spoken")}
            rawv = {x[0]: round(x[1], 3) for x in await pg.evaluate("window.__spoken")}
            ok(all(v >= 0.55 for v in rawv.values()) and rawv.get("d1") == 1, "チャットの読み上げは届く範囲ならはっきり聞こえる大きさ: " + str(rawv))
            ok(rawv.get("d1") == 1 and rawv.get("d2") == 1 and abs(vol.get("d3", 0) - 0.75) < 0.01 and vol.get("d3") > vol.get("d4") > vol.get("d5") > vol.get("d6") > 0.08 and "d7" not in vol and "d8" not in vol,
               "聞こえ方: 3ブロックでもけっこう聞こえる(0.75)、4〜6で小さく、7以上=聞こえない " + str(vol))
            # チャットの読み上げ（近い人だけ、近いほど大きく）
            await pg.evaluate("() => { window.__spoken=[]; window.speechSynthesis.speak = (u) => { window.__spoken.push([u.text, u.volume, u.lang]); }; }")
            await pg.evaluate("""() => { const w=window.__sockets[0];
              w._recv({t:'chat', mc:'gopura777', text:'こんにちは', p:{x:0,y:64,z:0,d:0,r:0}});
              w._recv({t:'chat', mc:'遠い人', text:'とおいよ', p:{x:20,y:64,z:0,d:0,r:0}});
              w._recv({t:'chat', mc:'ぎりぎり', text:'ぎりぎり', p:{x:9,y:64,z:0,d:0,r:0}});
              w._recv({t:'chat', mc:'ネザー', text:'ちがう世界', p:{x:3,y:64,z:0,d:1,r:0}});
              w._recv({t:'chat', mc:'gopura777', text:'位置なし' }); }""")
            spoken = await pg.evaluate("window.__spoken")
            texts = [x[0] for x in spoken]
            ok("こんにちは" in texts and "とおいよ" not in texts and "ちがう世界" not in texts, "チャット読み上げ: 近い人だけ（遠い人・別の世界は読まない）: " + str(spoken))
            v = {x[0]: x[1] for x in spoken}
            ok(v.get("こんにちは", 0) > v.get("ぎりぎり", 0) >= 0.55, "近いと大きく、6ブロックくらいでも聞こえる大きさで読む: " + str(v))
            ok(v.get("位置なし", 0) > 0.55 and all(x[2] == "ja-JP" for x in spoken), "位置がなくても通話の人ならその人の位置で読む・日本語で読む")
            await pg.click("#deafen")
            await pg.evaluate("() => { window.__spoken=[]; window.__sockets[0]._recv({t:'chat', mc:'gopura777', text:'聞こえないはず', p:{x:0,y:64,z:0,d:0,r:0}}); }")
            ok(await pg.evaluate("window.__spoken.length") == 0, "スピーカーミュート中は読み上げない")
            await pg.click("#deafen")
            # アイコン長押し → その人の音量・ミュート
            await pg.evaluate("""() => { window.__tg = []; const o = AudioParam.prototype.setTargetAtTime;
              AudioParam.prototype.setTargetAtTime = function(v, t, c) { window.__tg.push(v); return o.call(this, v, t, c); }; }""")
            tile = pg.locator("#tiles .tile", has_text="むいいむ")
            await tile.hover(); await pg.mouse.down(); await pg.wait_for_timeout(700); await pg.mouse.up()
            ok(await pg.is_visible("#volPick") and "むいいむ" in await pg.inner_text("#volTitle") and "100%" in await pg.inner_text("#volLabel"), "アイコン長押しで音量の画面（最初は100%）")
            await pg.evaluate("() => { const r = document.getElementById('volRange'); r.value = 30; r.dispatchEvent(new Event('input')); }")
            await pg.wait_for_timeout(200)
            tg = await pg.evaluate("window.__tg")
            ok("30%" in await pg.inner_text("#volLabel") and any(abs(x - 0.75 * 0.3) < 0.01 for x in tg), "30%にすると、その人の声が30%になる（3ブロック 0.75 → 0.225）: " + str([round(x,3) for x in tg[-4:]]))
            ok("🔉" in await pg.inner_text("#tiles"), "音量を下げた人には🔉が付く")
            await pg.click("#volMute"); await pg.wait_for_timeout(200)
            tg = await pg.evaluate("window.__tg")
            ok("ミュート中" in await pg.inner_text("#volLabel") and not any(abs(x - 0.225) < 0.01 or abs(x - 0.75) < 0.01 for x in tg[-4:]) and "🔇" in await pg.inner_text("#tiles"), "ミュートすると0になって🔇")
            await pg.evaluate("() => { window.__spoken=[]; window.__sockets[0]._recv({t:'chat', mc:'gopura777', text:'ミュートした人', p:{x:0,y:64,z:0,d:0,r:0}}); }")
            ok(await pg.evaluate("window.__spoken.length") == 0, "ミュートした人のチャットは読まない")
            await pg.click("#volReset"); await pg.wait_for_timeout(200)
            tg = await pg.evaluate("window.__tg")
            ok("100%" in await pg.inner_text("#volLabel") and any(abs(x - 0.75) < 0.01 for x in tg[-4:]), "「100%に戻す」で元どおり")
            await pg.click("#volClose")
            ok(not await pg.is_visible("#volPick"), "とじる")
            ok(await pg.evaluate("localStorage.getItem('vol_むいいむ')") is None, "戻したら記録も消える")
            await pg.click("#collapse")
            txt = await pg.inner_text("#members")
            i1 = txt.index("部屋1"); i2 = txt.index("部屋2"); i3 = txt.index("部屋3")
            ok("むいいむ" in txt[i1:i2] and "サブ垢" in txt[i2:i3], "むいいむは部屋1、サブ垢は部屋2に表示")
            ok("見学の人" in txt[:i1], "マイクラの名前なしの人は待機所に表示")
            ok(not _re.search(r"\dm", txt) and "聞こえない" not in txt, "チャンネル一覧も名前だけ（距離・聞こえないの文字なし）")
            ok("部屋2 にいるよ" in await pg.inner_text("#mc"), "「部屋2 にいるよ」と出る（状態カードに表示）")
            await pg.click("#collapse")
            # 6. 相手の声が届いたら再生される（エラーなく）
            await pg.evaluate("window.__sockets[0]._recvBin([1].concat(Array(640).fill(0x80)))")
            await pg.wait_for_timeout(300)
            ok(not errors, "ページのエラーなし " + str(errors))
            ids = await pg.evaluate("() => { const all=[...document.querySelectorAll('[id]')].map(e=>e.id); return all.filter((x,i)=>all.indexOf(x)!==i); }")
            ok(not ids, "同じIDの重複なし " + str(ids))
            await pg.screenshot(path="/tmp/webtest/e2e.png", full_page=True)
            # 7. 退出するとチャンネル一覧に戻る（名前は覚えている）
            await pg.click("#leave")
            await pg.wait_for_timeout(200)
            ok(await pg.is_visible("#setup") and not await pg.is_visible("#namePanel"), "退出するとチャンネル一覧に戻る")
            # 入る前の画面: 右上のシェアはだれでも、「オーナーを渡す」はオーナーだけ
            gave = []
            state = {"isOwner": False, "hasOwner": True, "ownerName": "むいいむ", "members": [], "people": [{"name": "むいいむ", "slot": 1, "host": True}, {"name": "見学の人", "slot": 0, "host": False}, {"name": "サブ垢", "slot": 3, "host": False}], "resting": [{"name": "寝てる人", "last": __import__("time").time()*1000 - 5*60000}, {"name": "きのうの人", "last": __import__("time").time()*1000 - 26*3600000}]}
            async def api_state(route):
                await route.fulfill(status=200, content_type="application/json", body=__import__("json").dumps(state))
            async def api_give(route):
                gave.append((route.request.method, route.request.url)); state["isOwner"] = False; state["ownerName"] = "サブ垢"; state["members"] = []
                await route.fulfill(status=200, content_type="application/json", body='{"ok":true}')
            await pg.route("**/api/state*", api_state); await pg.route("**/api/give*", api_give)
            await pg.wait_for_timeout(4500)
            ok(await pg.is_visible("#shareLobby"), "入る前の画面の右上にシェアボタン（だれでも）")
            # 人のマーク + 人数（シェアの右）
            ok((await pg.inner_text("#membersLobby")).strip() == "3", "人のマークのボタンに今いる人数（3）")
            boxes = await pg.evaluate("['shareLobby','membersLobby'].map(id => document.getElementById(id).getBoundingClientRect().left)")
            ok(boxes[0] < boxes[1], "人数のボタンはシェア（人＋）の右")
            await pg.click("#membersLobby"); await pg.wait_for_timeout(300)
            ml = await pg.inner_text("#memberList")
            ok("オンライン — 3" in ml and "休憩中 — 2" in ml and ml.index("むいいむ") < ml.index("休憩中") < ml.index("寝てる人") < ml.index("きのうの人"), "押すとオンラインが上、その下に休憩中（新しい順）")
            ok("5分前" in ml and "1日前" in ml and "部屋1" in ml and "待機所" in ml, "休憩中は「○分前」、オンラインはどこにいるか: " + ml.replace(chr(10), " | "))
            await pg.click("#memberClose"); await pg.wait_for_timeout(200)
            ok(not await pg.is_visible("#memberPanel"), "とじる")
            lp = await pg.inner_text("#lobbyPeople"); rp = await pg.inner_text("#roomsPreview")
            i1 = rp.index("部屋1"); i2 = rp.index("部屋2"); i3 = rp.index("部屋3"); i4 = rp.index("部屋4")
            ok("見学の人" in lp and "むいいむ" in rp[i1:i2] and "👑" in rp[i1:i2] and "サブ垢" in rp[i3:i4], "入る前の画面に、待機所と部屋ごとに今いる人の名前が出る")
            ok(not await pg.is_visible("#giveOwnerLobby") and "オーナー: むいいむ" in await pg.inner_text("#lobbyOwner"), "オーナーじゃない人には「オーナーを渡す」が出ない・だれがオーナーか出る")
            state.update({"isOwner": True, "ownerName": "サブ垢", "members": [{"id": 7, "name": "見学の人"}]})
            await pg.wait_for_timeout(4500)
            ok(await pg.is_visible("#giveOwnerLobby") and "あなたがオーナー" in await pg.inner_text("#lobbyOwner"), "オーナーには入る前の画面の右上に「オーナーを渡す」")
            ok((await pg.inner_text("#giveOwnerLobby")).strip() == "👑", "オーナーを渡すボタンは王冠だけ")
            await pg.click("#giveOwnerLobby")
            ok("見学の人" in await pg.inner_text("#lobbyList"), "渡す相手（今通話にいる人）が出る")
            pg.once("dialog", lambda d: asyncio.ensure_future(d.accept()))
            await pg.click("#lobbyList button")
            await pg.wait_for_timeout(500)
            ok(gave and gave[0][0] == "POST" and "id=7" in gave[0][1] and "dev=web-" in gave[0][1], "POST /api/give で渡す: " + str(gave))
            await pg.wait_for_timeout(300)
            ok(not await pg.is_visible("#giveOwnerLobby"), "渡したら「オーナーを渡す」が消える")
            # 8. Android のブラウザで開いたら、アプリを開く画面になる（名前の画面は出ない）
            actx = await b.new_context(user_agent="Mozilla/5.0 (Linux; Android 14) Chrome/120 Mobile")
            ap = await actx.new_page()
            await ap.add_init_script(FAKE_WS)
            await actx.grant_permissions(["microphone"])
            await ap.route("**/*", lambda route: route.continue_() if "localhost" in route.request.url else route.abort())
            await ap.goto("http://localhost:8765/index.html?room=MUIIMU")
            await ap.wait_for_timeout(100)
            ok(await ap.is_visible("#android") and not await ap.is_visible("#namePanel") and not await ap.is_visible("#setup"), "Androidでは最初に選ぶ画面が出る")
            ok(not await ap.is_visible("#openApp") and await ap.is_visible("#dlApk") and await ap.is_visible("#useBrowser"), "Androidでも「ブラウザ」「アプリ」が出る")
            await ap.wait_for_timeout(800)
            ok(ap.url.startswith("http://localhost"), "勝手にアプリへ飛ばない（選べる）")
            await ap.click("#useBrowser")
            ok(await ap.is_visible("#namePanel") and not await ap.is_visible("#android"), "「ブラウザで使う」で名前を決める画面になる")
            await ap.fill("#displayName", "スマホの人"); await ap.click("#setName"); await ap.click("#chLobby"); await ap.click("#join")
            await ap.wait_for_timeout(600)
            ok(await ap.is_visible("#mute") and await ap.is_visible("#leave"), "Androidのブラウザでも通話画面に入れる")
            # シェア = リンクをコピーするだけ（シェア画面は出さない）
            await ap.evaluate("""() => { window.__shared=null; window.__copied=null;
              navigator.share = (d) => { window.__shared = d.text; return Promise.resolve(); };
              Object.defineProperty(navigator, 'clipboard', { configurable: true, value: { writeText: (t) => { window.__copied = t; return Promise.resolve(); } } }); }""")
            await ap.click("#shareTop")
            await ap.wait_for_timeout(200)
            copied = await ap.evaluate("window.__copied") or ""
            ok(await ap.evaluate("window.__shared") is None, "シェアボタンでシェア画面は出さない")
            ok("http://localhost:8765/" in copied and copied.count("http") == 1 and ".apk" not in copied, "リンクをコピーする: " + copied.replace(chr(10), " "))
            ok(await ap.is_visible("#copied") and "コピーしたよ" in await ap.inner_text("#status"), "「コピーしたよ」と出る")
            await ap.click("#invite"); await ap.wait_for_timeout(200)
            ok((await ap.evaluate("window.__copied") or "") == copied, "「メンバーを追加」でも同じリンクをコピー")
            # 「ブラウザ」を押した瞬間にブラウザで使える（ページ移動なし）
            ok(ap.url.startswith("http://localhost"), "「ブラウザ」を押してもページは移動しない")
            # マイクが使えないブラウザでも「聞くだけ」で入れる
            nctx = await b.new_context()
            np_ = await nctx.new_page()
            await np_.add_init_script(FAKE_WS)
            await np_.add_init_script("Object.defineProperty(navigator, 'mediaDevices', { configurable: true, value: undefined });")
            await np_.goto("http://localhost:8765/index.html")
            await np_.click("#useBrowser"); await np_.fill("#displayName", "Discordの中"); await np_.click("#setName"); await np_.click("#chLobby"); await np_.click("#join")
            await np_.wait_for_timeout(600)
            ok(await np_.is_visible("#leave") and await np_.evaluate("window.__sockets.length") >= 1, "マイクが使えないブラウザでも通話に入れる（聞くだけ）")
            ok("聞くだけ" in await np_.inner_text("#status") and "Chrome" in await np_.inner_text("#status"), "どうすればいいか表示: " + await np_.inner_text("#status"))
            # マイクを拒否しても入れる
            dctx = await b.new_context()
            dp = await dctx.new_page()
            await dp.add_init_script(FAKE_WS)
            await dp.add_init_script("navigator.mediaDevices.getUserMedia = () => Promise.reject(Object.assign(new Error('x'), {name:'NotAllowedError'}));")
            await dp.goto("http://localhost:8765/index.html")
            await dp.click("#useBrowser"); await dp.fill("#displayName", "拒否した人"); await dp.click("#setName"); await dp.click("#chLobby"); await dp.click("#join")
            await dp.wait_for_timeout(600)
            ok(await dp.is_visible("#leave") and "許可" in await dp.inner_text("#status"), "マイクを拒否しても入れて、許可のしかたが出る")
            # AudioWorklet がない古いブラウザでも入れる（マイクあり）
            octx = await b.new_context(permissions=["microphone"])
            op = await octx.new_page()
            await op.add_init_script(FAKE_WS)
            await op.add_init_script("window.AudioWorkletNode = undefined;")
            await op.goto("http://localhost:8765/index.html")
            await op.click("#useBrowser"); await op.fill("#displayName", "古いスマホ"); await op.click("#setName"); await op.click("#chLobby"); await op.click("#join")
            await op.wait_for_timeout(1500)
            osent = await op.evaluate("window.__sent")
            ok(await op.is_visible("#leave") and "聞くだけ" not in await op.inner_text("#status") and any(x.startswith("[binary 640") for x in osent), "AudioWorkletがない古いブラウザでも声が送れる")
            # 声がちゃんと鳴る（届いた声を再生している・音量1）
            hctx = await b.new_context(permissions=["microphone"])
            hp = await hctx.new_page()
            await hp.add_init_script(FAKE_WS)
            await hp.add_init_script("""window.__played=0; window.__peak=0; const _st=AudioBufferSourceNode.prototype.start;
              AudioBufferSourceNode.prototype.start=function(){ window.__played++; try{ const d=this.buffer.getChannelData(0); for(let i=0;i<d.length;i++) window.__peak=Math.max(window.__peak,Math.abs(d[i])); }catch(e){} return _st.apply(this,arguments); };""")
            await hp.goto("http://localhost:8765/index.html")
            await hp.click("#useBrowser"); await hp.fill("#displayName", "聞く人"); await hp.click("#setName"); await hp.click("#chLobby"); await hp.click("#join")
            await hp.wait_for_timeout(500)
            await hp.evaluate("""() => { const w=window.__sockets[0];
              w._recv({t:'hello', id:5, host:false});
              w._recv({t:'members', mc:false, list:[{id:5,name:'聞く人',mc:'聞く人'},{id:2,name:'話す人',mc:'話す人'}]});
              let n=0; const f=()=>{ if(n++<25){ w._recvBin([2].concat(Array(640).fill(0x10))); setTimeout(f,40);} }; f(); }""")
            await hp.wait_for_timeout(500)
            talk_green = await hp.evaluate("document.querySelector('.tile.talk') !== null")
            await hp.wait_for_timeout(1000)
            played = await hp.evaluate("window.__played"); peak = await hp.evaluate("window.__peak")
            ok(played >= 20 and peak > 0.3, f"ブラウザで相手の声を再生している（{played}回・音の大きさ {peak:.2f}）")
            ok(talk_green, "話している人のタイルが緑になる")
            # iPhone: マナーモードでも鳴るように <audio> を通して鳴らす
            ictx = await b.new_context(permissions=["microphone"], user_agent="Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1")
            ip = await ictx.new_page()
            await ip.add_init_script(FAKE_WS)
            await ip.goto("http://localhost:8765/index.html")
            await ip.click("#useBrowser"); await ip.fill("#displayName", "iPhoneの人"); await ip.click("#setName"); await ip.click("#chLobby"); await ip.click("#join")
            await ip.wait_for_timeout(800)
            ok(await ip.evaluate("(() => { const a=document.getElementById('voiceOut'); return !!a.srcObject && !a.paused; })()"), "iPhoneでは<audio>で鳴らす（マナーモード対策）")
            # 退出すると止まる
            await ip.click("#leave"); await ip.wait_for_timeout(200)
            ok(await ip.evaluate("document.getElementById('voiceOut').srcObject === null"), "退出すると<audio>も止まる")
            # 初めての人へ: やり方を1つずつ（吹き出し）
            gctx = await b.new_context(permissions=["microphone"], viewport={"width":390,"height":844})
            gp = await gctx.new_page()
            await gp.add_init_script(FAKE_WS)
            await gp.goto("http://localhost:8765/index.html")
            await gp.wait_for_timeout(500)
            async def gtext(): return (await gp.inner_text("#guideText")) if await gp.is_visible("#guide") else ""
            steps = []
            steps.append(await gtext()); await gp.click("#useBrowser"); await gp.wait_for_timeout(400)
            steps.append(await gtext())
            await gp.click("#randomName"); await gp.wait_for_timeout(400)
            rn = await gp.input_value("#displayName")
            steps.append(await gtext()); await gp.click("#setName"); await gp.wait_for_timeout(400)
            steps.append(await gtext()); await gp.click("#chLobby"); await gp.wait_for_timeout(400)
            steps.append(await gtext()); await gp.fill("#mcName", "gopura777"); await gp.wait_for_timeout(400)
            steps.append(await gtext())
            ok([x[:1] for x in steps] == ["①","②","③","④","⑤","⑥"], "吹き出しが①〜⑥の順に出る: " + " / ".join(x[:12] for x in steps))
            ok("ブラウザ" in steps[0] and "名前" in steps[1] and "ランダム" in steps[1] and "決定" in steps[2] and "待機所" in steps[3] and "マイクラ" in steps[4] and "入る" in steps[5], "吹き出しの中身")
            ok(len(rn) >= 2, "🎲 ランダムで名前が入る: " + rn)
            names = set()
            for _ in range(30):
                await gp.evaluate("document.getElementById('randomName').click()")
                names.add(await gp.input_value("#displayName"))
            ok(len(names) >= 10, "ランダムの名前はいろいろ出る: " + "、".join(list(names)[:8]))
            await gp.click("#join"); await gp.wait_for_timeout(700)
            ok(not await gp.is_visible("#guide"), "通話に入ったら吹き出しは消える")
            await gp.click("#leave"); await gp.wait_for_timeout(500)
            ok(not await gp.is_visible("#guide"), "1回入れたら、次からは出さない")
            await gp.click("#guideOn"); await gp.wait_for_timeout(500)
            ok(await gp.is_visible("#guide") and (await gtext())[:1] in "④⑤⑥", "「❓ やり方を1つずつ見る」でまた出る: " + (await gtext())[:10])
            await gp.click("#guideClose"); await gp.wait_for_timeout(400)
            ok(not await gp.is_visible("#guide"), "✕で消せる")
            # QRコードのページ（?qr=1）: カメラで読めるか、本物の読み取り機で確かめる
            qp = await gctx.new_page()
            await qp.goto("http://localhost:8765/index.html?qr=1")
            await qp.wait_for_timeout(500)
            ok(await qp.is_visible("#qrCanvas") and not await qp.is_visible("#android") and not await qp.is_visible("#namePanel") and not await qp.is_visible("#guide"), "QRのページはQRだけ出る")
            await qp.locator("#qrCanvas").screenshot(path="/tmp/qr_shot.png")
            import cv2 as _cv
            dec, _, _ = _cv.QRCodeDetector().detectAndDecode(_cv.imread("/tmp/qr_shot.png"))
            ok(dec == "http://localhost:8765/", "QRコードを読みとると参加のページになる: " + repr(dec))
            ok((await qp.get_attribute("#qrSave", "href") or "").startswith("data:image/png"), "QRの画像を保存できる")
            # オーナーが落ちて位置が止まっても、みんなそのまま（10秒たっても元の通話に戻らない）
            fctx = await b.new_context(permissions=["microphone"])
            fp = await fctx.new_page()
            await fp.add_init_script(FAKE_WS)
            await fp.goto("http://localhost:8765/index.html")
            await fp.click("#useBrowser"); await fp.fill("#displayName", "サブ垢"); await fp.click("#setName"); await fp.click("#chLobby"); await fp.fill("#mcName", "saradayou509"); await fp.click("#join")
            await fp.wait_for_timeout(400)
            await fp.evaluate("""() => { const w=window.__sockets[0];
              w._recv({t:'pos', p:{gopura777:{x:0,y:64,z:0,d:0,r:0}, saradayou509:{x:30,y:64,z:0,d:0,r:0}}});
              w._recv({t:'members', mc:true, list:[{id:1,name:'むいいむ',mc:'gopura777',host:true,slot:1},{id:2,name:'サブ垢',mc:'saradayou509',slot:2}]});
              w._recv({t:'members', mc:true, list:[{id:2,name:'サブ垢',mc:'saradayou509',slot:2},{id:3,name:'友達',mc:'tomo',slot:3}]}); }""")
            await fp.evaluate("() => { const w=window.__sockets[0]; w._recv({t:'pos', p:{saradayou509:{x:30,y:64,z:0,d:0,r:0}, tomo:{x:200,y:64,z:0,d:0,r:0}}}); }")
            await fp.wait_for_timeout(6500)
            ok("部屋2" in await fp.inner_text("#roomLabel"), "オーナーが落ちて位置が止まっても、部屋2のまま（待機所に戻らない）")
            g_far = await fp.evaluate("(() => { var x = 0; document.querySelectorAll('#tiles .tile').forEach(function(){ x++; }); return x; })()")
            ok(g_far == 2, "タイルもそのまま")
            # 聞こえない時のボタン: テストの音 → 聞こえなければスピーカーモード（エコー消しなし）
            sctx = await b.new_context(permissions=["microphone"])
            sp_ = await sctx.new_page()
            await sp_.add_init_script(FAKE_WS)
            await sp_.add_init_script("""window.__osc=0; const _os=OscillatorNode.prototype.start; OscillatorNode.prototype.start=function(){ window.__osc++; return _os.apply(this,arguments); };
              window.__gum=[]; const _g=navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices); navigator.mediaDevices.getUserMedia=(c)=>{ window.__gum.push(JSON.stringify(c)); return _g(c); };
              window.__toDest=0; const _c=AudioNode.prototype.connect; AudioNode.prototype.connect=function(t){ if (t instanceof AudioDestinationNode && this instanceof GainNode && this.gain.value>1) window.__toDest++; return _c.apply(this,arguments); };""")
            await sp_.goto("http://localhost:8765/index.html")
            await sp_.click("#useBrowser"); await sp_.fill("#displayName", "聞こえない人"); await sp_.click("#setName"); await sp_.click("#chLobby"); await sp_.click("#join")
            await sp_.wait_for_timeout(600)
            ok(await sp_.evaluate("window.__toDest") >= 1, "相手の声は大きめにして出口（スピーカー）につながっている")
            ok(await sp_.is_visible("#hearHelp"), "「相手の声が聞こえない時はここ」ボタンがある")
            sp_.once("dialog", lambda d: asyncio.ensure_future(d.dismiss()))
            await sp_.click("#hearHelp")
            await sp_.wait_for_timeout(1500)
            ok(await sp_.evaluate("window.__osc") >= 2, "テストの「ピッ」が鳴る（切り替えたあとももう一回）")
            gum = await sp_.evaluate("window.__gum")
            ok(len(gum) >= 2 and '"echoCancellation":false' in gum[-1], "聞こえない → スピーカーモード（エコー消しなし）に切り替え: " + str(gum[-1:]))
            ok("スピーカーモード" in await sp_.inner_text("#status"), "スピーカーモードにしたと出る")
            await sp_.wait_for_timeout(1200)
            ssent = await sp_.evaluate("window.__sent")
            ok(any(x.startswith("[binary 640") for x in ssent[-20:]), "切り替えたあとも自分の声が送れる")
            # 新しい版が出たら: 通話してなければ自動で読み込み直す、通話中ならお知らせ
            vctx = await b.new_context(permissions=["microphone"])
            vp = await vctx.new_page()
            await vp.add_init_script(FAKE_WS)
            await vp.add_init_script("window.setInterval = ((si) => function(f, t){ return si(f, t === 60000 ? 300 : t); })(window.setInterval);")
            await vp.route("**/api/version", lambda r: asyncio.ensure_future(r.fulfill(status=200, content_type="application/json", body='{"build":"B2"}')))
            loads = []
            vp.on("load", lambda: loads.append(1))
            await vp.goto("http://localhost:8765/index.html")
            await vp.wait_for_timeout(1200)
            ok(len(loads) >= 2, "通話してない時に新しい版が出たら自動で読み込み直す")
            await vp.route("**/api/version", lambda r: asyncio.ensure_future(r.fulfill(status=200, content_type="application/json", body='{"build":"B1"}')))
            await vp.wait_for_timeout(500)
            await vp.click("#useBrowser"); await vp.fill("#displayName", "通話中の人"); await vp.click("#setName"); await vp.click("#chLobby"); await vp.click("#join")
            await vp.wait_for_timeout(400)
            n0 = len(loads)
            await vp.route("**/api/version", lambda r: asyncio.ensure_future(r.fulfill(status=200, content_type="application/json", body='{"build":"B3"}')))
            await vp.wait_for_timeout(900)
            ok(len(loads) == n0 and await vp.is_visible("#updateNote") and await vp.is_visible("#leave"), "通話中は切らずに「新しい版が出たよ」とお知らせだけ")
            await vp.click("#leave"); await vp.wait_for_timeout(1000)
            ok(len(loads) > n0, "通話を抜けたら新しい版になる")
            await b.close()
    finally:
        srv.terminate()
    print("ALL OK" if not fails else f"FAILED {len(fails)}")
asyncio.run(main())
