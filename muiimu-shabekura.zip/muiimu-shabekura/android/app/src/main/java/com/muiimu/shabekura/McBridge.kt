package com.muiimu.shabekura

import android.util.Log
import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import java.net.InetSocketAddress
import java.util.UUID

/**
 * ホストのスマホの中で動く小さなサーバー。
 * マイクラで「/connect 127.0.0.1:19131」すると、ここにつながる。
 * やりとりの中身は BridgeLogic（パソコンで何万回もテスト済み）にまかせて、
 * ここは「送る・受け取る」だけをする。
 */
class McBridge(
    private val names: () -> List<String>,
    private val hostName: () -> String,
    private val onPositions: (Map<String, Pos>) -> Unit,
    private val onLinked: (Boolean) -> Unit,
    private val onInfo: (String) -> Unit,
    private val onFail: (String) -> Unit,
) : WebSocketServer(InetSocketAddress("127.0.0.1", PORT)) {

    companion object {
        const val PORT = 19131
        const val COMMAND = "/connect 127.0.0.1:19131"
        private const val POLL_MS = 200L
        private const val TAG = "McBridge"
    }

    @Volatile private var conn: WebSocket? = null
    @Volatile private var alive = true
    private var poller: Thread? = null
    private val logic = BridgeLogic { UUID.randomUUID().toString() }

    init {
        isReuseAddr = true
        connectionLostTimeout = 0
    }

    override fun onStart() {
        poller = Thread({ pollLoop() }, "shabekura-mc").also { it.start() }
    }

    override fun onOpen(c: WebSocket, handshake: ClientHandshake?) {
        val old = conn
        conn = c
        if (old != null && old != c) try { old.close() } catch (_: Exception) {}
        val hello = synchronized(logic) { logic.reset(); logic.greeting() }
        onLinked(true)
        try { c.send(hello) } catch (_: Exception) {}
    }

    override fun onClose(c: WebSocket, code: Int, reason: String?, remote: Boolean) {
        if (c == conn) {
            conn = null
            synchronized(logic) { logic.reset() }
            onLinked(false)
            onInfo("")
        }
    }

    override fun onError(c: WebSocket?, ex: Exception) {
        Log.w(TAG, "error", ex)
        if (c == null) onFail("連携用ポートを開けませんでした: ${ex.message}")
    }

    override fun onMessage(c: WebSocket, message: String) {
        if (c != conn) return
        try {
            synchronized(logic) { logic.onMessage(message, System.currentTimeMillis()) }
        } catch (e: Exception) {
            Log.w(TAG, "bad message", e)
        }
    }

    private fun pollLoop() {
        while (alive) {
            try { Thread.sleep(POLL_MS) } catch (_: InterruptedException) { break }
            val c = conn ?: continue
            if (!c.isOpen) continue
            try {
                val now = System.currentTimeMillis()
                val members = names()
                val host = hostName()
                val (cmds, snap, info) = synchronized(logic) {
                    val cmds = logic.tick(now, members)
                    val snap = logic.snapshot(now, members, host)
                    Triple(cmds, snap, logic.info(now, members, snap))
                }
                for (cmd in cmds) {
                    try { c.send(cmd) } catch (_: Exception) { break }
                }
                onPositions(snap)
                onInfo(info)
            } catch (e: Exception) {
                // 1回失敗しても止まらずに続ける
                Log.w(TAG, "poll", e)
            }
        }
    }

    fun shutdown() {
        alive = false
        poller?.interrupt()
        try { stop(500) } catch (_: Exception) {}
    }
}
