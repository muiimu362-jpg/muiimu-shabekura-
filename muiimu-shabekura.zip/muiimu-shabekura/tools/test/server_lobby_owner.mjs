import { Room } from "./idx.mjs";
class WS { constructor(){this.readyState=1;this.sent=[];this.att=null;} send(m){this.sent.push(m)} close(c){this.readyState=3;this.closed=c} serializeAttachment(a){this.att=a} deserializeAttachment(){return this.att} }
globalThis.WebSocketPair=function(){ return {0:new WS(),1:new WS()}; };
globalThis.Response=class{constructor(b,o){this.body=b;this.status=(o&&o.status)||200;} json(){return JSON.parse(this.body)}};
let fails=0; const ok=(c,m)=>{ if(!c){fails++; console.log("FAIL:",m);} };
const store=new Map(); const sockets=[];
const r=new Room({getWebSockets:()=>sockets,acceptWebSocket:w=>sockets.push(w),storage:{get:async k=>store.get(k),put:async(k,v)=>store.set(k,v)}},{BUILD_ID:"v1"});
const join=async(n,dev,role="")=>{ await r.fetch({url:`https://x/ws?room=MUIIMU&name=${encodeURIComponent(n)}&dev=${dev}&role=${role}`}); return sockets.at(-1); };
const api=async(path,dev,method="GET")=>(await r.fetch({url:`https://x${path}?room=MUIIMU&dev=${dev}`+(path.includes("give")?"":""),method})).json();
const give=async(dev,id,method="POST")=>{ const res=await r.fetch({url:`https://x/api/give?room=MUIIMU&dev=${dev}&id=${id}`,method}); return [res.status,res.json()]; };
// オーナーがまだいない
let s=await api("/api/state","DEV-A"); ok(!s.isOwner && !s.hasOwner, "最初はオーナーなし");
const a=await join("むいいむ","DEV-A"); const b=await join("サブ垢","DEV-B"); const b2=b; const br=await join("むいいむ","DEV-A","bridge");
// 通話を抜けてロビー画面にいても、自分がオーナーだと分かる
a.readyState=3;
s=await api("/api/state","DEV-A"); ok(s.isOwner && s.members.length===1 && s.members[0].name==="サブ垢", "ロビーでもオーナーと分かり、渡す相手が出る（連携だけは出ない）: "+JSON.stringify(s));
s=await api("/api/state","DEV-B"); ok(!s.isOwner && s.members.length===0, "オーナー以外には一覧を出さない");
// オーナー以外は渡せない
let [st]=await give("DEV-B", b.att.id); ok(st===403 && store.get("ownerDev2")==="DEV-A", "オーナー以外は渡せない");
[st]=await give("", b.att.id); ok(st===403, "端末IDなしは渡せない");
[st]=await give("DEV-A", b.att.id, "GET"); ok(st===405 && store.get("ownerDev2")==="DEV-A", "GETでは渡せない");
[st]=await give("DEV-A", 999); ok(st===404 && store.get("ownerDev2")==="DEV-A", "いない人には渡せない");
[st]=await give("DEV-A", br.att.id); ok(st===404, "連携だけの接続には渡せない");
// 渡す
[st]=await give("DEV-A", b.att.id); ok(st===200 && store.get("ownerDev2")==="DEV-B", "ロビーからオーナーを渡せた");
ok(JSON.parse(b.sent.filter(x=>x.includes('"t":"owner"')).at(-1)).host===true, "渡された人に知らせが届く");
ok(br.closed===4011, "前のオーナーの連携だけは終わる");
s=await api("/api/state","DEV-A"); ok(!s.isOwner && s.ownerName==="サブ垢", "渡したあとはオーナーじゃない・新オーナーの名前が分かる");
// 入る前の画面用: だれがどこにいるか（名前と部屋だけ・オーナー以外にも見える）
const c=await join("友達","DEV-C");
await r.webSocketMessage(b2, JSON.stringify({t:"pos", p:{"サブ垢":{x:0,y:64,z:0,d:0,r:0}}}));
s=await api("/api/state","DEV-X");
const names=(s.people||[]).map(p=>p.name).sort().join(",");
ok(names==="サブ垢,友達" , "だれでも今いる人の名前が見える（連携だけ・抜けた人は出ない）: "+JSON.stringify(s.people));
ok((s.people.find(p=>p.name==="サブ垢")||{}).slot>0 && (s.people.find(p=>p.name==="友達")||{}).slot===0, "部屋にいる人は部屋番号、待機所の人は0");
ok(!JSON.stringify(s).includes("DEV-"), "端末IDは見えない");
// 休憩中: 前に来て今いない人（新しい順）
a.readyState=3; await r.webSocketClose(a,1000,"bye");
s=await api("/api/state","DEV-X");
ok((s.resting||[]).some(p=>p.name==="むいいむ") && !(s.resting||[]).some(p=>p.name==="サブ垢"||p.name==="友達"), "抜けた人は「休憩中」、今いる人は出ない: "+JSON.stringify(s.resting));
console.log(fails?"FAILED "+fails:"ALL OK");
