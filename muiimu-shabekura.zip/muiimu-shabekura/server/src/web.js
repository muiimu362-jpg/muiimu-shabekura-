// iPhone・PC 用の Web 版（サーバーから配る）
// 注意: このファイルの中のスクリプトではバッククォートと「ドル記号+波かっこ」を使わないこと
// Android 用 APK の直接ダウンロード先（GitHub のリリース）
const APK_URL = "https://github.com/muiimu362-jpg/muiimu-shabekura-/releases/latest/download/MuiimuShabekura.apk";
const WEB_HTML_RAW = `<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="しゃべくら">
<meta name="theme-color" content="#2E5E2A">
<link rel="manifest" href="/manifest.json">
<link rel="apple-touch-icon" href="/icon.svg">
<title>むいいむ しゃべくら</title>
<style>
  :root { --g:#2E5E2A; --sub:#5B6B57; --bg:#F4F7F2; }
  * { box-sizing: border-box; }
  body { margin:0; background:var(--bg); color:#1F2A1D;
    font-family: -apple-system, "Hiragino Sans", "Noto Sans JP", sans-serif; }
  main { max-width: 480px; margin: 0 auto; padding: 20px 20px calc(24px + env(safe-area-inset-bottom)); }
  h1 { color:var(--g); font-size:26px; margin:8px 0 2px; }
  .sub { color:var(--sub); font-size:13px; margin-bottom:18px; }
  label { display:block; color:var(--g); font-weight:700; font-size:14px; margin-top:14px; }
  input { width:100%; font-size:18px; padding:12px; border:1px solid #C9D3C5; border-radius:10px; margin-top:6px; background:#fff; }
  button { width:100%; font-size:17px; padding:15px; border:0; border-radius:12px; margin-top:12px;
    background:var(--g); color:#fff; font-weight:700; }
  button.sec { background:#DDE6D9; color:#1F2A1D; }
  .row { display:flex; gap:10px; } .row button { flex:1; }
  .room { font-size:22px; font-weight:700; }
  .mc { margin-top:10px; padding:10px; border-radius:10px; background:#EDEDED; font-size:15px; }
  .mc.on { background:#DDF3D3; }
  #members { background:#fff; border-radius:10px; padding:12px; margin-top:6px; font-size:16px; line-height:1.9; }
  #status { color:var(--sub); margin-top:16px; min-height:1.2em; }
  .note { color:#8A9586; font-size:12px; margin-top:12px; line-height:1.6; }
  .hidden { display:none; }
</style>
</head>
<body>
<main>
  <h1>むいいむ しゃべくら</h1>
  <div class="sub">むいいむ通話 ・ 近づくと聞こえるボイスチャット（Web版）</div>

  <section id="android" class="hidden">
    <div class="room" id="aRoom"></div>
    <button id="openApp">アプリで開く</button>
    <a id="dlApk" href="__APK_URL__"><button class="sec">アプリをダウンロード（初めての人）</button></a>
    <div class="note">
      ・アプリが入っていれば「アプリで開く」で、ルームコード入りでアプリが開きます。<br>
      ・入っていない人は「アプリをダウンロード」→ ダウンロードしたファイルを開いてインストール →もう一度このページの「アプリで開く」を押してね。<br>
      ・インストール時に「提供元不明のアプリ」の許可を聞かれたら許可してください。
    </div>
  </section>

  <section id="setup">
    <label for="name">マイクラの名前（Switch・PS なら、そのマイクラで表示される名前）</label>
    <input id="name" autocomplete="off" autocapitalize="off" placeholder="例: Muiimu1234">
    <label for="room">ルームコード（6文字）</label>
    <input id="room" autocomplete="off" autocapitalize="characters" maxlength="6" placeholder="むいいむにもらったコード">
    <button id="join">通話に入る</button>
  </section>

  <section id="call" class="hidden">
    <div class="room" id="roomLabel"></div>
    <div class="mc" id="mc"></div>
    <div class="row">
      <button id="mute" class="sec">ミュート</button>
      <button id="deafen" class="sec">スピーカーミュート</button>
      <button id="leave" class="sec">退出</button>
    </div>
    <button id="optout" class="sec hidden">通話を抜ける</button>
    <label>参加中のメンバー</label>
    <div id="members"></div>
  </section>

  <div id="status"></div>
  <div class="note" id="webNote">
    ・このページは開いたまま（画面をつけたまま）にしてね。別のアプリに切り替えると声が止まります。<br>
    ・iPhoneで同じ端末のマイクラを遊ぶ場合は声が止まるので、Switch・PS・PCで遊ぶときの「横に置く用」に使ってね。<br>
    ・Safariの共有ボタン →「ホーム画面に追加」でアプリみたいに使えます。<br>
    ・イヤホン推奨。
  </div>
</main>

<script>
(function () {
  var RATE = 16000, FRAME = 640, VAD_LEVEL = 280, VAD_HANG = 8;
  var FULL = 3, MAX = 24;
  function $(id) { return document.getElementById(id); }

  // ---- μ-law ----
  var DEC = new Float32Array(256);
  (function () {
    for (var u = 0; u < 256; u++) {
      var x = (~u) & 0xFF, sign = x & 0x80, e = (x >> 4) & 7, m = x & 0x0F;
      var mag = (((m << 3) + 0x84) << e) - 0x84;
      DEC[u] = (sign ? -mag : mag) / 32768;
    }
  })();
  function enc(s) {
    var sign = 0;
    if (s < 0) { s = -s; sign = 0x80; }
    if (s > 32635) s = 32635;
    s += 0x84;
    var e = 7, mask = 0x4000;
    while ((s & mask) === 0 && e > 0) { e--; mask >>= 1; }
    var m = (s >> (e + 3)) & 0x0F;
    return (~(sign | (e << 4) | m)) & 0xFF;
  }

  // ---- 状態 ----
  var ws = null, ctx = null, stream = null, running = false, retry = 0;
  var myName = "", room = "", muted = false, deafened = false, mySlot = 0, optOut = false, selfTalking = false, hang = 0;
  var members = {}, positions = {}, mcOn = false, lastPos = 0;
  var speakers = {};
  var inBuf = [], rpos = 0, frame = new Int16Array(FRAME), fpos = 0;
  var wakeLock = null;

  try {
    $("name").value = localStorage.getItem("name") || "";
    $("room").value = localStorage.getItem("room") || "";
  } catch (e) {}
  var qp = new URLSearchParams(location.search).get("room");
  if (qp) $("room").value = qp.toUpperCase();

  // Android はブラウザではなくアプリを使う
  if (/Android/i.test(navigator.userAgent)) {
    var code = (qp || "").toUpperCase();
    var valid = /^[A-Z0-9]{6}$/.test(code);
    $("setup").classList.add("hidden");
    $("webNote").classList.add("hidden");
    $("android").classList.remove("hidden");
    $("aRoom").textContent = valid ? ("ルームコード: " + code) : "むいいむ通話";
    var apk = $("dlApk").getAttribute("href");
    var intentUrl = "intent://join" + (valid ? ("?room=" + code) : "") +
      "#Intent;scheme=shabekura;package=com.muiimu.shabekura;S.browser_fallback_url=" +
      encodeURIComponent(apk) + ";end";
    $("openApp").onclick = function () { location.href = intentUrl; };
    // ページを開いたら自動でアプリを開いてみる
    setTimeout(function () { location.href = intentUrl; }, 300);
  }

  function setStatus(t) { $("status").textContent = t; }

  $("join").onclick = function () { join().catch(function (e) { setStatus("開始できませんでした: " + e.message); stop(); }); };
  $("leave").onclick = function () { stop(); setStatus("退出しました"); };
  $("mute").onclick = function () { muted = !muted; render(); };
  $("optout").onclick = function () {
    optOut = !optOut;
    if (ws && ws.readyState === 1) ws.send(JSON.stringify({ t: "optout", on: optOut }));
    render();
  };
  $("deafen").onclick = function () {
    deafened = !deafened;
    for (var id in speakers) speakers[id].next = 0;
    render();
  };

  async function join() {
    myName = $("name").value.trim();
    room = $("room").value.trim().toUpperCase();
    if (!myName) { setStatus("マイクラの名前を入れてね"); return; }
    if (!/^[A-Z0-9]{6}$/.test(room)) { setStatus("ルームコードは英数字6文字だよ"); return; }
    try { localStorage.setItem("name", myName); localStorage.setItem("room", room); } catch (e) {}

    try { if (navigator.audioSession) navigator.audioSession.type = "play-and-record"; } catch (e) {}
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    await ctx.resume();
    stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 }
    });
    var code = "class C extends AudioWorkletProcessor{process(i){var c=i[0]&&i[0][0];if(c)this.port.postMessage(c.slice(0));return true}}registerProcessor('cap',C);";
    await ctx.audioWorklet.addModule(URL.createObjectURL(new Blob([code], { type: "application/javascript" })));
    var src = ctx.createMediaStreamSource(stream);
    var node = new AudioWorkletNode(ctx, "cap");
    var sink = ctx.createGain(); sink.gain.value = 0;
    src.connect(node); node.connect(sink); sink.connect(ctx.destination);
    node.port.onmessage = function (e) { onMic(e.data); };

    running = true; retry = 0;
    $("setup").classList.add("hidden");
    $("call").classList.remove("hidden");
    keepAwake();
    connect();
    render();
  }

  function onMic(chunk) {
    var ratio = ctx.sampleRate / RATE;
    for (var i = 0; i < chunk.length; i++) inBuf.push(chunk[i]);
    while (rpos + 1 < inBuf.length) {
      var k = Math.floor(rpos), t = rpos - k;
      var v = inBuf[k] * (1 - t) + inBuf[k + 1] * t;
      frame[fpos++] = Math.max(-32768, Math.min(32767, Math.round(v * 32767)));
      rpos += ratio;
      if (fpos === FRAME) { fpos = 0; onFrame(); }
    }
    var drop = Math.floor(rpos);
    if (drop > 0) { inBuf = inBuf.slice(drop); rpos -= drop; }
  }

  function onFrame() {
    var sum = 0;
    for (var i = 0; i < FRAME; i++) sum += frame[i] * frame[i];
    var rms = Math.sqrt(sum / FRAME);
    if (rms > VAD_LEVEL) hang = VAD_HANG; else if (hang > 0) hang--;
    selfTalking = !muted && !deafened && hang > 0;
    if (!selfTalking || mySlot <= 0 || !ws || ws.readyState !== 1) return;
    var out = new Uint8Array(FRAME);
    for (var j = 0; j < FRAME; j++) out[j] = enc(frame[j]);
    ws.send(out);
  }

  function connect() {
    if (!running) return;
    var url = location.origin.replace(/^http/, "ws") + "/ws?room=" + encodeURIComponent(room) +
      "&name=" + encodeURIComponent(myName) + "&key=";
    var s = new WebSocket(url);
    s.binaryType = "arraybuffer";
    ws = s;
    setStatus("接続中…");
    s.onopen = function () { if (ws === s) { retry = 0; setStatus("通話中"); } };
    s.onmessage = function (e) {
      if (ws !== s) return;
      if (typeof e.data === "string") onText(e.data);
      else onAudio(new Uint8Array(e.data));
    };
    s.onclose = function (e) {
      if (ws !== s) return;
      if (e.code === 4004) { setStatus("その通話は見つかりません（コードを確認してね）"); stop(); return; }
      if (e.code === 4009) { setStatus("別の端末から同じ名前で入りました"); stop(); return; }
      if (e.code === 4010) { setStatus("通話が満員です"); stop(); return; }
      if (!running) return;
      retry++;
      setStatus("再接続中…");
      setTimeout(connect, Math.min(10000, 1000 * retry));
    };
  }

  function onText(text) {
    var m; try { m = JSON.parse(text); } catch (e) { return; }
    if (m.t === "members") {
      members = {};
      mySlot = 0;
      (m.list || []).forEach(function (x) {
        members[x.id] = x;
        if (x.name === myName) { mySlot = x.slot || 0; optOut = !!x.out; }
      });
      if (m.mc === false) mcOn = false;
      for (var id in speakers) if (!members[id]) delete speakers[id];
      recompute();
    } else if (m.t === "pos") {
      positions = m.p || {}; mcOn = true; lastPos = Date.now(); recompute();
    } else if (m.t === "mc") {
      mcOn = !!m.on; if (!mcOn) positions = {}; recompute();
    }
  }

  function speaker(id) {
    var s = speakers[id];
    if (s) return s;
    var g = ctx.createGain();
    var p = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
    if (p) { g.connect(p); p.connect(ctx.destination); } else g.connect(ctx.destination);
    s = speakers[id] = { gain: g, pan: p, next: 0, last: 0, g: 1 };
    return s;
  }

  function onAudio(u8) {
    if (u8.length < 2 || !ctx || deafened) return;
    var id = u8[0], n = u8.length - 1, sr = ctx.sampleRate;
    var outLen = Math.round(n * sr / RATE);
    var buf = ctx.createBuffer(1, outLen, sr);
    var d = buf.getChannelData(0), step = RATE / sr;
    for (var i = 0; i < outLen; i++) {
      var x = i * step, k = Math.floor(x), t = x - k;
      var a = DEC[u8[1 + Math.min(k, n - 1)]], b = DEC[u8[1 + Math.min(k + 1, n - 1)]];
      d[i] = a * (1 - t) + b * t;
    }
    var s = speaker(id);
    var now = ctx.currentTime;
    if (s.next < now + 0.02 || s.next > now + 0.5) s.next = now + 0.1;
    var node = ctx.createBufferSource();
    node.buffer = buf;
    node.connect(s.gain);
    node.start(s.next);
    s.next += buf.duration;
    s.last = Date.now();
  }

  function compute(me, o) {
    if (!me || !o || me.d !== o.d) return [0, 0];
    var dx = o.x - me.x, dy = o.y - me.y, dz = o.z - me.z;
    var dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
    var g = dist <= FULL ? 1 : dist >= MAX ? 0 : Math.pow((MAX - dist) / (MAX - FULL), 2);
    var yaw = (me.r || 0) * Math.PI / 180;
    var rx = -Math.cos(yaw), rz = -Math.sin(yaw);
    var len = Math.sqrt(dx * dx + dz * dz);
    var pan = len < 0.5 ? 0 : ((dx * rx + dz * rz) / len) * 0.8;
    return [g, pan, dist];
  }

  function recompute() {
    if (!ctx) return;
    var me = positions[myName];
    for (var id in members) {
      var mem = members[id];
      if (mem.name === myName) continue;
      // 自分も相手も部屋に入っているときだけ、距離に応じて聞こえる
      var r = (mcOn && mySlot > 0 && mem.slot > 0) ? compute(me, positions[mem.name]) : [0, 0];
      var full = compute(me, positions[mem.name]);
      var s = speaker(id);
      s.g = r[0]; s.dist = full.length > 2 ? full[2] : null;
      s.gain.gain.setTargetAtTime(r[0], ctx.currentTime, 0.05);
      if (s.pan) s.pan.pan.setTargetAtTime(r[1], ctx.currentTime, 0.05);
    }
    render();
  }

  function render() {
    $("roomLabel").textContent = "ルームコード: " + room;
    $("mute").textContent = muted ? "ミュート解除" : "ミュート";
    $("deafen").textContent = deafened ? "スピーカー解除" : "スピーカーミュート";
    var mc = $("mc");
    if (!mcOn) { mc.textContent = "⚪ 待機中：運営がマイクラで準備すると通話が始まるよ"; mc.className = "mc"; }
    else if (optOut) { mc.textContent = "⏸ 通話を抜けてるよ（「通話に戻る」で戻れる）"; mc.className = "mc"; }
    else if (mySlot > 0) { mc.textContent = "🟢 通話" + mySlot + " にいるよ：近くの人ほど大きく聞こえる"; mc.className = "mc on"; }
    else { mc.textContent = "🟡 待機中：マイクラのワールドに入ると、自動で通話に入るよ（名前がマイクラと同じか確認してね）"; mc.className = "mc"; }
    $("optout").classList.toggle("hidden", !mcOn);
    $("optout").textContent = optOut ? "通話に戻る" : "通話を抜ける";
    var box = $("members");
    box.textContent = "";
    var order = function (id) { var x = members[id]; return x.slot > 0 ? x.slot : 100 + Number(id); };
    var ids = Object.keys(members).sort(function (a, b) { return order(a) - order(b); });
    if (!ids.length) box.textContent = "接続中…";
    var now = Date.now();
    ids.forEach(function (id) {
      var mem = members[id], me = mem.name === myName, s = speakers[id];
      var talking = me ? selfTalking : (s && now - s.last < 350 && s.g > 0.01);
      var tag = !mcOn ? "" : mem.slot > 0 ? ("通話" + mem.slot + "  ") : mem.out ? "抜けてる  " : "待機中  ";
      var line = (talking ? "🔊 " : "　 ") + tag + mem.name + (mem.host ? " 👑" : "") + (me ? "（自分）" : "") +
        (me && deafened ? " スピーカーミュート中" : me && muted ? " ミュート中" : "");
      if (mcOn && !me && s && mem.slot > 0) {
        if (s.dist == null) line += "  — ワールドにいない";
        else line += "  " + Math.round(s.dist) + "m" + (s.g <= 0.01 ? "（遠くて聞こえない）" : "");
      }
      var div = document.createElement("div");
      div.textContent = line;
      box.appendChild(div);
    });
  }

  setInterval(function () {
    if (!running) return;
    if (mcOn && Date.now() - lastPos > 5000) { mcOn = false; positions = {}; recompute(); }
    else render();
  }, 250);

  async function keepAwake() {
    try { if (navigator.wakeLock) wakeLock = await navigator.wakeLock.request("screen"); } catch (e) {}
  }
  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible" && running) {
      keepAwake();
      if (ctx && ctx.state !== "running") ctx.resume();
    }
  });

  function stop() {
    running = false;
    var s = ws; ws = null;
    try { if (s) s.close(1000); } catch (e) {}
    try { if (stream) stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
    try { if (ctx) ctx.close(); } catch (e) {}
    try { if (wakeLock) wakeLock.release(); } catch (e) {}
    ctx = null; stream = null; speakers = {}; members = {}; positions = {}; mcOn = false; mySlot = 0; optOut = false;
    inBuf = []; rpos = 0; fpos = 0; selfTalking = false; muted = false; deafened = false;
    $("setup").classList.remove("hidden");
    $("call").classList.add("hidden");
  }
})();
</script>
</body>
</html>`;

export const WEB_HTML = WEB_HTML_RAW.replace("__APK_URL__", APK_URL);

export const MANIFEST = JSON.stringify({
  name: "むいいむ しゃべくら",
  short_name: "しゃべくら",
  start_url: "/",
  display: "standalone",
  background_color: "#F4F7F2",
  theme_color: "#2E5E2A",
  icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml" }],
});

export const ICON_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 108">
<rect width="108" height="108" rx="22" fill="#7EC8E3"/>
<path fill="#8B5A2B" d="M32,38h44v38h-44z"/>
<path fill="#5DAE3B" d="M32,38h44v12h-44z"/>
<path fill="#4A9130" d="M32,50h6v4h-6zM44,50h6v6h-6zM58,50h6v3h-6zM70,50h6v5h-6z"/>
<path fill="#FFFFFF" d="M56,24h26a6,6 0,0 1,6 6v12a6,6 0,0 1,-6 6h-14l-8,7v-7h-4a6,6 0,0 1,-6 -6v-12a6,6 0,0 1,6 -6z"/>
<path fill="#5DAE3B" d="M61,34h4v4h-4zM67,34h4v4h-4zM73,34h4v4h-4z"/>
</svg>`;
