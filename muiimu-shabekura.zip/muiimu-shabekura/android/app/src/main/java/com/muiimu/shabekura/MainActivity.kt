package com.muiimu.shabekura

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import okhttp3.RequestBody.Companion.toRequestBody
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class MainActivity : Activity() {

    companion object {
        /** みんなが入る「近接VC待機所」（決まったコード） */
        const val LOBBY = "MUIIMU"
        const val APK_URL = "https://github.com/muiimu362-jpg/muiimu-shabekura-/releases/latest/download/MuiimuShabekura.apk"
        const val ROOMS = 20
        private val AVATARS = intArrayOf(
            R.drawable.avatar_0, R.drawable.avatar_1, R.drawable.avatar_2,
            R.drawable.avatar_3, R.drawable.avatar_4, R.drawable.avatar_5,
        )
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var etMc: EditText
    private lateinit var etDisplayName: EditText
    private lateinit var namePanel: LinearLayout
    private lateinit var setupPanel: LinearLayout
    private lateinit var joinForm: LinearLayout
    private lateinit var tvBridgeToggle: TextView
    private var bridgeChoice = false
    private lateinit var callPanel: LinearLayout
    private lateinit var tvRoom: TextView
    private lateinit var tvMc: TextView
    private lateinit var llChannels: LinearLayout
    private lateinit var tvStatus: TextView
    private lateinit var btnCopyCmd: Button
    private lateinit var btnMute: ImageButton
    private lateinit var btnDeafen: ImageButton
    private lateinit var llTiles: LinearLayout
    private lateinit var listPanel: LinearLayout
    private lateinit var tvSub: TextView
    private var showList = false   // ⌄ でチャンネル一覧に切り替え
    private lateinit var btnOptOut: Button

    private val listener: () -> Unit = { render() }
    private var pendingStart: (() -> Unit)? = null
    private var linkCode: String? = null   // 招待リンクで別の部屋コードが来たとき

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("shabekura", Context.MODE_PRIVATE)
        loadUserVolumes()

        etMc = findViewById(R.id.etMc)
        etDisplayName = findViewById(R.id.etDisplayName)
        namePanel = findViewById(R.id.namePanel)
        setupPanel = findViewById(R.id.setupPanel)
        joinForm = findViewById(R.id.joinForm)
        tvBridgeToggle = findViewById(R.id.tvBridgeToggle)
        callPanel = findViewById(R.id.callPanel)
        tvRoom = findViewById(R.id.tvRoom)
        tvMc = findViewById(R.id.tvMc)
        llChannels = findViewById(R.id.llChannels)
        tvStatus = findViewById(R.id.tvStatus)
        btnCopyCmd = findViewById(R.id.btnCopyCmd)
        btnMute = findViewById(R.id.btnMute)
        btnDeafen = findViewById(R.id.btnDeafen)
        btnOptOut = findViewById(R.id.btnOptOut)
        llTiles = findViewById(R.id.llTiles)
        listPanel = findViewById(R.id.listPanel)
        tvSub = findViewById(R.id.tvSub)
        val toggleList = View.OnClickListener { showList = !showList; render() }
        findViewById<ImageButton>(R.id.btnCollapse).setOnClickListener(toggleList)
        findViewById<TextView>(R.id.tvRoom).setOnClickListener(toggleList)

        etMc.setText(prefs.getString("mc", ""))
        etDisplayName.setText(prefs.getString("displayName", ""))
        // 一番最初は「名前を決めてください」
        // 🎲 ランダムな名前（かっこいい名前・そこらへんにいそうな名前）
        findViewById<Button>(R.id.btnRandomName).setOnClickListener { etDisplayName.setText(randomName()) }
        // 📱 QR: 配信画面に出すQRコードのページを開く（スマホのカメラで読むと参加できる）
        findViewById<Button>(R.id.btnQrLobby).setOnClickListener {
            val url = VoiceService.serverBase() + "/?qr=1"
            try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))) } catch (_: Exception) { copy(url); toast("QRのページのリンクをコピーしたよ") }
        }
        findViewById<Button>(R.id.btnSetName).setOnClickListener {
            val n = etDisplayName.text.toString().trim()
            if (n.isEmpty()) { toast("名前を入れてね"); return@setOnClickListener }
            prefs.edit().putString("displayName", n).apply()
            render()
        }
        findViewById<TextView>(R.id.tvMyName).setOnClickListener {
            // 名前を変える
            prefs.edit().remove("displayName").apply()
            render()
        }

        findViewById<TextView>(R.id.tvVersion).text = "バージョン " + BuildConfig.VERSION_NAME
        if (VoiceService.serverBase().isEmpty()) {
            findViewById<View>(R.id.serverWarn).visibility = View.VISIBLE
        }

        // 近接VC待機所をタップすると、名前とオーナーの入力欄が出る
        findViewById<TextView>(R.id.chLobby).setOnClickListener {
            joinForm.visibility = if (joinForm.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            if (joinForm.visibility == View.VISIBLE) etMc.requestFocus()
        }
        tvBridgeToggle.setOnClickListener { bridgeChoice = !bridgeChoice; updateOwnerUi() }
        updateOwnerUi()
        buildRoomsPreview()

        findViewById<Button>(R.id.btnJoin).setOnClickListener { join() }
        // 右上の「オーナーを渡す」
        findViewById<Button>(R.id.btnGiveOwner).setOnClickListener { chooseNewOwner() }
        btnCopyCmd.setOnClickListener {
            copy(McBridge.COMMAND)
            Toast.makeText(this, "コピーしたよ！マイクラのチャットに貼り付けて送信してね", Toast.LENGTH_LONG).show()
        }
        // アプリをシェア（だれでも押せる。LINE や Discord などに送れる）
        val shareClick = View.OnClickListener { shareApp() }
        findViewById<ImageButton>(R.id.btnShareTop).setOnClickListener(shareClick)
        findViewById<ImageButton>(R.id.btnShareLobby).setOnClickListener(shareClick)
        findViewById<Button>(R.id.btnMembersLobby).setOnClickListener { showMembers() }
        findViewById<Button>(R.id.btnMembersTop).setOnClickListener { showMembers() }
        // 古いアプリのとき: 押すと新しいアプリをダウンロード
        findViewById<TextView>(R.id.tvUpdate).setOnClickListener {
            try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(APK_URL))) } catch (_: Exception) { copy(APK_URL); toast("ダウンロードのリンクをコピーしたよ") }
        }
        // 入る前の画面の右上「オーナーを渡す」（オーナーだけに出る）
        findViewById<Button>(R.id.btnGiveOwnerLobby).setOnClickListener { chooseNewOwnerLobby() }
        findViewById<LinearLayout>(R.id.cardInvite).setOnClickListener(shareClick)
        btnMute.setOnClickListener { VoiceService.instance?.setMuted(!AppState.muted) }
        btnDeafen.setOnClickListener { VoiceService.instance?.setDeafened(!AppState.deafened) }
        btnOptOut.setOnClickListener { VoiceService.instance?.setOptOut(!AppState.optOut) }
        // 配信に自分の声ものせる（覚えておく）
        // 長押し: 配信のテスト音（配信で「ピッピッピッ」が聞こえれば、声も配信にのる）
        findViewById<Button>(R.id.btnStreamVoice).setOnLongClickListener {
            VoiceService.instance?.testStreamBeep()
            toast(if (AppState.streamLinked) "🔔 配信アプリにテスト音を送ったよ（配信で聞こえればOK）" else "🔔 テスト音をスマホから鳴らしたよ（配信の内部音声で聞こえればOK）")
            true
        }
        findViewById<Button>(R.id.btnStreamVoice).setOnClickListener {
            val on = !AppState.streamVoice
            prefs.edit().putBoolean("streamVoice", on).apply()
            VoiceService.instance?.setStreamVoice(on)
            if (on) toast("📺 自分の声もスマホの音にまぜるよ。配信アプリの「内部音声」で、みんなの声と自分の声がのる（自分の声が少し聞こえるよ）")
        }

        findViewById<ImageButton>(R.id.btnLeave).setOnClickListener { VoiceService.leave(this) }

        askPermissions()
        handleLink(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleLink(intent)
    }

    /** 招待リンク（shabekura://join?room=XXXXXX）から開かれたとき */
    private fun handleLink(i: Intent?) {
        val data = i?.data ?: return
        if (data.scheme != "shabekura") return
        val code = data.getQueryParameter("room")?.trim()?.uppercase().orEmpty()
        linkCode = if (Regex("^[A-Z0-9]{6}$").matches(code) && code != LOBBY) code else null
        if (AppState.running) return
        joinForm.visibility = View.VISIBLE
        toast("「近接VC待機所」の「入る」を押してね")
    }

    override fun onResume() {
        super.onResume()
        AppState.addListener(listener)
        lobbyPoll.removeCallbacksAndMessages(null)
        lastVersionCheck = 0L
        lobbyPoll.post(lobbyTick)
        render()
    }

    override fun onPause() {
        lobbyPoll.removeCallbacksAndMessages(null)
        AppState.removeListener(listener)
        super.onPause()
    }

    private fun askPermissions() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val start = pendingStart
        pendingStart = null
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            start?.invoke()
        } else if (start != null) {
            toast("マイクの許可がないと通話できないよ（設定 → アプリ → 権限）")
        }
    }

    /** マイクの許可を確認してから通話を始める */
    private fun withMic(action: () -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            action()
        } else {
            pendingStart = action
            askPermissions()
        }
    }

    /** みんなに表示される名前（一番最初に決めたもの） */
    private fun myName(): String? {
        val name = prefs.getString("displayName", "").orEmpty().trim()
        if (name.isEmpty()) {
            render(); toast("先に名前を決めてね"); return null
        }
        return name
    }

    /** このスマホの端末ID（オーナーを覚えるのに使う。アプリを消さない限り変わらない） */
    private fun deviceId(): String {
        var d = prefs.getString("dev", "").orEmpty()
        if (d.isEmpty()) {
            d = java.util.UUID.randomUUID().toString()
            prefs.edit().putString("dev", d).apply()
        }
        return d
    }

    private fun join() {
        val name = myName() ?: return
        val mc = etMc.text.toString().trim()
        prefs.edit().putString("mc", mc).apply()
        if (bridgeChoice && mc.isEmpty()) {
            toast("配信用（連携だけ）は、マイクラの名前を入れてね"); return
        }
        val code = linkCode ?: LOBBY
        withMic { VoiceService.start(this, code, name, mc, deviceId(), bridgeChoice, prefs.getBoolean("streamVoice", false)) }
    }

    /** シェア = 招待のリンクをコピーするだけ（LINE や Discord に貼り付けて送る） */
    private fun shareApp() {
        val base = VoiceService.serverBase()
        copy("むいいむ通話に来てね！\n$base/")
        Toast.makeText(this, "📋 リンクをコピーしたよ！LINE や Discord に貼り付けて送ってね", Toast.LENGTH_LONG).show()
    }

    /** オーナーを渡す相手を選ぶ（アプリやブラウザで入っている人の一覧） */
    // ---- 入る前の画面: 自分がオーナーか・オーナーを渡す（サーバーに聞く） ----
    private class LobbyMember(val id: Int, val name: String)
    private var lobbyIsOwner = false
    private var lobbyOwnerName: String? = null
    private var lobbyHasOwner = true
    private var lobbyMembers: List<LobbyMember> = emptyList()
    private val lobbyPoll = Handler(Looper.getMainLooper())
    private val lobbyHttp by lazy { okhttp3.OkHttpClient() }
    private var lastVersionCheck = 0L
    private var appOutdated = false

    /** サーバーの版とちがったら「古いアプリだよ」を出す */
    private fun checkVersion() {
        val base = VoiceService.serverBase()
        if (base.isEmpty() || BuildStamp.ID == "dev") return
        Thread {
            try {
                val req = okhttp3.Request.Builder().url("$base/api/version").build()
                lobbyHttp.newCall(req).execute().use { res ->
                    val m = MiniJson.parse(res.body?.string() ?: "") as? Map<*, *> ?: return@use
                    val build = m["build"] as? String ?: return@use
                    runOnUiThread {
                        appOutdated = build != BuildStamp.ID
                        findViewById<TextView>(R.id.tvUpdate).visibility = if (appOutdated) View.VISIBLE else View.GONE
                    }
                }
            } catch (_: Exception) { }
        }.start()
    }

    private val lobbyTick = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (now - lastVersionCheck > 60_000) { lastVersionCheck = now; checkVersion() }
            refreshLobbyOwner() // 通話中も（メンバーの数・休憩中の一覧のため）
            lobbyPoll.postDelayed(this, 4000)
        }
    }

    private fun refreshLobbyOwner() {
        val base = VoiceService.serverBase()
        if (base.isEmpty()) return
        val url = "$base/api/state?room=$LOBBY&dev=" + java.net.URLEncoder.encode(deviceId(), "UTF-8")
        Thread {
            try {
                val req = okhttp3.Request.Builder().url(url).build()
                lobbyHttp.newCall(req).execute().use { res ->
                    val m = MiniJson.parse(res.body?.string() ?: "") as? Map<*, *> ?: return@use
                    val list = (m["members"] as? List<*>).orEmpty().mapNotNull {
                        val o = it as? Map<*, *> ?: return@mapNotNull null
                        val id = (o["id"] as? Number)?.toInt() ?: return@mapNotNull null
                        LobbyMember(id, o["name"]?.toString() ?: "")
                    }
                    val owner = m["isOwner"] == true
                    val ownerName = m["ownerName"] as? String
                    val hasOwner = m["hasOwner"] != false
                    val resting = (m["resting"] as? List<*>).orEmpty().mapNotNull {
                        val o = it as? Map<*, *> ?: return@mapNotNull null
                        val nm = o["name"]?.toString() ?: return@mapNotNull null
                        nm to ((o["last"] as? Number)?.toLong() ?: 0L)
                    }
                    val people = (m["people"] as? List<*>).orEmpty().mapNotNull {
                        val o = it as? Map<*, *> ?: return@mapNotNull null
                        LobbyPerson(o["name"]?.toString() ?: return@mapNotNull null, (o["slot"] as? Number)?.toInt() ?: 0, o["host"] == true)
                    }
                    runOnUiThread {
                        val changedPeople = people.map { Triple(it.name, it.slot, it.host) } != lobbyPeople.map { Triple(it.name, it.slot, it.host) }
                        lobbyPeople = people
                        lobbyResting = resting
                        if (changedPeople) buildRoomsPreview()
                        lobbyIsOwner = owner; lobbyOwnerName = ownerName; lobbyHasOwner = hasOwner; lobbyMembers = list
                        render()
                    }
                }
            } catch (_: Exception) { }
        }.start()
    }

    private fun chooseNewOwnerLobby() {
        // 通話中ならいつもの方法で渡す
        if (AppState.running) { chooseNewOwner(); return }
        val others = lobbyMembers
        if (others.isEmpty()) {
            toast("今、通話に入っている人がいないよ。渡したい人に先に入ってもらってね"); return
        }
        val names = others.map { it.name }.toTypedArray<CharSequence>()
        android.app.AlertDialog.Builder(this)
            .setTitle("👑 だれにオーナーを渡す？")
            .setItems(names) { _, which ->
                val target = others[which]
                android.app.AlertDialog.Builder(this)
                    .setTitle("オーナーを渡す")
                    .setMessage("「${target.name}」にオーナーを渡すよ。\n渡したあとは、自分はふつうのメンバーになるよ。いい？")
                    .setPositiveButton("渡す") { _, _ -> giveOwnerLobby(target) }
                    .setNegativeButton("やめる", null)
                    .show()
            }
            .setNegativeButton("やめる", null)
            .show()
    }

    private fun giveOwnerLobby(target: LobbyMember) {
        val base = VoiceService.serverBase()
        val url = "$base/api/give?room=$LOBBY&id=${target.id}&dev=" + java.net.URLEncoder.encode(deviceId(), "UTF-8")
        Thread {
            var done = false
            try {
                val req = okhttp3.Request.Builder().url(url)
                    .post("".toRequestBody(null)).build()
                lobbyHttp.newCall(req).execute().use { res -> done = res.isSuccessful }
            } catch (_: Exception) { }
            runOnUiThread {
                toast(if (done) "「${target.name}」にオーナーを渡したよ" else "渡せなかった。もう一度やってみてね")
                refreshLobbyOwner()
            }
        }.start()
    }

    private fun chooseNewOwner() {
        val others = AppState.members.filter { it.name != AppState.myName }
        if (others.isEmpty()) {
            toast("ほかに入っている人がいないよ"); return
        }
        val names = others.map { it.name }.toTypedArray<CharSequence>()
        android.app.AlertDialog.Builder(this)
            .setTitle("👑 だれにオーナーを渡す？")
            .setItems(names) { _, which ->
                val target = others[which]
                android.app.AlertDialog.Builder(this)
                    .setTitle("オーナーを渡す")
                    .setMessage("「${target.name}」にオーナーを渡すよ。\n渡したあとは、自分はふつうのメンバーになるよ。いい？")
                    .setPositiveButton("渡す") { _, _ -> VoiceService.instance?.giveOwner(target.id) }
                    .setNegativeButton("やめる", null)
                    .show()
            }
            .setNegativeButton("やめる", null)
            .show()
    }

    private fun updateOwnerUi() {
        tvBridgeToggle.text = (if (bridgeChoice) "☑" else "☐") + " 配信用：このスマホは連携だけ（オーナーだけ・声は別のスマホ）"
    }

    /** 入る前の画面に、待機所と部屋1〜20、今いる人の名前を並べる（Discord と同じ見た目） */
    private class LobbyPerson(val name: String, val slot: Int, val host: Boolean)
    private var lobbyPeople: List<LobbyPerson> = emptyList()
    private var lobbyResting: List<Pair<String, Long>> = emptyList()

    /** 人のマークのボタン: オンライン（今アプリ・ブラウザを開いてる人）と 休憩中（前に来た人）の一覧。Discord と同じ */
    private fun showMembers() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(8), dp(18), dp(8))
        fun header(t: String) {
            val h = TextView(this); h.text = t; h.textSize = 13f
            h.setTextColor(Color.parseColor("#949BA4")); h.setTypeface(null, Typeface.BOLD)
            h.setPadding(0, dp(12), 0, dp(6)); box.addView(h)
        }
        fun row(name: String, sub: String, online: Boolean) {
            val r = TextView(this)
            r.text = (if (online) "🟢 " else "⚫ ") + name + if (sub.isNotEmpty()) "　$sub" else ""
            r.textSize = 16f
            r.setTextColor(Color.parseColor(if (online) "#F2F3F5" else "#80848E"))
            r.setPadding(0, dp(6), 0, dp(6)); box.addView(r)
        }
        // 通話中は、サーバーから届いているメンバーを使う（いちばん新しい）
        val online: List<LobbyPerson> = if (AppState.running && AppState.members.isNotEmpty())
            AppState.members.map { LobbyPerson(it.name, if (AppState.mcLinked) it.slot else 0, it.host) }
        else lobbyPeople
        header("オンライン — ${online.size}")
        for (p in online.sortedWith(compareBy({ !it.host }, { it.name }))) {
            row((if (p.host) "👑 " else "") + p.name, if (p.slot > 0) "部屋${p.slot}" else "待機所", true)
        }
        val onlineNames = online.map { it.name }.toSet()
        val rest = lobbyResting.filter { it.first !in onlineNames }
        header("休憩中 — ${rest.size}")
        val now = System.currentTimeMillis()
        for ((n, last) in rest) row(n, agoText(now - last), false)
        val sv = android.widget.ScrollView(this)
        sv.addView(box)
        android.app.AlertDialog.Builder(this)
            .setTitle("👤 メンバー")
            .setView(sv)
            .setPositiveButton("とじる", null)
            .show()
    }

    private fun agoText(ms: Long): String {
        val m = ms / 60000
        return when {
            m < 1 -> "さっき"
            m < 60 -> "${m}分前"
            m < 60 * 24 -> "${m / 60}時間前"
            else -> "${m / 60 / 24}日前"
        }
    }

    private fun buildRoomsPreview() {
        fun personRow(p: LobbyPerson): TextView {
            val t = TextView(this)
            t.text = "⚫ " + p.name + if (p.host) " 👑" else ""
            t.textSize = 14f
            t.setPadding(dp(40), dp(3), dp(8), dp(3))
            t.setTextColor(Color.parseColor("#DBDEE1"))
            return t
        }
        val lobby = findViewById<LinearLayout>(R.id.llLobbyPeople)
        lobby.removeAllViews()
        for (p in lobbyPeople.filter { it.slot == 0 }) lobby.addView(personRow(p))
        val box = findViewById<LinearLayout>(R.id.llRoomsPreview)
        box.removeAllViews()
        for (room in 1..ROOMS) {
            val t = TextView(this)
            t.text = "🔊  🎧▮部屋$room"
            t.textSize = 15f
            t.setPadding(dp(8), dp(7), dp(8), dp(7))
            t.setTextColor(Color.parseColor("#80848E"))
            box.addView(t)
            for (p in lobbyPeople.filter { it.slot == room }) box.addView(personRow(p))
        }
    }

    private fun render() {
        val s = AppState
        val hasName = prefs.getString("displayName", "").orEmpty().isNotBlank()
        namePanel.visibility = if (!s.running && !hasName) View.VISIBLE else View.GONE
        setupPanel.visibility = if (s.running || !hasName) View.GONE else View.VISIBLE
        findViewById<TextView>(R.id.tvMyName).text = "👤 " + prefs.getString("displayName", "").orEmpty() + "　（タップで名前を変える）"
        callPanel.visibility = if (s.running) View.VISIBLE else View.GONE
        // 入る前の画面の右上（オーナーだけ「オーナーを渡す」）
        findViewById<Button>(R.id.btnGiveOwnerLobby).visibility = if (!s.running && lobbyIsOwner) View.VISIBLE else View.GONE
        // 人のマーク + 今オンラインの人数
        val onlineCount = if (s.running && s.members.isNotEmpty()) s.members.size else lobbyPeople.size
        findViewById<Button>(R.id.btnMembersLobby).text = onlineCount.toString()
        findViewById<Button>(R.id.btnMembersTop).text = onlineCount.toString()
        findViewById<TextView>(R.id.tvLobbyOwner).text = when {
            lobbyIsOwner -> "👑 あなたがオーナー"
            lobbyOwnerName != null -> "👑 オーナー: $lobbyOwnerName"
            !lobbyHasOwner -> "👑 まだオーナーなし（最初に入った人がオーナー）"
            else -> ""
        }
        tvStatus.text = s.status

        if (!s.running) return

        val roomName = when {
            s.bridgeOnly -> "連携だけ"
            s.mcLinked && s.mySlot > 0 && !s.optOut -> "部屋${s.mySlot}"
            else -> "近接VC待機所"
        }
        tvRoom.text = (if (s.isHost) "👑 " else "") + roomName + "  ›"
        // オーナーだけ: 右上の「オーナーを渡す」とマイクラのコマンド（待機所でも部屋でも出る）
        btnCopyCmd.visibility = if (s.isHost) View.VISIBLE else View.GONE
        findViewById<Button>(R.id.btnGiveOwner).visibility = if (s.isHost && !s.bridgeOnly) View.VISIBLE else View.GONE

        var card = when {
            !s.mcLinked && s.isHost && s.bridgeOpen -> "🟡 マイクラとつながった。位置を取得中…"
            !s.mcLinked && s.isHost -> "⚪ 今は待機所でふつうの通話\n上の「⛏ マイクラのコマンドをコピー」 → マイクラのチャットに貼って送信すると、ワールドに入った人が部屋に移動するよ"
            !s.mcLinked -> "⚪ 近接VC待機所にいるよ（ふつうの通話）\n運営がマイクラで準備すると、ワールドに入った人から部屋に移動するよ"
            s.optOut -> "⏸ 通話を抜けてるよ（「通話に戻る」で戻れる）"
            s.mySlot > 0 -> "🟢 部屋${s.mySlot} にいるよ：近くの人ほど大きく聞こえる"
            else -> "🟡 近接VC待機所にいるよ：待機所の人どうしでふつうに話せる\nマイクラのワールドに入ると、空いてる部屋に自動で移動するよ"
        }
        if (s.bridgeOnly) {
            card = "🔗 連携だけモード：このスマホはマイクもスピーカーも使っていないよ（配信アプリがマイクを使える）\n" +
                "声は別のスマホで、同じ名前「${s.myName}」・同じマイクラの名前で「入る」してね\n\n" +
                when {
                    s.mcLinked -> "🟢 マイクラと連携中"
                    s.bridgeOpen -> "🟡 マイクラとつながった。位置を取得中…"
                    else -> "⚪ 上の「⛏ マイクラのコマンドをコピー」→ マイクラのチャットに貼って送信"
                }
        }
        if (s.isHost && s.bridgeInfo.isNotEmpty()) card += "\n\n" + s.bridgeInfo
        tvMc.text = card

        // 下のボタン（押すたびに切り替え。オフのときは赤い斜線のアイコン）
        btnMute.setImageResource(if (s.muted || s.deafened) R.drawable.ic_mic_off else R.drawable.ic_mic)
        btnDeafen.setImageResource(if (s.deafened) R.drawable.ic_headset_off else R.drawable.ic_headset)
        btnOptOut.visibility = if (s.mcLinked && !s.bridgeOnly) View.VISIBLE else View.GONE
        val voiceBtns = if (s.bridgeOnly) View.GONE else View.VISIBLE
        btnMute.visibility = voiceBtns
        btnDeafen.visibility = voiceBtns
        btnOptOut.text = if (s.optOut) "通話に戻る" else "通話を抜ける"
        findViewById<Button>(R.id.btnStreamVoice).apply {
            visibility = if (s.bridgeOnly) View.GONE else View.VISIBLE
            text = when {
                s.streamLinked -> "📺 配信アプリとつながってる（声を直接送ってる・反響なし）"
                s.streamVoice -> "📺 配信に自分の声ものせる：オン（スマホの音にまぜてる）"
                else -> "📺 配信に自分の声ものせる：オフ"
            }
        }

        // 短い説明（上のバーの下）
        var sub = card.lineSequence().first()
        if (s.isHost && s.bridgeInfo.isNotEmpty()) sub += "\n" + s.bridgeInfo.lineSequence().first()
        if (!s.mcLinked && !s.bridgeOpen) {
            sub += if (s.isHost) "\n⛏ 上のボタンでコマンドをコピー → マイクラのチャットに貼って送信"
            else {
                // マイクラのコマンドはオーナーだけ。だれがオーナーか分かるようにする
                val owner = s.members.firstOrNull { it.host }?.name
                "\n⛏ マイクラのコマンドはオーナー" + (if (owner != null) "（$owner）" else "") + "だけが使えるよ"
            }
        }
        tvSub.text = sub

        // ⌄ で「タイル」と「チャンネル一覧」を切り替え
        listPanel.visibility = if (showList) View.VISIBLE else View.GONE
        llTiles.visibility = if (showList) View.GONE else View.VISIBLE
        if (showList) renderChannels() else renderTiles()
    }

    /** 真ん中のタイル: 自分と、今声が聞こえる相手（Discord の通話画面みたいに） */
    private fun renderTiles() {
        val s = AppState
        val me = s.members.firstOrNull { it.name == s.myName }
        // 通話にいる人をずっと同じ順番で出す（聞こえる・聞こえないで出たり消えたりしない）
        val others = s.members.filter { it.name != s.myName }.sortedBy { it.id }
        val people = (if (me != null && !s.bridgeOnly) listOf(me) else emptyList()) + others
        llTiles.removeAllViews()
        if (people.isEmpty()) {
            val t = TextView(this)
            t.text = "まだ誰の声も聞こえないよ"
            t.setTextColor(Color.parseColor("#80848E"))
            t.setPadding(dp(8), dp(40), dp(8), dp(40))
            llTiles.addView(t)
            return
        }
        val cols = if (people.size == 1) 1 else 2
        val h = when {
            people.size == 1 -> dp(360)
            people.size == 2 -> dp(220)
            people.size <= 4 -> dp(180)
            else -> dp(150)
        }
        var i = 0
        while (i < people.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val rowLp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, h)
            rowLp.setMargins(0, if (i == 0) 0 else dp(10), 0, 0)
            llTiles.addView(row, rowLp)
            // 2人のときは縦に並べる（Discord と同じ）
            val perRow = if (people.size == 2) 1 else cols
            for (c in 0 until perRow) {
                if (i >= people.size) {
                    row.addView(View(this), LinearLayout.LayoutParams(0, h, 1f))
                    continue
                }
                val m = people[i++]
                val isMe = m.name == s.myName
                val talking = if (isMe) s.selfTalking else m.id in s.talking
                val tile = LinearLayout(this)
                tile.orientation = LinearLayout.VERTICAL
                tile.gravity = android.view.Gravity.CENTER
                tile.setBackgroundResource(if (talking) R.drawable.tile_talking else R.drawable.tile)
                val lp = LinearLayout.LayoutParams(0, h, 1f)
                lp.setMargins(if (c == 0) 0 else dp(10), 0, 0, 0)
                row.addView(tile, lp)

                // アイコン（名前の1文字目）
                val size = if (people.size == 1) dp(110) else dp(72)
                val av = TextView(this)
                av.text = m.name.take(1).uppercase()
                av.gravity = android.view.Gravity.CENTER
                av.setTextColor(Color.WHITE)
                av.textSize = if (people.size == 1) 44f else 28f
                av.setTypeface(null, Typeface.BOLD)
                av.setBackgroundResource(AVATARS[Math.floorMod(m.name.hashCode(), AVATARS.size)])
                tile.addView(av, LinearLayout.LayoutParams(size, size))

                // 名前（下の黒い札）
                val chip = TextView(this)
                val sb = StringBuilder()
                if (m.host) sb.append("👑 ")
                sb.append(m.name)
                if (isMe && s.deafened) sb.append("  🎧✕") else if (isMe && s.muted) sb.append("  🎤✕")
                if (!isMe && m.name in AppState.userMute) sb.append("  🔇")
                else if (!isMe && (AppState.userVol[m.name] ?: 100) < 100) sb.append("  🔉")
                chip.text = sb.toString()
                chip.setTextColor(Color.parseColor(if (talking) "#23A55A" else "#F2F3F5"))
                chip.textSize = 15f
                chip.setTypeface(null, Typeface.BOLD)
                chip.setBackgroundResource(R.drawable.name_chip)
                chip.setPadding(dp(14), dp(6), dp(14), dp(6))
                val clp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                clp.setMargins(0, dp(14), 0, 0)
                tile.addView(chip, clp)
                // アイコンを長押し → その人の音量・ミュート
                if (!isMe) tile.setOnLongClickListener { showUserVolume(m.name); true }
            }
        }
    }

    private val NAME_COOL = listOf("カイト", "レン", "ソラ", "シン", "リク", "ハヤテ", "クロ", "ジン", "ライト", "ゼロ", "ノア", "ルカ", "アオ", "ヒカル", "ユウキ", "ショウ", "レイ", "ミナト", "トワ", "イブキ", "セナ", "ルイ", "カナタ", "アキラ")
    private val NAME_COMMON = listOf("はると", "そうた", "ゆうま", "ゆいと", "りく", "たける", "こうき", "ひなた", "あおい", "ゆな", "さくら", "りん", "めい", "ひより", "みお", "ことね", "ゆうと", "かいと", "けんた", "しょう", "まな", "なつき", "あやか", "そら")
    private val NAME_PRE = listOf("黒猫の", "疾風の", "蒼き", "夜の", "伝説の", "無敵の", "はぐれ", "眠れる", "闇の", "炎の", "最強の", "迷子の")

    /** ランダムな名前（ブラウザ版と同じ作り方） */
    private fun randomName(): String {
        val r = Math.random()
        return when {
            r < 0.3 -> NAME_COOL.random()
            r < 0.55 -> NAME_COMMON.random()
            r < 0.8 -> NAME_PRE.random() + NAME_COOL.random()
            else -> (if (Math.random() < 0.5) NAME_COOL else NAME_COMMON).random() + (10..99).random()
        }
    }

    /** 人ごとの音量: 覚えておいたものを読み込む */
    private fun loadUserVolumes() {
        for ((k, v) in prefs.all) {
            if (k.startsWith("vol_") && v is Int) AppState.userVol[k.removePrefix("vol_")] = v
            if (k.startsWith("mute_") && v == true) AppState.userMute.add(k.removePrefix("mute_"))
        }
    }

    /** アイコン長押しで出る: その人の音量（0〜100%）とミュート */
    private fun showUserVolume(who: String) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(12), dp(20), dp(4))
        val label = TextView(this)
        label.textSize = 16f
        label.setTextColor(Color.parseColor("#F2F3F5"))
        val bar = android.widget.SeekBar(this)
        bar.max = 100
        bar.progress = AppState.userVol[who] ?: 100
        val muteBtn = Button(this)
        fun save() {
            prefs.edit().putInt("vol_$who", AppState.userVol[who] ?: 100).putBoolean("mute_$who", who in AppState.userMute).apply()
            VoiceService.instance?.refreshVolumes()
            render()
        }
        fun show() {
            val muted = who in AppState.userMute
            label.text = if (muted) "🔇 ミュート中" else "🔊 音量: ${bar.progress}%"
            muteBtn.text = if (muted) "ミュートをやめる" else "🔇 ミュートする"
        }
        bar.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                AppState.userVol[who] = p
                show(); save()
            }
            override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
        })
        muteBtn.setOnClickListener {
            if (who in AppState.userMute) AppState.userMute.remove(who) else AppState.userMute.add(who)
            show(); save()
        }
        box.addView(label)
        box.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)))
        box.addView(muteBtn)
        show()
        android.app.AlertDialog.Builder(this)
            .setTitle("$who の音量")
            .setView(box)
            .setPositiveButton("とじる", null)
            .setNeutralButton("100%に戻す") { _, _ ->
                AppState.userVol[who] = 100; AppState.userMute.remove(who); save()
            }
            .show()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    /** Discord みたいなボイスチャンネル一覧（近接VC待機所 ＋ 部屋1〜20） */
    private fun renderChannels() {
        val s = AppState
        // 部屋ごとに人を分ける（0 = 近接VC待機所）
        val byRoom = HashMap<Int, MutableList<Member>>()
        for (m in s.members) {
            val room = if (s.mcLinked && m.slot in 1..ROOMS) m.slot else 0
            byRoom.getOrPut(room) { ArrayList() }.add(m)
        }
        val myRoom = s.members.firstOrNull { it.name == s.myName }?.let { if (s.mcLinked && it.slot in 1..ROOMS) it.slot else 0 }

        llChannels.removeAllViews()
        for (room in 0..ROOMS) {
            val title = if (room == 0) "🎤▮近接VC待機所" else "🎧▮部屋$room"
            val people = byRoom[room].orEmpty()
            val head = TextView(this)
            head.text = "🔊  $title" + if (room > 0 && people.isNotEmpty()) "   1/1" else ""
            head.textSize = 15f
            head.setPadding(dp(8), dp(7), dp(8), dp(7))
            val mine = room == myRoom
            head.setTextColor(if (mine || people.isNotEmpty()) Color.parseColor("#F2F3F5") else Color.parseColor("#80848E"))
            if (mine) head.setBackgroundResource(R.drawable.channel_selected)
            llChannels.addView(head)

            for (m in people) {
                val me = m.name == s.myName
                val talking = if (me) s.selfTalking else m.id in s.talking
                val row = TextView(this)
                val sb = StringBuilder()
                sb.append(if (talking) "🟢 " else "⚫ ")
                sb.append(m.name)
                if (m.host) sb.append(" 👑")
                if (me && s.bridgeOnly) {
                    sb.append("（声は別のスマホ）")
                } else if (me) {
                    sb.append("（自分）")
                    if (s.deafened) sb.append("  🎧✕") else if (s.muted) sb.append("  🎤✕")
                    else sb.append("  ").append("■".repeat(s.micLevel)).append("□".repeat(5 - s.micLevel))
                } else if (m.out) {
                    sb.append("  （抜けてる）")
                }
                row.text = sb.toString()
                row.textSize = 14f
                row.setPadding(dp(40), dp(3), dp(8), dp(3))
                row.setTextColor(Color.parseColor(if (talking) "#23A55A" else "#DBDEE1"))
                if (talking) row.setTypeface(null, Typeface.BOLD)
                llChannels.addView(row)
            }
        }
    }

    private fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("shabekura", text))
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
