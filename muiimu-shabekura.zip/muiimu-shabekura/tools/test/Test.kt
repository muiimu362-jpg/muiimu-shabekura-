import com.muiimu.shabekura.*
import kotlin.math.abs
import kotlin.random.Random
fun check(c: Boolean, m: String) { if (!c) { println("FAIL: $m"); kotlin.system.exitProcess(1) } }
fun main() {
    // μ-law: 1万回ランダムに変換して戻す
    val r = Random(1)
    repeat(10000) {
        val v = r.nextInt(-32768, 32768)
        val back = MuLaw.decode(byteArrayOf(MuLaw.encode(v)), 0)[0].toInt()
        val tol = maxOf(40, abs(v) / 12)
        check(abs(back - v) <= tol, "mulaw $v -> $back")
    }
    // 距離と音量
    val me = Pos(0.0, 64.0, 0.0, 0, 0.0)
    check(Spatial.compute(me, Pos(1.0, 64.0, 0.0, 0, 0.0)).first == 1f, "目の前は最大音量")
    var prev = 2f
    for (d in 0..30) {
        val g = Spatial.compute(me, Pos(d.toDouble(), 64.0, 0.0, 0, 0.0)).first
        check(g <= prev + 1e-6, "離れるほど小さく d=$d"); prev = g
    }
    check(Spatial.compute(me, Pos(24.0, 64.0, 0.0, 0, 0.0)).first == 0f, "24ブロックで無音")
    check(Spatial.compute(me, Pos(2.0, 64.0, 0.0, -1, 0.0)).first == 0f, "別ディメンションは無音")
    check(Spatial.compute(me, null).first == 0f, "ワールドにいない人は無音")
    // 向き: 南を向いて(yRot=0)、東(+X)の人は左、西(-X)の人は右
    check(Spatial.compute(me, Pos(5.0, 64.0, 0.0, 0, 0.0)).second < 0f, "東は左")
    check(Spatial.compute(me, Pos(-5.0, 64.0, 0.0, 0, 0.0)).second > 0f, "西は右")
    check(abs(Spatial.compute(me, Pos(0.0, 64.0, 5.0, 0, 0.0)).second) < 0.01f, "正面は真ん中")
    // 西を向いて(yRot=90)、北(-Z)の人は右
    check(Spatial.compute(Pos(0.0,64.0,0.0,0,90.0), Pos(0.0, 64.0, -5.0, 0, 0.0)).second > 0f, "西向きで北は右")
    repeat(5000) {
        val o = Pos(r.nextDouble(-40.0,40.0), r.nextDouble(0.0,128.0), r.nextDouble(-40.0,40.0), r.nextInt(-1,2), 0.0)
        val m = Pos(r.nextDouble(-40.0,40.0), r.nextDouble(0.0,128.0), r.nextDouble(-40.0,40.0), r.nextInt(-1,2), r.nextDouble(-180.0,180.0))
        val (g, p) = Spatial.compute(m, o)
        check(g in 0f..1f && p in -1f..1f && !g.isNaN() && !p.isNaN(), "範囲外 $g $p")
    }
    println("ALL OK")
}
