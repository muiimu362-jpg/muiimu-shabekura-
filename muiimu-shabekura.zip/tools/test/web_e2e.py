import asyncio, json, subprocess, sys, time
from playwright.async_api import async_playwright
FAKE_WS = """
window.__sent = []; window.__sockets = [];
class FakeWS {
  constructor(url){ this.url=url; this.readyState=0; this.binaryType='blob'; window.__sockets.push(this);
    setTimeout(()=>{ this.readyState=1; this.onopen && this.onopen({}); }, 50); }
  send(d){ window.__sent.push(typeof d === 'string' ? d : '[binary ' + (d.byteLength||d.length) + ']'); }
  close(){ this.readyState=3; }
  _recv(obj){ this.onmessage && this.onmessage({data: typeof obj==='string'?obj:JSON.stringify(obj)}); }
  _recvBin(arr){ this.onmessage && this.onmessage({data: new Uint8Array(arr).buffer}); }
}
window.WebSocket = FakeWS;
"""
async def main():
    srv = subprocess.Popen([sys.executable, "-m", "http.server", "8765"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(1)
    fails = []
    def ok(c, m):
        print(("OK   " if c else "FAIL ") + m)
        if not c: fails.append(m)
    try:
        async with async_playwright() as p:
            b = await p.chromium.launch(executable_path="/usr/bin/google-chrome",
                args=["--no-sandbox","--use-fake-device-for-media-stream","--use-fake-ui-for-media-stream","--autoplay-policy=no-user-gesture-required"])
            ctx = await b.new_context(viewport={"width":390,"height":844}, permissions=["microphone"])
            pg = await ctx.new_page()
            await pg.add_init_script(FAKE_WS)
            errors = []
            pg.on("pageerror", lambda e: errors.append(str(e)))
            await pg.goto("http://localhost:8765/index.html")
            # 0. 一番最初は「名前を決めてください」
            ok(await pg.is_visible("#namePanel") and not await pg.is_visible("#setup"), "最初の画面は「名前を決めてください」")
            await pg.fill("#displayName", "サブ垢")
            await pg.click("#setName")
            ok(await pg.is_visible("#setup") and "サブ垢" in await pg.inner_text("#myNameLabel"), "名前を決めるとチャンネル一覧になる")
            # 1. 待機所をタップ → マイクラの名前（サブ） → 入る
            await pg.click("#chLobby")
            ok(await pg.is_visible("#joinForm"), "待機所をタップすると入力欄が出る")
            await pg.fill("#mc", "saradayou509")
            await pg.click("#join")
            await pg.wait_for_timeout(800)
            url = await pg.evaluate("window.__sockets[0] && window.__sockets[0].url")
            import urllib.parse as up
            q = up.parse_qs(up.urlparse(url).query) if url else {}
            ok(q.get("room")==["MUIIMU"] and q.get("name")==["サブ垢"] and q.get("mc")==["saradayou509"] and q.get("dev",[""])[0].startswith("web-"), "呼び名とマイクラの名前を分けてつながる: " + str(q))
            ok(await pg.is_visible("#call"), "通話画面になる")
            # 2. サーバーから hello(オーナー) と members
            await pg.evaluate("""() => { const w=window.__sockets[0];
              w._recv({t:'hello', id:2, host:true});
              w._recv({t:'members', mc:false, list:[{id:1,name:'むいいむ',mc:'gopura777',host:false,slot:0},{id:2,name:'サブ垢',mc:'saradayou509',host:true,slot:0},{id:3,name:'見学の人',mc:'',host:false,slot:0}]}); }""")
            await pg.wait_for_timeout(300)
            ok(await pg.is_visible("#giveOwner"), "オーナーには右上に「オーナーを渡す」が出る")
            txt = await pg.inner_text("#members")
            ok("近接VC待機所" in txt and "部屋20" in txt and "むいいむ" in txt and "見学の人" in txt, "チャンネル一覧に待機所・部屋20・メンバー（呼び名）が出る")
            # 3. 声が送られている（偽マイクの音）
            await pg.wait_for_timeout(1500)
            sent = await pg.evaluate("window.__sent")
            ok(any(s.startswith("[binary 640") for s in sent), "マイクの声が送られている（40msごとの音声）")
            # 4. オーナーを渡す
            pg.once("dialog", lambda d: asyncio.ensure_future(d.accept()))
            await pg.click("#giveOwner")
            ok(await pg.is_visible("#ownerPick"), "渡す相手の一覧が出る")
            names = await pg.inner_text("#ownerList")
            ok("むいいむ" in names and "見学の人" in names and "サブ垢" not in names, "一覧に自分以外のメンバー（呼び名）が出る")
            await pg.click("#ownerList button:has-text('むいいむ')")
            await pg.wait_for_timeout(300)
            sent = await pg.evaluate("window.__sent")
            ok(any('"giveOwner"' in s and '"id":1' in s for s in sent), "giveOwner(id=1) が送られる")
            await pg.evaluate("window.__sockets[0]._recv({t:'owner', host:false, ownerName:'むいいむ'})")
            await pg.wait_for_timeout(300)
            ok(not await pg.is_visible("#giveOwner"), "渡したら「オーナーを渡す」が消える")
            ok("むいいむ" in await pg.inner_text("#status"), "「オーナーが むいいむ に変わった」と出る")
            # 5. 部屋に移動（マイクラ連携後）
            await pg.evaluate("""() => { const w=window.__sockets[0];
              w._recv({t:'pos', p:{gopura777:{x:0,y:64,z:0,d:0,r:0}, saradayou509:{x:3,y:64,z:0,d:0,r:0}}});
              w._recv({t:'members', mc:true, list:[{id:1,name:'むいいむ',mc:'gopura777',host:true,slot:1},{id:2,name:'サブ垢',mc:'saradayou509',host:false,slot:2},{id:3,name:'見学の人',mc:'',host:false,slot:0}]}); }""")
            await pg.wait_for_timeout(400)
            txt = await pg.inner_text("#members")
            i1 = txt.index("部屋1"); i2 = txt.index("部屋2"); i3 = txt.index("部屋3")
            ok("むいいむ" in txt[i1:i2] and "サブ垢" in txt[i2:i3], "むいいむは部屋1、サブ垢は部屋2に表示")
            ok("見学の人" in txt[:i1], "マイクラの名前なしの人は待機所に表示")
            ok("3m" in txt[i1:i2], "部屋1の人までの距離(3m)がマイクラの名前の位置から出る")
            ok("部屋2 にいるよ" in await pg.inner_text("#mc"), "「部屋2 にいるよ」と出る")
            # 6. 相手の声が届いたら再生される（エラーなく）
            await pg.evaluate("window.__sockets[0]._recvBin([1].concat(Array(640).fill(0x80)))")
            await pg.wait_for_timeout(300)
            ok(not errors, "ページのエラーなし " + str(errors))
            await pg.screenshot(path="/tmp/webtest/e2e.png", full_page=True)
            # 7. 退出するとチャンネル一覧に戻る（名前は覚えている）
            await pg.click("#leave")
            await pg.wait_for_timeout(200)
            ok(await pg.is_visible("#setup") and not await pg.is_visible("#namePanel"), "退出するとチャンネル一覧に戻る")
            # 8. Android のブラウザで開いたら、アプリを開く画面になる（名前の画面は出ない）
            actx = await b.new_context(user_agent="Mozilla/5.0 (Linux; Android 14) Chrome/120 Mobile")
            ap = await actx.new_page()
            await ap.route("**/*", lambda route: route.continue_() if "localhost" in route.request.url else route.abort())
            await ap.goto("http://localhost:8765/index.html?room=MUIIMU")
            await ap.wait_for_timeout(100)
            ok(await ap.is_visible("#android") and not await ap.is_visible("#namePanel") and not await ap.is_visible("#setup"), "Androidではアプリを開く画面だけ出る")
            await b.close()
    finally:
        srv.terminate()
    print("ALL OK" if not fails else f"FAILED {len(fails)}")
asyncio.run(main())
