const fs=require('fs'); const QR=new Function(fs.readFileSync('qr.js','utf8')+'; return QR;')();
let seed=7; const rnd=()=>{seed=(seed*1103515245+12345)&0x7fffffff; return seed/0x7fffffff;};
const chars="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789:/?=&.-_~%#";
const out=[];
for(let i=0;i<400;i++){ const L=1+Math.floor(rnd()*190); let t=""; for(let j=0;j<L;j++) t+=chars[Math.floor(rnd()*chars.length)];
  try{ out.push({t,m:QR.make(t)}); }catch(e){ } }
fs.writeFileSync('m2.json', JSON.stringify(out)); console.log(out.length);
