import { Room } from "./idx.mjs";
class WS { constructor(){this.readyState=1;this.sent=[];this.att=null;} send(m){this.sent.push(m)} close(c){this.readyState=3;this.closed=c} serializeAttachment(a){this.att=a} deserializeAttachment(){return this.att} }
globalThis.WebSocketPair=function(){ return {0:new WS(),1:new WS()}; }; globalThis.Response=class{constructor(b,o){}};
let fails=0; const ok=(c,m)=>{ if(!c){fails++; console.log("FAIL:",m);} };
const store=new Map(); const sockets=[];
const r=new Room({getWebSockets:()=>sockets.filter(s=>s.readyState===1),acceptWebSocket:w=>sockets.push(w),storage:{get:async k=>store.get(k),put:async(k,v)=>store.set(k,v)}},{BUILD_ID:"v1"});
const join=async(n,dev,mc="",role="")=>{ await r.fetch({url:`https://x/ws?room=MUIIMU&name=${encodeURIComponent(n)}&dev=${dev}&mc=${encodeURIComponent(mc)}&role=${role}`}); return sockets.at(-1); };
const last=(w,t)=>{ const a=w.sent.filter(x=>typeof x==="string"&&x.includes(`"t":"${t}"`)); return a.length?JSON.parse(a.at(-1)):null; };
const host=await join("むいいむ","A","gopura777");
const sub=await join("サブ垢","B","saradayou509");
const fr=await join("友達","C","tomo");
const pos=async()=>r.webSocketMessage(host, JSON.stringify({t:"pos", p:{gopura777:{x:0,y:64,z:0,d:0,r:0}, saradayou509:{x:4,y:64,z:0,d:0,r:0}, tomo:{x:40,y:64,z:0,d:0,r:0}}}));
await pos();
ok(r.mcOnline, "連携中");
// 1. 聞こえる距離: 4ブロックの人には届く、40ブロックの人には届かない
ok(r.canHear(host.att, sub.att) && !r.canHear(host.att, fr.att), "近い人には届いて、遠い人には届かない");
ok(r.canHear(host.att, {...sub.att}) , "4ブロックは届く");
// 2. チャットの読み上げ: オーナー（連携）から全員へ、位置つき
await r.webSocketMessage(host, JSON.stringify({t:"chat", mc:"gopura777", text:"やあ", p:{x:1,y:64,z:2,d:0,r:0}}));
const c=last(sub,"chat"); ok(c && c.text==="やあ" && c.mc==="gopura777" && c.p.x===1, "チャットがみんなに届く: "+JSON.stringify(c));
await r.webSocketMessage(sub, JSON.stringify({t:"chat", mc:"saradayou509", text:"なりすまし"}));
ok(last(fr,"chat").text==="やあ", "オーナー以外はチャットを流せない");
await r.webSocketMessage(host, JSON.stringify({t:"chat", mc:"x", text:"a".repeat(500), p:{x:"bad"}}));
const c2=last(fr,"chat"); ok(c2.text.length===120 && !c2.p, "長すぎる文は切る・おかしい位置は付けない");
// 3. オーナーが連携を続けたまま声だけ抜ける → 近接はそのまま
const br=await join("むいいむ","A","gopura777","bridge");
host.readyState=3; await r.webSocketClose(host, 1000, "voice off");
ok(r.mcOnline, "オーナーが声だけ抜けても（連携だけ続けてる）近接はそのまま");
await r.webSocketMessage(br, JSON.stringify({t:"pos", p:{gopura777:{x:0,y:64,z:0,d:0,r:0}, saradayou509:{x:4,y:64,z:0,d:0,r:0}, tomo:{x:5,y:64,z:0,d:0,r:0}}}));
ok(r.canHear(sub.att, fr.att), "オーナーがいなくても、ほかの人どうしの近接ボイスは動く");
await r.webSocketMessage(br, JSON.stringify({t:"chat", mc:"tomo", text:"連携だけからも読める"}));
ok(last(sub,"chat").text==="連携だけからも読める" && !br.sent.some(x=>typeof x==="string"&&x.includes("連携だけからも読める")), "連携だけからチャットが届く（連携だけには送らない）");
// 4. オーナーが完全に抜けた（アプリが落ちた・マイクラごと落ちた）→ だれも切られず、部屋も近接もそのまま
const slotsBefore = JSON.stringify(last(sub,"members").list.map(m=>[m.name,m.slot]));
sub.sent=[]; fr.sent=[];
br.readyState=3; await r.webSocketClose(br, 1000, "bye");
ok(r.mcOnline, "オーナーが落ちても連携はオンのまま");
ok(!sub.sent.some(x=>typeof x==="string"&&x.includes('"t":"mc"')&&x.includes('"on":false')), "「ふつうの通話に戻る」は送らない");
ok(sub.readyState===1 && fr.readyState===1 && !sub.closed && !fr.closed, "だれも切断されない");
ok(r.canHear(sub.att, fr.att), "近くにいた人どうしは、そのまま話せる");
const mem=last(sub,"members"); ok(mem && mem.mc===true, "メンバー一覧も連携のまま");
ok(JSON.stringify(mem.list.map(m=>[m.name,m.slot])) === slotsBefore, "部屋はそのまま（元の待機所に戻さない）: " + slotsBefore);
// 10分たっても戻さない
const realNow = Date.now; Date.now = () => realNow() + 10*60*1000;
await r.webSocketMessage(sub, JSON.stringify({t:"ping"}));
ok(r.posActive() && r.canHear(sub.att, fr.att), "時間がたってもそのまま");
// 遠くにいた人は遠いまま
await r.webSocketMessage(sub, JSON.stringify({t:"optout", on:false}));
Date.now = realNow;
// オーナーが戻って /connect し直したら、また位置が動く
const host2=await join("むいいむ","A","gopura777");
ok(JSON.parse(host2.sent.find(x=>x.includes('"hello"'))).host===true, "オーナーが戻ったらオーナーのまま");
await r.webSocketMessage(host2, JSON.stringify({t:"pos", p:{gopura777:{x:0,y:64,z:0,d:0,r:0}, saradayou509:{x:4,y:64,z:0,d:0,r:0}, tomo:{x:40,y:64,z:0,d:0,r:0}}}));
ok(!r.canHear(sub.att, fr.att), "また /connect したら位置が動き出す");
// オーナーを渡しても、みんなの部屋はそのまま
const before2 = JSON.stringify(last(sub,"members").list.map(m=>[m.name,m.slot]));
await r.webSocketMessage(host2, JSON.stringify({t:"giveOwner", id: sub.att.id}));
ok(r.mcOnline && JSON.stringify(last(sub,"members").list.map(m=>[m.name,m.slot])) === before2, "オーナーを渡しても部屋はそのまま");
console.log(fails?"FAILED "+fails:"ALL OK");
