import com.muiimu.shabekura.*
import kotlin.random.Random

// ===== 偽物のマイクラ =====
enum class SelMode { EXACT, IGNORECASE, BROKEN, QUOTED_ONLY, UNQUOTED_ONLY }
enum class VictimStyle { ARRAY, MSG_EN, MSG_JA, MSG_JA2 }

data class Cfg(
    val sel: SelMode, val victim: VictimStyle, val ja: Boolean,
    val maxDelayTicks: Int, val dropRate: Double, val detailsAsArray: Boolean,
    val yawKey: String, val churn: Boolean, val limit: Int,
)

class P(var name: String, var x: Double, var y: Double, var z: Double, var d: Int, var yaw: Double) {
    val hist = ArrayDeque<Triple<Double, Double, Double>>()
}

class FakeMc(val cfg: Cfg, val rnd: Random, val host: P) {
    val players = ArrayList<P>()
    private val queue = ArrayList<Pair<Int, String>>()
    private var inFlight = 0

    fun noTarget() = if (cfg.ja) "セレクターに合う対象がありません" else "No targets matched selector"

    private fun resp(id: String, code: Int, msg: String, extra: Map<String, Any?> = emptyMap()): String {
        val body = LinkedHashMap<String, Any?>()
        body["statusCode"] = code; body["statusMessage"] = msg; body.putAll(extra)
        return MiniJson.write(mapOf(
            "header" to mapOf("version" to 1, "requestId" to id, "messagePurpose" to "commandResponse", "messageType" to "commandResponse"),
            "body" to body))
    }

    private fun details(ps: List<P>): Any {
        val arr = ps.map { p ->
            val m = LinkedHashMap<String, Any?>()
            m["dimension"] = p.d; m["id"] = -4294967295L; m["position"] = mapOf("x" to p.x, "y" to p.y, "z" to p.z)
            m["uniqueId"] = "-4294967295"; m[cfg.yawKey] = p.yaw
            m
        }
        return if (cfg.detailsAsArray) arr else MiniJson.write(arr)
    }

    private fun match(sel: String): List<P>? {
        // @a / @s / @a[name="x"] / @a[name=x]
        if (sel == "@a") return players.toList()
        if (sel == "@s") return players.filter { it === host }
        val m = Regex("^@a\\[name=(\"((?:[^\"\\\\]|\\\\.)*)\"|([A-Za-z0-9_]+))]$").find(sel) ?: return null
        val quoted = m.groups[2] != null
        val name = if (quoted) m.groupValues[2].replace("\\\"", "\"").replace("\\\\", "\\") else m.groupValues[3]
        return when (cfg.sel) {
            SelMode.BROKEN -> emptyList()
            SelMode.EXACT -> players.filter { it.name == name }
            SelMode.IGNORECASE -> players.filter { it.name.equals(name, true) }
            SelMode.QUOTED_ONLY -> if (quoted) players.filter { it.name == name } else null
            SelMode.UNQUOTED_ONLY -> if (!quoted) players.filter { it.name == name } else emptyList()
        }
    }

    fun receive(json: String, tick: Int) {
        val o = MiniJson.parse(json) as Map<*, *>
        val h = o["header"] as Map<*, *>; val b = o["body"] as Map<*, *>
        check(h["messagePurpose"] == "commandRequest") { "送り方が変" }
        val id = h["requestId"] as String
        val line = b["commandLine"] as String
        if (rnd.nextDouble() < cfg.dropRate) return
        val out: String = if (inFlight >= cfg.limit) {
            resp(id, -2147418109, "Too many commands have been requested, wait for one to be done")
        } else when {
            line.startsWith("tellraw ") -> { MiniJson.parse(line.substringAfter("@s ")); resp(id, 0, "") }
            line == "testfor @a" || line == "testfor @s" -> {
                val who = if (line.endsWith("@s")) players.filter { it === host } else players
                if (who.isEmpty()) resp(id, -2147352576, noTarget())
                else {
                    val names = who.map { it.name }
                    when (cfg.victim) {
                        VictimStyle.ARRAY -> resp(id, 0, "Found " + names.joinToString(", "), mapOf("victim" to names))
                        VictimStyle.MSG_EN -> resp(id, 0, "Found " + names.joinToString(", "))
                        VictimStyle.MSG_JA -> resp(id, 0, names.joinToString(", ") + " を見つけました")
                        VictimStyle.MSG_JA2 -> resp(id, 0, "検出: " + names.joinToString("、"))
                    }
                }
            }
            line.startsWith("querytarget ") -> {
                val sel = line.removePrefix("querytarget ")
                val ps = match(sel)
                when {
                    ps == null -> resp(id, -2147483648, "構文エラー: 予期しない \"$sel\"")
                    ps.isEmpty() -> resp(id, -2147352576, noTarget())
                    else -> resp(id, 0, "Target data", mapOf("details" to details(ps)))
                }
            }
            else -> resp(id, -2147483648, "Unknown command")
        }
        inFlight++
        queue.add(tick + rnd.nextInt(0, cfg.maxDelayTicks + 1) to out)
    }

    fun deliver(tick: Int): List<String> {
        val ready = queue.filter { it.first <= tick }
        queue.removeAll(ready.toSet())
        inFlight -= ready.size
        return ready.map { it.second }.shuffled(rnd)
    }

    fun move() {
        for (p in players) {
            p.x += rnd.nextDouble(-0.5, 0.5); p.z += rnd.nextDouble(-0.5, 0.5)
            p.yaw = rnd.nextDouble(-180.0, 180.0)
            if (rnd.nextDouble() < 0.01) p.d = rnd.nextInt(-1, 2)
            p.hist.addLast(Triple(p.x, p.z, p.d.toDouble())); while (p.hist.size > 25) p.hist.removeFirst()
        }
    }
}

// ===== テスト =====
var totalChecks = 0L
var wrongPositions = 0L
var presenceChecks = 0L
var presenceHits = 0L

fun appNameFor(real: String, rnd: Random): Pair<String, Boolean> {
    // アプリに入れた名前（マイクラの名前とどう違うか）。second = 結びつくべきか
    return when (rnd.nextInt(7)) {
        0, 1, 2 -> real to true
        3 -> real.lowercase() to true
        4 -> real.uppercase() to true
        5 -> real.replace(Regex("#\\d+$"), "").let { it to (it == real) }
        else -> (real + "x") to false   // 打ち間違い → 結びつけてはいけない
    }
}

fun runScenario(seed: Int): String? {
    val rnd = Random(seed)
    val cfg = Cfg(
        sel = SelMode.values()[rnd.nextInt(SelMode.values().size)],
        victim = VictimStyle.values()[rnd.nextInt(VictimStyle.values().size)],
        ja = rnd.nextBoolean(),
        maxDelayTicks = rnd.nextInt(0, 4),
        dropRate = if (rnd.nextInt(3) == 0) rnd.nextDouble(0.0, 0.15) else 0.0,
        detailsAsArray = rnd.nextInt(4) == 0,
        yawKey = listOf("yRot", "y-rot", "yrot")[rnd.nextInt(3)],
        churn = rnd.nextBoolean(),
        limit = if (rnd.nextInt(4) == 0) 20 else 100,
    )
    val baseNames = listOf("gopura777", "saradayou509", "Steve", "Alex_01", "MuiimuTV", "sora 123", "Kuro#4521", "abc", "ABC2", "nyan_cat")
    val n = rnd.nextInt(1, 8)
    val chosen = baseNames.shuffled(rnd).take(n).toMutableList()
    // 大文字小文字だけ違う2人がいる場合も混ぜる
    if (rnd.nextInt(4) == 0 && n >= 2) chosen[1] = chosen[0].replace(Regex("#\\d+$"), "") + "#" + rnd.nextInt(1000, 9999)
    val realPlayers = chosen.map { P(it, rnd.nextDouble(-50.0, 50.0), 64.0, rnd.nextDouble(-50.0, 50.0), 0, 0.0) }
    val host = realPlayers[0]
    val mc = FakeMc(cfg, rnd, host)
    mc.players.addAll(realPlayers)
    val leftAt = HashMap<P, Int>()

    // アプリ側のメンバー
    val members = ArrayList<String>()
    val expect = HashMap<String, P?>()
    val hostApp = appNameFor(host.name, rnd).first
    members.add(hostApp); expect[hostApp] = host   // ホストは @s で必ず結びつく
    for (p in realPlayers.drop(1)) {
        if (rnd.nextInt(5) == 0) continue   // アプリを使っていない人
        val (an, should) = appNameFor(p.name, rnd)
        if (an in expect) continue
        members.add(an); expect[an] = if (should) p else null
    }
    if (rnd.nextBoolean()) { members.add("lobby_only"); expect["lobby_only"] = null } // ワールドにいないアプリ利用者

    // 期待: 名前の結びつけが一意にできるか（同じルールで判定）
    fun norm(s: String) = s.lowercase().replace(Regex("#\\d+$"), "").filter { !it.isWhitespace() }
    fun uniqueMatch(app: String, tick: Int = 0): P? {
        val ps: List<P> = mc.players + leftAt.filter { tick - it.value <= 15 && it.key !in mc.players }.keys.toList()
        ps.firstOrNull { it.name == app }?.let { return it }
        ps.filter { it.name.equals(app, true) }.let { if (it.size == 1) return it[0] }
        return null
    }

    var id = 0
    val logic = BridgeLogic { "req-${id++}" }
    mc.receive(logic.greeting(), 0)
    var stableSince = 0
    for (tick in 1..150) {
        val now = tick * 200L
        // 出入り
        if (cfg.churn && rnd.nextInt(40) == 0) {
            val others = mc.players.filter { it !== host }
            if (others.isNotEmpty() && rnd.nextBoolean()) { val gone = others[rnd.nextInt(others.size)]; mc.players.remove(gone); leftAt[gone] = tick }
            else realPlayers.filter { it !in mc.players }.randomOrNull(rnd)?.let { mc.players.add(rnd.nextInt(mc.players.size + 1), it) }
            stableSince = tick
        }
        mc.move()
        for (cmd in logic.tick(now, members)) mc.receive(cmd, tick)
        for (r in mc.deliver(tick)) logic.onMessage(r, now)
        val snap = logic.snapshot(now, members, hostApp)

        for (m in members) {
            val p = snap[m]
            val target: P? = if (m == hostApp) (uniqueMatch(m, tick) ?: host) else uniqueMatch(m, tick)
            val hostAlt: P? = if (m == hostApp) host else null
            if (p != null) {
                totalChecks++
                // 間違った人の位置になっていないか（一番大事）
                fun near(t: P?) = t != null && t.hist.any { (x, z, d) ->
                    kotlin.math.abs(x - p.x) < 1e-9 && kotlin.math.abs(z - p.z) < 1e-9 && d.toInt() == p.d
                }
                val okPos = near(target) || near(hostAlt)
                if (!okPos) {
                    wrongPositions++
                    return "seed=$seed tick=$tick cfg=$cfg 名前=$m に間違った位置 $p（正しい相手=${target?.name}）"
                }
            }
            // ちゃんと見つかっているか（落ち着いたあと）
            if (target != null && target in mc.players && tick - stableSince > 12 && tick > 15) {
                // 名前で探せない & 並び順も使えない組み合わせは、ホスト以外は見つからなくて正しい
                val byNameWorks = cfg.sel != SelMode.BROKEN
                val listWorks = true
                if (byNameWorks || listWorks || m == hostApp) {
                    presenceChecks++
                    if (p != null) presenceHits++
                    else if (cfg.dropRate == 0.0 && cfg.limit >= 100 && tick - stableSince > 20) {
                        return "seed=$seed tick=$tick cfg=$cfg 名前=$m（マイクラでは ${target.name}）が見つからない"
                    }
                }
            }
        }
        // 説明文が作れること
        logic.info(now, members, snap)
    }
    return null
}

fun main(args: Array<String>) {
    // JSON の読み書きテスト
    val r = Random(7)
    repeat(20000) {
        val s = buildString { repeat(r.nextInt(0, 30)) { append(r.nextInt(0, 0x3000).toChar()) } }
        val back = MiniJson.parse(MiniJson.write(mapOf("a" to s, "b" to listOf(1, 2.5, true, null))))
        check((back as Map<*, *>)["a"] == s) { "JSON 往復失敗: $s" }
    }
    println("JSON 往復テスト 20000回: OK")

    val count = args.firstOrNull()?.toInt() ?: 3000
    var fails = 0
    val start = args.getOrNull(1)?.toInt() ?: 1
    for (seed in start until start + count) {
        val err = runScenario(seed)
        if (err != null) { fails++; if (fails <= 5) println("FAIL: $err") }
    }
    println("シナリオ $count 個 × 150ステップ: 失敗 $fails")
    println("位置チェック $totalChecks 回 / 間違った人の位置 $wrongPositions 回")
    println("見つかった割合 ${"%.2f".format(100.0 * presenceHits / maxOf(1, presenceChecks))}%（$presenceHits / $presenceChecks）")
    if (fails == 0) println("ALL OK")
}
