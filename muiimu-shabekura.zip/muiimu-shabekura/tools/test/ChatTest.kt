import com.muiimu.shabekura.*
fun main() {
    var fails = 0
    fun ok(c: Boolean, m: String) { if (!c) { fails++; println("FAIL: $m") } }
    // 統合版のチャットイベント（新しい形: eventName が header）
    val a = """{"body":{"message":"こんにちは","receiver":"","sender":"Sarada Gamer12","type":"chat"},"header":{"eventName":"PlayerMessage","messagePurpose":"event","version":17039360}}"""
    ok(BridgeLogic.parseChat(a) == ("Sarada Gamer12" to "こんにちは"), "新しい形のチャット")
    // 古い形: eventName が body
    val b = """{"body":{"eventName":"PlayerMessage","properties":{},"message":"hi","sender":"gopura777","type":"chat"},"header":{"messagePurpose":"event","version":1}}"""
    ok(BridgeLogic.parseChat(b) == ("gopura777" to "hi"), "古い形のチャット")
    // 読まないもの
    ok(BridgeLogic.parseChat(a.replace("\"type\":\"chat\"", "\"type\":\"tell\"")) == null, "ささやき(tell)は読まない")
    ok(BridgeLogic.parseChat(a.replace("こんにちは", "/tp @s ~ ~ ~")) == null, "コマンドは読まない")
    ok(BridgeLogic.parseChat(a.replace("\"type\":\"chat\"", "\"type\":\"tellraw\"")) == null, "アプリのあいさつ(tellraw)は読まない")
    ok(BridgeLogic.parseChat(a.replace("Sarada Gamer12", "外部")) == null, "外部(コマンド)は読まない")
    ok(BridgeLogic.parseChat(a.replace("PlayerMessage", "PlayerTravelled")) == null, "ほかのイベントは読まない")
    ok(BridgeLogic.parseChat("""{"header":{"messagePurpose":"commandResponse","requestId":"x"},"body":{"statusCode":0}}""") == null, "コマンドの返事は読まない")
    ok(BridgeLogic.parseChat("こわれた") == null, "こわれた文字でも落ちない")
    ok(BridgeLogic.parseChat(a.replace("こんにちは", "あ".repeat(300)))!!.second.length == 120, "長すぎる文は120文字まで")
    // 申し込み
    val sub = BridgeLogic { "id1" }.subscribeChat()
    ok(sub.contains("\"messagePurpose\":\"subscribe\"") && sub.contains("\"eventName\":\"PlayerMessage\""), "チャットの申し込み")
    // 聞こえる距離
    fun g(d: Double) = Spatial.compute(Pos(0.0, 64.0, 0.0, 0, 0.0), Pos(d, 64.0, 0.0, 0, 0.0)).first
    ok(g(0.5) == 1.25f && g(1.0) == 1.25f, "1ブロックはふつうの声より少し大きめ: ${g(1.0)}")
    ok(Math.abs(g(2.0) - 1f) < 0.001f, "2ブロックはふつうの声: ${g(2.0)}")
    ok(Math.abs(g(3.0) - 0.75f) < 0.001f, "3ブロックでもけっこう聞こえる: ${g(3.0)}")
    ok(g(3.0) > g(4.0) && g(4.0) > g(5.0) && g(5.0) > g(6.0) && g(6.0) > 0f, "4〜6ブロックで少しずつ小さく")
    ok(g(6.0) in 0.08f..0.15f, "6ブロックは薄い声: ${g(6.0)}")
    ok(g(7.0) == 0f && g(25.0) == 0f, "7ブロック以上は聞こえない")
    var prev = 2f; var smooth = true
    var d = 0.0; while (d < 8.0) { val x = g(d); if (x > prev + 1e-6f) smooth = false; prev = x; d += 0.05 }
    ok(smooth, "離れるほど必ず小さくなる（急に大きくならない）")
    println(if (fails == 0) "ALL OK" else "FAILED $fails")
}
