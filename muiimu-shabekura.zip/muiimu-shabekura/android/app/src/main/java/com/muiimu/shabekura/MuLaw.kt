package com.muiimu.shabekura

/** G.711 μ-law（音声を半分のサイズにする） */
object MuLaw {
    private const val BIAS = 0x84
    private const val CLIP = 32635

    private val decodeTable = ShortArray(256).also { t ->
        for (u in 0 until 256) {
            val x = u.inv() and 0xFF
            val sign = x and 0x80
            val exponent = (x shr 4) and 0x07
            val mantissa = x and 0x0F
            val magnitude = (((mantissa shl 3) + BIAS) shl exponent) - BIAS
            t[u] = (if (sign != 0) -magnitude else magnitude).toShort()
        }
    }

    fun encode(sample: Int): Byte {
        var s = sample
        val sign = if (s < 0) { s = -s; 0x80 } else 0
        if (s > CLIP) s = CLIP
        s += BIAS
        var exponent = 7
        var mask = 0x4000
        while ((s and mask) == 0 && exponent > 0) {
            exponent--
            mask = mask shr 1
        }
        val mantissa = (s shr (exponent + 3)) and 0x0F
        return (sign or (exponent shl 4) or mantissa).inv().toByte()
    }

    fun encode(pcm: ShortArray): ByteArray {
        val out = ByteArray(pcm.size)
        for (i in pcm.indices) out[i] = encode(pcm[i].toInt())
        return out
    }

    fun decode(data: ByteArray, offset: Int): ShortArray {
        val n = data.size - offset
        val out = ShortArray(n)
        for (i in 0 until n) out[i] = decodeTable[data[offset + i].toInt() and 0xFF]
        return out
    }
}
