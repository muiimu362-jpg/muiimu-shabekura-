// iPhone・PC 用の Web 版（サーバーから配る）
// 注意: このファイルの中のスクリプトではバッククォートと「ドル記号+波かっこ」を使わないこと
// Android 用 APK の直接ダウンロード先（GitHub のリリース）
const APK_URL = "https://github.com/muiimu362-jpg/muiimu-shabekura-/releases/latest/download/MuiimuShabekura.apk";
const WEB_HTML_RAW = `<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="しゃべくら">
<meta name="theme-color" content="#2E5E2A">
<link rel="manifest" href="/manifest.json">
<link rel="apple-touch-icon" href="/icon.svg">
<title>むいいむ しゃべくら</title>
<style>
  * { box-sizing: border-box; }
  body { margin:0; background:#2B2D31; color:#DBDEE1;
    font-family: -apple-system, "Hiragino Sans", "Noto Sans JP", sans-serif; }
  main { max-width: 480px; margin: 0 auto; padding: 20px 16px calc(24px + env(safe-area-inset-bottom)); }
  h1 { color:#F2F3F5; font-size:22px; margin:8px 0 2px; }
  .sub { color:#80848E; font-size:12px; margin-bottom:14px; }
  label { display:block; color:#B5BAC1; font-weight:700; font-size:12px; margin-top:16px; }
  input { width:100%; font-size:16px; padding:12px; border:0; border-radius:6px; margin-top:6px; background:#1E1F22; color:#F2F3F5; }
  button { width:100%; font-size:15px; padding:13px; border:0; border-radius:8px; margin-top:10px;
    background:#5865F2; color:#fff; font-weight:700; }
  button.sec { background:#383A40; color:#DBDEE1; font-weight:500; }
  button.red { background:#DA373C; color:#fff; }
  .row { display:flex; gap:6px; } .row button { flex:1; font-size:12px; padding:12px 2px; white-space:nowrap; }
  .room { font-size:16px; font-weight:700; color:#F2F3F5; }
  .mc { margin-top:8px; padding:12px; border-radius:8px; background:#232428; font-size:13px; line-height:1.6; }
  .ch { padding:7px 8px; font-size:15px; color:#80848E; border-radius:6px; }
  .ch.has { color:#F2F3F5; } .ch.mine { background:#404249; color:#F2F3F5; }
  .ch .cnt { float:right; font-size:12px; color:#80848E; }
  .mem { padding:3px 8px 3px 40px; font-size:14px; color:#DBDEE1; }
  .mem.talk { color:#23A55A; font-weight:700; }
  #status { color:#949BA4; margin-top:16px; min-height:1.2em; }
  .note { color:#6D6F78; font-size:12px; margin-top:12px; line-height:1.6; }
  .hidden { display:none; }
</style>
</head>
<body>
<main>
  <h1>むいいむ しゃべくら</h1>
  <div class="sub">むいいむ通話 ・ 近づくと聞こえるボイスチャット（Web版）</div>

  <section id="android" class="hidden">
    <div class="room" id="aRoom"></div>
    <button id="openApp">アプリで開く</button>
    <a id="dlApk" href="__APK_URL__"><button class="sec">アプリをダウンロード（初めての人）</button></a>
    <div class="note">
      ・アプリが入っていれば「アプリで開く」で、ルームコード入りでアプリが開きます。<br>
      ・入っていない人は「アプリをダウンロード」→ ダウンロードしたファイルを開いてインストール →もう一度このページの「アプリで開く」を押してね。<br>
      ・インストール時に「提供元不明のアプリ」の許可を聞かれたら許可してください。
    </div>
  </section>

  <section id="setup">
    <label>ボイスチャンネル</label>
    <div class="ch mine" id="chLobby" style="cursor:pointer">🔊  🎤▮近接VC待機所　（タップして入る）</div>
    <div class="mc hidden" id="joinForm">
      <div style="color:#F2F3F5;font-weight:700;font-size:15px">マイクラの名前を教えてください</div>
      <input id="name" autocomplete="off" autocapitalize="off" placeholder="例: gopura777">
      <div class="note" style="margin-top:6px">Switch・PS で遊ぶ人は、そのマイクラで表示される名前をそのまま入れてね</div>
      <input id="room" type="hidden">
      <button id="join">入る</button>
    </div>
    <div id="roomsPreview"></div>
  </section>

  <section id="call" class="hidden">
    <div class="room" id="roomLabel"></div>
    <div class="mc" id="mc"></div>
    <div class="row">
      <button id="mute" class="sec">ミュート</button>
      <button id="deafen" class="sec">スピーカーミュート</button>
      <button id="leave" class="red">退出</button>
    </div>
    <button id="optout" class="sec hidden">通話を抜ける</button>
    <label>ボイスチャンネル</label>
    <div id="members"></div>
  </section>

  <div id="status"></div>
  <div class="note" id="webNote">
    ・このページは開いたまま（画面をつけたまま）にしてね。別のアプリに切り替えると声が止まります。<br>
    ・iPhoneで同じ端末のマイクラを遊ぶ場合は声が止まるので、Switch・PS・PCで遊ぶときの「横に置く用」に使ってね。<br>
    ・Safariの共有ボタン →「ホーム画面に追加」でアプリみたいに使えます。<br>
    ・イヤホン推奨。
  </div>
</main>

<script>
(function () {
  var RATE = 16000, FRAME = 640, VAD_LEVEL = 280, VAD_HANG = 8;
  var FULL = 3, MAX = 24;
  function $(id) { return document.getElementById(id); }

  // ---- μ-law ----
  var DEC = new Float32Array(256);
  (function () {
    for (var u = 0; u < 256; u++) {
      var x = (~u) & 0xFF, sign = x & 0x80, e = (x >> 4) & 7, m = x & 0x0F;
      var mag = (((m << 3) + 0x84) << e) - 0x84;
      DEC[u] = (sign ? -mag : mag) / 32768;
    }
  })();
  function enc(s) {
    var sign = 0;
    if (s < 0) { s = -s; sign = 0x80; }
    if (s > 32635) s = 32635;
    s += 0x84;
    var e = 7, mask = 0x4000;
    while ((s & mask) === 0 && e > 0) { e--; mask >>= 1; }
    var m = (s >> (e + 3)) & 0x0F;
    return (~(sign | (e << 4) | m)) & 0xFF;
  }

  // ---- 状態 ----
  var ws = null, ctx = null, stream = null, running = false, retry = 0;
  var myName = "", room = "", muted = false, deafened = false, mySlot = 0, optOut = false, selfTalking = false, hang = 0;
  var members = {}, positions = {}, mcOn = false, lastPos = 0;
  var speakers = {};
  var inBuf = [], rpos = 0, frame = new Int16Array(FRAME), fpos = 0;
  var wakeLock = null;

  try {
    $("name").value = localStorage.getItem("name") || "";
    $("room").value = localStorage.getItem("room") || "";
  } catch (e) {}
  var qp = new URLSearchParams(location.search).get("room");
  if (qp) $("room").value = qp.toUpperCase();

  // Android はブラウザではなくアプリを使う
  if (/Android/i.test(navigator.userAgent)) {
    var code = (qp || "").toUpperCase();
    var valid = /^[A-Z0-9]{6}$/.test(code);
    $("setup").classList.add("hidden");
    $("webNote").classList.add("hidden");
    $("android").classList.remove("hidden");
    $("aRoom").textContent = valid ? ("ルームコード: " + code) : "むいいむ通話";
    var apk = $("dlApk").getAttribute("href");
    var intentUrl = "intent://join" + (valid ? ("?room=" + code) : "") +
      "#Intent;scheme=shabekura;package=com.muiimu.shabekura;S.browser_fallback_url=" +
      encodeURIComponent(apk) + ";end";
    $("openApp").onclick = function () { location.href = intentUrl; };
    // ページを開いたら自動でアプリを開いてみる
    setTimeout(function () { location.href = intentUrl; }, 300);
  }

  function setStatus(t) { $("status").textContent = t; }

  $("chLobby").onclick = function () { $("joinForm").classList.toggle("hidden"); $("name").focus(); };
  (function () {
    var box = $("roomsPreview");
    for (var r = 1; r <= 20; r++) { var d = document.createElement("div"); d.className = "ch"; d.textContent = "🔊  🎧▮部屋" + r; box.appendChild(d); }
  })();
  $("join").onclick = function () { join().catch(function (e) { setStatus("開始できませんでした: " + e.message); stop(); }); };
  $("leave").onclick = function () { stop(); setStatus("退出しました"); };
  $("mute").onclick = function () { muted = !muted; render(); };
  $("optout").onclick = function () {
    optOut = !optOut;
    if (ws && ws.readyState === 1) ws.send(JSON.stringify({ t: "optout", on: optOut }));
    render();
  };
  $("deafen").onclick = function () {
    deafened = !deafened;
    for (var id in speakers) speakers[id].next = 0;
    render();
  };

  async function join() {
    myName = $("name").value.trim();
    room = ($("room").value.trim().toUpperCase()) || "MUIIMU";
    if (!myName) { $("joinForm").classList.remove("hidden"); setStatus("マイクラの名前を教えてね"); return; }
    if (!/^[A-Z0-9]{6}$/.test(room)) room = "MUIIMU";
    try { localStorage.setItem("name", myName); localStorage.setItem("room", room); } catch (e) {}

    try { if (navigator.audioSession) navigator.audioSession.type = "play-and-record"; } catch (e) {}
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    await ctx.resume();
    stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 }
    });
    var code = "class C extends AudioWorkletProcessor{process(i){var c=i[0]&&i[0][0];if(c)this.port.postMessage(c.slice(0));return true}}registerProcessor('cap',C);";
    await ctx.audioWorklet.addModule(URL.createObjectURL(new Blob([code], { type: "application/javascript" })));
    var src = ctx.createMediaStreamSource(stream);
    var node = new AudioWorkletNode(ctx, "cap");
    var sink = ctx.createGain(); sink.gain.value = 0;
    src.connect(node); node.connect(sink); sink.connect(ctx.destination);
    node.port.onmessage = function (e) { onMic(e.data); };

    running = true; retry = 0;
    $("setup").classList.add("hidden");
    $("call").classList.remove("hidden");
    keepAwake();
    connect();
    render();
  }

  function onMic(chunk) {
    var ratio = ctx.sampleRate / RATE;
    for (var i = 0; i < chunk.length; i++) inBuf.push(chunk[i]);
    while (rpos + 1 < inBuf.length) {
      var k = Math.floor(rpos), t = rpos - k;
      var v = inBuf[k] * (1 - t) + inBuf[k + 1] * t;
      frame[fpos++] = Math.max(-32768, Math.min(32767, Math.round(v * 32767)));
      rpos += ratio;
      if (fpos === FRAME) { fpos = 0; onFrame(); }
    }
    var drop = Math.floor(rpos);
    if (drop > 0) { inBuf = inBuf.slice(drop); rpos -= drop; }
  }

  function onFrame() {
    var sum = 0;
    for (var i = 0; i < FRAME; i++) sum += frame[i] * frame[i];
    var rms = Math.sqrt(sum / FRAME);
    if (rms > VAD_LEVEL) hang = VAD_HANG; else if (hang > 0) hang--;
    selfTalking = !muted && !deafened && hang > 0;
    if (!selfTalking || optOut || !ws || ws.readyState !== 1) return;
    var out = new Uint8Array(FRAME);
    for (var j = 0; j < FRAME; j++) out[j] = enc(frame[j]);
    ws.send(out);
  }

  function connect() {
    if (!running) return;
    var url = location.origin.replace(/^http/, "ws") + "/ws?room=" + encodeURIComponent(room) +
      "&name=" + encodeURIComponent(myName) + "&key=";
    var s = new WebSocket(url);
    s.binaryType = "arraybuffer";
    ws = s;
    setStatus("接続中…");
    s.onopen = function () { if (ws === s) { retry = 0; setStatus("通話中"); } };
    s.onmessage = function (e) {
      if (ws !== s) return;
      if (typeof e.data === "string") onText(e.data);
      else onAudio(new Uint8Array(e.data));
    };
    s.onclose = function (e) {
      if (ws !== s) return;
      if (e.code === 4004) { setStatus("運営がまだ近接VC待機所を開いてないよ（開くまで待ってね）"); stop(); return; }
      if (e.code === 4009) { setStatus("別の端末から同じ名前で入りました"); stop(); return; }
      if (e.code === 4010) { setStatus("通話が満員です"); stop(); return; }
      if (!running) return;
      retry++;
      setStatus("再接続中…");
      setTimeout(connect, Math.min(10000, 1000 * retry));
    };
  }

  function onText(text) {
    var m; try { m = JSON.parse(text); } catch (e) { return; }
    if (m.t === "members") {
      members = {};
      mySlot = 0;
      (m.list || []).forEach(function (x) {
        members[x.id] = x;
        if (x.name === myName) { mySlot = x.slot || 0; optOut = !!x.out; }
      });
      if (m.mc === false) mcOn = false;
      for (var id in speakers) if (!members[id]) delete speakers[id];
      recompute();
    } else if (m.t === "pos") {
      positions = m.p || {}; mcOn = true; lastPos = Date.now(); recompute();
    } else if (m.t === "mc") {
      mcOn = !!m.on; if (!mcOn) positions = {}; recompute();
    }
  }

  function speaker(id) {
    var s = speakers[id];
    if (s) return s;
    var g = ctx.createGain();
    var p = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
    if (p) { g.connect(p); p.connect(ctx.destination); } else g.connect(ctx.destination);
    s = speakers[id] = { gain: g, pan: p, next: 0, last: 0, g: 1 };
    return s;
  }

  function onAudio(u8) {
    if (u8.length < 2 || !ctx || deafened) return;
    var id = u8[0], n = u8.length - 1, sr = ctx.sampleRate;
    var outLen = Math.round(n * sr / RATE);
    var buf = ctx.createBuffer(1, outLen, sr);
    var d = buf.getChannelData(0), step = RATE / sr;
    for (var i = 0; i < outLen; i++) {
      var x = i * step, k = Math.floor(x), t = x - k;
      var a = DEC[u8[1 + Math.min(k, n - 1)]], b = DEC[u8[1 + Math.min(k + 1, n - 1)]];
      d[i] = a * (1 - t) + b * t;
    }
    var s = speaker(id);
    var now = ctx.currentTime;
    if (s.next < now + 0.02 || s.next > now + 0.5) s.next = now + 0.1;
    var node = ctx.createBufferSource();
    node.buffer = buf;
    node.connect(s.gain);
    node.start(s.next);
    s.next += buf.duration;
    s.last = Date.now();
  }

  function compute(me, o) {
    if (!me || !o || me.d !== o.d) return [0, 0];
    var dx = o.x - me.x, dy = o.y - me.y, dz = o.z - me.z;
    var dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
    var g = dist <= FULL ? 1 : dist >= MAX ? 0 : Math.pow((MAX - dist) / (MAX - FULL), 2);
    var yaw = (me.r || 0) * Math.PI / 180;
    var rx = -Math.cos(yaw), rz = -Math.sin(yaw);
    var len = Math.sqrt(dx * dx + dz * dz);
    var pan = len < 0.5 ? 0 : ((dx * rx + dz * rz) / len) * 0.8;
    return [g, pan, dist];
  }

  function recompute() {
    if (!ctx) return;
    var me = positions[myName];
    for (var id in members) {
      var mem = members[id];
      if (mem.name === myName) continue;
      // サーバーと同じルール
      var other = positions[mem.name];
      var r;
      if (optOut || mem.out) r = [0, 0];
      else if (!mcOn) r = [1, 0];                                   // /connect 前はふつうの通話
      else if (mySlot > 0 && mem.slot > 0) r = compute(me, other);  // ワールドの中どうしは距離で
      else if (!me && !other && !mem.slot) r = [1, 0];              // ワールドの外どうしはふつうの通話
      else r = [0, 0];
      var full = compute(me, positions[mem.name]);
      var s = speaker(id);
      s.g = r[0]; s.dist = full.length > 2 ? full[2] : null;
      s.gain.gain.setTargetAtTime(r[0], ctx.currentTime, 0.05);
      if (s.pan) s.pan.pan.setTargetAtTime(r[1], ctx.currentTime, 0.05);
    }
    render();
  }

  function render() {
    $("roomLabel").textContent = "むいいむ通話";
    $("mute").textContent = muted ? "🎤 ミュート解除" : "🎤 ミュート";
    $("deafen").textContent = deafened ? "🎧 スピーカー解除" : "🎧 スピーカーミュート";
    var mc = $("mc");
    if (!mcOn) { mc.textContent = "⚪ 近接VC待機所にいるよ（ふつうの通話）。運営がマイクラで準備すると、ワールドに入った人から部屋に移動するよ"; mc.className = "mc"; }
    else if (optOut) { mc.textContent = "⏸ 通話を抜けてるよ（「通話に戻る」で戻れる）"; mc.className = "mc"; }
    else if (mySlot > 0) { mc.textContent = "🟢 部屋" + mySlot + " にいるよ：近くの人ほど大きく聞こえる"; mc.className = "mc on"; }
    else { mc.textContent = "🟡 近接VC待機所にいるよ：待機所の人どうしでふつうに話せる。マイクラのワールドに入ると、空いてる部屋に自動で移動するよ（名前がマイクラと同じか確認してね）"; mc.className = "mc"; }
    $("optout").classList.toggle("hidden", !mcOn);
    $("optout").textContent = optOut ? "通話に戻る" : "通話を抜ける";
    // Discord みたいなボイスチャンネル一覧（近接VC待機所 ＋ 部屋1〜20）
    var box = $("members");
    box.textContent = "";
    var byRoom = {}, myRoom = 0, now = Date.now();
    Object.keys(members).forEach(function (id) {
      var x = members[id];
      var r = (mcOn && x.slot >= 1 && x.slot <= 20) ? x.slot : 0;
      (byRoom[r] = byRoom[r] || []).push(id);
      if (x.name === myName) myRoom = r;
    });
    for (var r = 0; r <= 20; r++) {
      var people = byRoom[r] || [];
      var head = document.createElement("div");
      head.className = "ch" + (people.length ? " has" : "") + (r === myRoom ? " mine" : "");
      head.textContent = "🔊  " + (r === 0 ? "🎤▮近接VC待機所" : "🎧▮部屋" + r);
      if (r > 0 && people.length) {
        var c = document.createElement("span"); c.className = "cnt"; c.textContent = "1/1"; head.appendChild(c);
      }
      box.appendChild(head);
      people.forEach(function (id) {
        var mem = members[id], me = mem.name === myName, s = speakers[id];
        var talking = me ? selfTalking : (s && now - s.last < 350 && s.g > 0.01);
        var line = (talking ? "🟢 " : "⚫ ") + mem.name + (mem.host ? " 👑" : "");
        if (me) line += "（自分）" + (deafened ? "  🎧✕" : muted ? "  🎤✕" : "");
        else if (mem.out) line += "  （抜けてる）";
        else if (mcOn && r > 0 && s && s.dist != null) line += "  " + Math.round(s.dist) + "m" + (s.g <= 0.01 ? "・聞こえない" : "");
        var div = document.createElement("div");
        div.className = "mem" + (talking ? " talk" : "");
        div.textContent = line;
        box.appendChild(div);
      });
    }
  }

  setInterval(function () {
    if (!running) return;
    if (mcOn && Date.now() - lastPos > 5000) { mcOn = false; positions = {}; recompute(); }
    else render();
  }, 250);

  async function keepAwake() {
    try { if (navigator.wakeLock) wakeLock = await navigator.wakeLock.request("screen"); } catch (e) {}
  }
  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible" && running) {
      keepAwake();
      if (ctx && ctx.state !== "running") ctx.resume();
    }
  });

  function stop() {
    running = false;
    var s = ws; ws = null;
    try { if (s) s.close(1000); } catch (e) {}
    try { if (stream) stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
    try { if (ctx) ctx.close(); } catch (e) {}
    try { if (wakeLock) wakeLock.release(); } catch (e) {}
    ctx = null; stream = null; speakers = {}; members = {}; positions = {}; mcOn = false; mySlot = 0; optOut = false;
    inBuf = []; rpos = 0; fpos = 0; selfTalking = false; muted = false; deafened = false;
    $("setup").classList.remove("hidden");
    $("call").classList.add("hidden");
  }
})();
</script>
</body>
</html>`;

export const WEB_HTML = WEB_HTML_RAW.replace("__APK_URL__", APK_URL);

export const MANIFEST = JSON.stringify({
  name: "むいいむ しゃべくら",
  short_name: "しゃべくら",
  start_url: "/",
  display: "standalone",
  background_color: "#F4F7F2",
  theme_color: "#2E5E2A",
  icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml" }],
});

export const ICON_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 108">
<rect width="108" height="108" rx="22" fill="#7EC8E3"/>
<path fill="#8B5A2B" d="M32,38h44v38h-44z"/>
<path fill="#5DAE3B" d="M32,38h44v12h-44z"/>
<path fill="#4A9130" d="M32,50h6v4h-6zM44,50h6v6h-6zM58,50h6v3h-6zM70,50h6v5h-6z"/>
<path fill="#FFFFFF" d="M56,24h26a6,6 0,0 1,6 6v12a6,6 0,0 1,-6 6h-14l-8,7v-7h-4a6,6 0,0 1,-6 -6v-12a6,6 0,0 1,6 -6z"/>
<path fill="#5DAE3B" d="M61,34h4v4h-4zM67,34h4v4h-4zM73,34h4v4h-4z"/>
</svg>`;
