import worker, { Room } from "./idx.mjs";
class WS { constructor(){this.readyState=1;this.sent=[];this.att=null;} send(m){this.sent.push(m)} close(c){this.readyState=3;this.closed=c} serializeAttachment(a){this.att=a} deserializeAttachment(){return this.att} }
globalThis.WebSocketPair=function(){ return {0:new WS(),1:new WS()}; };
globalThis.Response=class{constructor(b,o={}){this.body=b;this.status=o.status||200;} async json(){return JSON.parse(this.body);} };
const rooms=new Map();
const env={ OWNER_PASSWORD:"muiimu2026", ROOM:{ idFromName:(n)=>n, get:(id)=>{ if(!rooms.has(id)){ const sockets=[],store=new Map(); rooms.set(id,new Room({getWebSockets:()=>sockets,acceptWebSocket:w=>sockets.push(w),storage:{get:async k=>store.get(k),put:async(k,v)=>store.set(k,v)}},{})); } return rooms.get(id);} } };
let fails=0; const ok=(c,m)=>{ if(!c){fails++;console.log("FAIL:",m);} };
const req=(path,method,body,h={})=>({url:"https://x"+path,method,headers:{get:(k)=>h[k]},json:async()=>body});
// 友達が先に来た（まだ開いてない）→ 4004
const r0=env.ROOM.get("MUIIMU"); await r0.fetch({url:"https://x/ws?room=MUIIMU&name=friend"}); 
ok(r0.ctx.getWebSockets().at(-1).closed===4004, "開く前は入れない(4004)");
// 間違ったパスワード
let res=await worker.fetch(req("/api/create","POST",{password:"x",code:"MUIIMU"}),env); ok(res.status===403,"パスワード違いは開けない");
// 運営が開く
res=await worker.fetch(req("/api/create","POST",{password:"muiimu2026",code:"MUIIMU"}),env); const j=await res.json();
ok(res.status===200 && j.code==="MUIIMU" && j.hostKey, "運営が待機所 MUIIMU を開ける");
// 友達はコードなし（アプリが MUIIMU を使う）で入れる
await r0.fetch({url:"https://x/ws?room=MUIIMU&name=saradayou509"}); ok(r0.ctx.getWebSockets().at(-1).readyState===1, "友達はコードなしで待機所に入れる");
await r0.fetch({url:`https://x/ws?room=MUIIMU&name=gopura777&key=${j.hostKey}`}); const L=JSON.parse(r0.ctx.getWebSockets().at(-1).sent.filter(x=>x.includes('"members"')).at(-1)).list;
ok(L.find(m=>m.name==="gopura777").host===true, "運営に王冠");
// 開き直すと新しい鍵になる（古い鍵は使えない）
const j2=await (await worker.fetch(req("/api/create","POST",{password:"muiimu2026",code:"MUIIMU"}),env)).json(); ok(j2.hostKey!==j.hostKey,"開き直すと鍵が新しくなる");
console.log(fails===0?"ALL OK":"FAILED "+fails);
