package com.muiimu.shabekura

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Process
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * マイク録音 → 送信、受信 → 人ごとに音量と左右を付けてミックス → 再生
 * 16kHz モノラル、40ms ごとに1フレーム
 */
class AudioEngine(private val send: (ByteArray) -> Unit) {

    companion object {
        const val RATE = 16000
        const val FRAME = 640           // 40ms
        private const val VAD_LEVEL = 140.0
        private const val VAD_HANG = 8  // 話し終わってから 320ms は送り続ける
        private const val MAX_QUEUE = 8
        private const val START_FRAMES = 2
    }

    private class Speaker {
        val queue = ArrayDeque<ShortArray>()
        var playing = false
        var gain = 1f
        var targetGain = 1f
        var pan = 0f
        var targetPan = 0f
        var lastHeard = 0L
    }

    private val speakers = HashMap<Int, Speaker>()
    @Volatile var muted = false
    @Volatile private var running = false
    private var recThread: Thread? = null
    private var playThread: Thread? = null

    fun start() {
        if (running) return
        running = true
        recThread = Thread({ recordLoop() }, "shabekura-rec").also { it.start() }
        playThread = Thread({ playLoop() }, "shabekura-play").also { it.start() }
    }

    fun stop() {
        running = false
        recThread?.interrupt(); playThread?.interrupt()
        recThread = null; playThread = null
        synchronized(speakers) { speakers.clear() }
    }

    fun onIncoming(id: Int, data: ByteArray, offset: Int) {
        if (data.size - offset <= 0) return
        val pcm = MuLaw.decode(data, offset)
        synchronized(speakers) {
            val s = speakers.getOrPut(id) { Speaker() }
            s.queue.addLast(pcm)
            while (s.queue.size > MAX_QUEUE) s.queue.removeFirst()
            s.lastHeard = System.currentTimeMillis()
        }
    }

    fun setSpatial(id: Int, gain: Float, pan: Float) {
        synchronized(speakers) {
            val s = speakers.getOrPut(id) { Speaker().also { it.gain = gain; it.pan = pan } }
            s.targetGain = gain
            s.targetPan = pan
        }
    }

    fun retain(ids: Set<Int>) {
        synchronized(speakers) { speakers.keys.retainAll(ids) }
    }

    fun talkingIds(): Set<Int> {
        val now = System.currentTimeMillis()
        synchronized(speakers) {
            return speakers.filter { now - it.value.lastHeard < 350 && it.value.targetGain > 0.01f }.keys.toSet()
        }
    }

    @SuppressLint("MissingPermission")
    private fun openRecorder(source: Int): AudioRecord? {
        val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        return try {
            val r = AudioRecord(
                source, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                max(minBuf, FRAME * 2 * 4)
            )
            if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); null } else r
        } catch (e: Exception) { null }
    }

    private fun recordLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        // まず通話用マイク → ダメなら普通のマイク
        val sources = intArrayOf(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            MediaRecorder.AudioSource.MIC,
            MediaRecorder.AudioSource.DEFAULT,
        )
        var si = 0
        val buf = ShortArray(FRAME)
        var hang = 0
        while (running && si < sources.size) {
            val rec = openRecorder(sources[si])
            if (rec == null) { si++; continue }
            var aec: AcousticEchoCanceler? = null
            var ns: NoiseSuppressor? = null
            try {
                if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(rec.audioSessionId)?.also { it.enabled = true }
                if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(rec.audioSessionId)?.also { it.enabled = true }
            } catch (_: Exception) {}

            var silentFrames = 0
            var switchSource = false
            try {
                rec.startRecording()
                while (running) {
                    var read = 0
                    while (read < FRAME && running) {
                        val n = rec.read(buf, read, FRAME - read)
                        if (n <= 0) break
                        read += n
                    }
                    if (read < FRAME) continue
                    var sum = 0.0
                    var allZero = true
                    for (v in buf) { sum += v.toDouble() * v; if (v.toInt() != 0) allZero = false }
                    // 完全な無音が2秒続いたら、別のマイク設定に切り替える
                    if (allZero) silentFrames++ else silentFrames = 0
                    if (silentFrames >= 50 && si < sources.size - 1) { switchSource = true; break }
                    if (silentFrames == 50) {
                        AppState.status = "マイクの音が取れません（他のアプリがマイクを使っていないか確認してね）"
                        AppState.changed()
                    }
                    val rms = sqrt(sum / FRAME)
                    // マイクの大きさ（0〜5）を画面に出す
                    val lv = when {
                        rms < 60 -> 0; rms < 140 -> 1; rms < 400 -> 2; rms < 1200 -> 3; rms < 3000 -> 4; else -> 5
                    }
                    if (lv != AppState.micLevel) { AppState.micLevel = lv; AppState.changed() }
                    if (rms > VAD_LEVEL) hang = VAD_HANG else if (hang > 0) hang--
                    val talking = !muted && hang > 0
                    if (talking != AppState.selfTalking) { AppState.selfTalking = talking; AppState.changed() }
                    if (talking) send(MuLaw.encode(buf))
                }
            } catch (_: Exception) {
            } finally {
                try { rec.stop() } catch (_: Exception) {}
                rec.release(); aec?.release(); ns?.release()
                AppState.selfTalking = false
            }
            if (switchSource) si++ else break
        }
        if (running && si >= sources.size) {
            AppState.status = "マイクを使えません（権限を確認してね）"; AppState.changed()
        }
    }

    private fun playLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val minOut = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(RATE)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(max(minOut, FRAME * 4 * 3))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        val mix = IntArray(FRAME * 2)
        val out = ShortArray(FRAME * 2)
        try {
            track.play()
            while (running) {
                java.util.Arrays.fill(mix, 0)
                synchronized(speakers) {
                    for (s in speakers.values) {
                        if (!s.playing && s.queue.size >= START_FRAMES) s.playing = true
                        if (!s.playing) continue
                        val f = s.queue.removeFirstOrNull()
                        if (f == null) { s.playing = false; continue }
                        // 音量と左右は1フレームかけてなめらかに変える
                        val g0 = s.gain; val g1 = s.targetGain
                        val (l0, r0) = panGains(s.pan)
                        val (l1, r1) = panGains(s.targetPan)
                        val n = min(f.size, FRAME)
                        for (i in 0 until n) {
                            val t = i.toFloat() / FRAME
                            val g = g0 + (g1 - g0) * t
                            val l = l0 + (l1 - l0) * t
                            val r = r0 + (r1 - r0) * t
                            val v = f[i] * g
                            mix[2 * i] += (v * l).toInt()
                            mix[2 * i + 1] += (v * r).toInt()
                        }
                        s.gain = g1; s.pan = s.targetPan
                    }
                }
                for (i in mix.indices) {
                    out[i] = mix[i].coerceIn(-32768, 32767).toShort()
                }
                track.write(out, 0, out.size)
            }
        } catch (_: Exception) {
        } finally {
            try { track.stop() } catch (_: Exception) {}
            track.release()
        }
    }

    /** 左右の音量（真ん中で両方1.0、端で片方が小さくなる） */
    private fun panGains(pan: Float): Pair<Float, Float> {
        val th = (pan.coerceIn(-1f, 1f) + 1f) * (PI / 4).toFloat()
        val l = min(1f, cos(th) * 1.4142f)
        val r = min(1f, sin(th) * 1.4142f)
        return l to r
    }
}
