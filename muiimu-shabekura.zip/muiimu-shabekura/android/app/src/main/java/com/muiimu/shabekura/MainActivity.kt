package com.muiimu.shabekura

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import okhttp3.RequestBody.Companion.toRequestBody
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class MainActivity : Activity() {

    companion object {
        /** みんなが入る「近接VC待機所」（決まったコード） */
        const val LOBBY = "MUIIMU"
        const val APK_URL = "https://github.com/muiimu362-jpg/muiimu-shabekura-/releases/latest/download/MuiimuShabekura.apk"
        const val ROOMS = 20
        private val AVATARS = intArrayOf(
            R.drawable.avatar_0, R.drawable.avatar_1, R.drawable.avatar_2,
            R.drawable.avatar_3, R.drawable.avatar_4, R.drawable.avatar_5,
        )
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var etMc: EditText
    private lateinit var etDisplayName: EditText
    private lateinit var namePanel: LinearLayout
    private lateinit var setupPanel: LinearLayout
    private lateinit var joinForm: LinearLayout
    private lateinit var tvBridgeToggle: TextView
    private var bridgeChoice = false
    private lateinit var callPanel: LinearLayout
    private lateinit var tvRoom: TextView
    private lateinit var tvMc: TextView
    private lateinit var llChannels: LinearLayout
    private lateinit var tvStatus: TextView
    private lateinit var btnCopyCmd: Button
    private lateinit var btnMute: ImageButton
    private lateinit var btnDeafen: ImageButton
    private lateinit var llTiles: LinearLayout
    private lateinit var listPanel: LinearLayout
    private lateinit var tvSub: TextView
    private var showList = false   // ⌄ でチャンネル一覧に切り替え
    private lateinit var btnOptOut: Button

    private val listener: () -> Unit = { render() }
    private var pendingStart: (() -> Unit)? = null
    private var linkCode: String? = null   // 招待リンクで別の部屋コードが来たとき

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("shabekura", Context.MODE_PRIVATE)

        etMc = findViewById(R.id.etMc)
        etDisplayName = findViewById(R.id.etDisplayName)
        namePanel = findViewById(R.id.namePanel)
        setupPanel = findViewById(R.id.setupPanel)
        joinForm = findViewById(R.id.joinForm)
        tvBridgeToggle = findViewById(R.id.tvBridgeToggle)
        callPanel = findViewById(R.id.callPanel)
        tvRoom = findViewById(R.id.tvRoom)
        tvMc = findViewById(R.id.tvMc)
        llChannels = findViewById(R.id.llChannels)
        tvStatus = findViewById(R.id.tvStatus)
        btnCopyCmd = findViewById(R.id.btnCopyCmd)
        btnMute = findViewById(R.id.btnMute)
        btnDeafen = findViewById(R.id.btnDeafen)
        btnOptOut = findViewById(R.id.btnOptOut)
        llTiles = findViewById(R.id.llTiles)
        listPanel = findViewById(R.id.listPanel)
        tvSub = findViewById(R.id.tvSub)
        val toggleList = View.OnClickListener { showList = !showList; render() }
        findViewById<ImageButton>(R.id.btnCollapse).setOnClickListener(toggleList)
        findViewById<TextView>(R.id.tvRoom).setOnClickListener(toggleList)

        etMc.setText(prefs.getString("mc", ""))
        etDisplayName.setText(prefs.getString("displayName", ""))
        // 一番最初は「名前を決めてください」
        findViewById<Button>(R.id.btnSetName).setOnClickListener {
            val n = etDisplayName.text.toString().trim()
            if (n.isEmpty()) { toast("名前を入れてね"); return@setOnClickListener }
            prefs.edit().putString("displayName", n).apply()
            render()
        }
        findViewById<TextView>(R.id.tvMyName).setOnClickListener {
            // 名前を変える
            prefs.edit().remove("displayName").apply()
            render()
        }

        findViewById<TextView>(R.id.tvVersion).text = "バージョン " + BuildConfig.VERSION_NAME
        if (VoiceService.serverBase().isEmpty()) {
            findViewById<View>(R.id.serverWarn).visibility = View.VISIBLE
        }

        // 近接VC待機所をタップすると、名前とオーナーの入力欄が出る
        findViewById<TextView>(R.id.chLobby).setOnClickListener {
            joinForm.visibility = if (joinForm.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            if (joinForm.visibility == View.VISIBLE) etMc.requestFocus()
        }
        tvBridgeToggle.setOnClickListener { bridgeChoice = !bridgeChoice; updateOwnerUi() }
        updateOwnerUi()
        buildRoomsPreview()

        findViewById<Button>(R.id.btnJoin).setOnClickListener { join() }
        // 右上の「オーナーを渡す」
        findViewById<Button>(R.id.btnGiveOwner).setOnClickListener { chooseNewOwner() }
        btnCopyCmd.setOnClickListener {
            copy(McBridge.COMMAND)
            Toast.makeText(this, "コピーしたよ！マイクラのチャットに貼り付けて送信してね", Toast.LENGTH_LONG).show()
        }
        // アプリをシェア（だれでも押せる。LINE や Discord などに送れる）
        val shareClick = View.OnClickListener { shareApp() }
        findViewById<ImageButton>(R.id.btnShareTop).setOnClickListener(shareClick)
        findViewById<ImageButton>(R.id.btnShareLobby).setOnClickListener(shareClick)
        // 入る前の画面の右上「オーナーを渡す」（オーナーだけに出る）
        findViewById<Button>(R.id.btnGiveOwnerLobby).setOnClickListener { chooseNewOwnerLobby() }
        findViewById<LinearLayout>(R.id.cardInvite).setOnClickListener(shareClick)
        btnMute.setOnClickListener { VoiceService.instance?.setMuted(!AppState.muted) }
        btnDeafen.setOnClickListener { VoiceService.instance?.setDeafened(!AppState.deafened) }
        btnOptOut.setOnClickListener { VoiceService.instance?.setOptOut(!AppState.optOut) }

        findViewById<ImageButton>(R.id.btnLeave).setOnClickListener { VoiceService.stop(this) }

        askPermissions()
        handleLink(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleLink(intent)
    }

    /** 招待リンク（shabekura://join?room=XXXXXX）から開かれたとき */
    private fun handleLink(i: Intent?) {
        val data = i?.data ?: return
        if (data.scheme != "shabekura") return
        val code = data.getQueryParameter("room")?.trim()?.uppercase().orEmpty()
        linkCode = if (Regex("^[A-Z0-9]{6}$").matches(code) && code != LOBBY) code else null
        if (AppState.running) return
        joinForm.visibility = View.VISIBLE
        toast("「近接VC待機所」の「入る」を押してね")
    }

    override fun onResume() {
        super.onResume()
        AppState.addListener(listener)
        lobbyPoll.removeCallbacksAndMessages(null)
        lobbyPoll.post(lobbyTick)
        render()
    }

    override fun onPause() {
        lobbyPoll.removeCallbacksAndMessages(null)
        AppState.removeListener(listener)
        super.onPause()
    }

    private fun askPermissions() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val start = pendingStart
        pendingStart = null
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            start?.invoke()
        } else if (start != null) {
            toast("マイクの許可がないと通話できないよ（設定 → アプリ → 権限）")
        }
    }

    /** マイクの許可を確認してから通話を始める */
    private fun withMic(action: () -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            action()
        } else {
            pendingStart = action
            askPermissions()
        }
    }

    /** みんなに表示される名前（一番最初に決めたもの） */
    private fun myName(): String? {
        val name = prefs.getString("displayName", "").orEmpty().trim()
        if (name.isEmpty()) {
            render(); toast("先に名前を決めてね"); return null
        }
        return name
    }

    /** このスマホの端末ID（オーナーを覚えるのに使う。アプリを消さない限り変わらない） */
    private fun deviceId(): String {
        var d = prefs.getString("dev", "").orEmpty()
        if (d.isEmpty()) {
            d = java.util.UUID.randomUUID().toString()
            prefs.edit().putString("dev", d).apply()
        }
        return d
    }

    private fun join() {
        val name = myName() ?: return
        val mc = etMc.text.toString().trim()
        prefs.edit().putString("mc", mc).apply()
        if (bridgeChoice && mc.isEmpty()) {
            toast("配信用（連携だけ）は、マイクラの名前を入れてね"); return
        }
        val code = linkCode ?: LOBBY
        withMic { VoiceService.start(this, code, name, mc, deviceId(), bridgeChoice) }
    }

    private fun shareApp() {
        val base = VoiceService.serverBase()
        val text = "むいいむ通話に来てね！\n" +
            "アプリを開いて名前を決めたら「近接VC待機所」をタップ →「入る」だけ！（マイクラの名前を入れると近接ボイスになるよ）\n" +
            "🌐 ブラウザで入る（ダウンロードなし・iPhoneもOK）:\n$base/?web=1\n" +
            "📱 アプリで入る・アプリを入れる:\n$base/"
        try {
            val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
            startActivity(Intent.createChooser(send, "アプリをシェア"))
        } catch (e: Exception) {
            copy(text)
            Toast.makeText(this, "シェアできなかったので、招待メッセージをコピーしたよ", Toast.LENGTH_LONG).show()
        }
    }

    /** オーナーを渡す相手を選ぶ（アプリやブラウザで入っている人の一覧） */
    // ---- 入る前の画面: 自分がオーナーか・オーナーを渡す（サーバーに聞く） ----
    private class LobbyMember(val id: Int, val name: String)
    private var lobbyIsOwner = false
    private var lobbyOwnerName: String? = null
    private var lobbyHasOwner = true
    private var lobbyMembers: List<LobbyMember> = emptyList()
    private val lobbyPoll = Handler(Looper.getMainLooper())
    private val lobbyHttp by lazy { okhttp3.OkHttpClient() }
    private val lobbyTick = object : Runnable {
        override fun run() {
            if (!AppState.running) refreshLobbyOwner()
            lobbyPoll.postDelayed(this, 4000)
        }
    }

    private fun refreshLobbyOwner() {
        val base = VoiceService.serverBase()
        if (base.isEmpty()) return
        val url = "$base/api/state?room=$LOBBY&dev=" + java.net.URLEncoder.encode(deviceId(), "UTF-8")
        Thread {
            try {
                val req = okhttp3.Request.Builder().url(url).build()
                lobbyHttp.newCall(req).execute().use { res ->
                    val m = MiniJson.parse(res.body?.string() ?: "") as? Map<*, *> ?: return@use
                    val list = (m["members"] as? List<*>).orEmpty().mapNotNull {
                        val o = it as? Map<*, *> ?: return@mapNotNull null
                        val id = (o["id"] as? Number)?.toInt() ?: return@mapNotNull null
                        LobbyMember(id, o["name"]?.toString() ?: "")
                    }
                    val owner = m["isOwner"] == true
                    val ownerName = m["ownerName"] as? String
                    val hasOwner = m["hasOwner"] != false
                    runOnUiThread {
                        lobbyIsOwner = owner; lobbyOwnerName = ownerName; lobbyHasOwner = hasOwner; lobbyMembers = list
                        render()
                    }
                }
            } catch (_: Exception) { }
        }.start()
    }

    private fun chooseNewOwnerLobby() {
        // 通話中ならいつもの方法で渡す
        if (AppState.running) { chooseNewOwner(); return }
        val others = lobbyMembers
        if (others.isEmpty()) {
            toast("今、通話に入っている人がいないよ。渡したい人に先に入ってもらってね"); return
        }
        val names = others.map { it.name }.toTypedArray<CharSequence>()
        android.app.AlertDialog.Builder(this)
            .setTitle("👑 だれにオーナーを渡す？")
            .setItems(names) { _, which ->
                val target = others[which]
                android.app.AlertDialog.Builder(this)
                    .setTitle("オーナーを渡す")
                    .setMessage("「${target.name}」にオーナーを渡すよ。\n渡したあとは、自分はふつうのメンバーになるよ。いい？")
                    .setPositiveButton("渡す") { _, _ -> giveOwnerLobby(target) }
                    .setNegativeButton("やめる", null)
                    .show()
            }
            .setNegativeButton("やめる", null)
            .show()
    }

    private fun giveOwnerLobby(target: LobbyMember) {
        val base = VoiceService.serverBase()
        val url = "$base/api/give?room=$LOBBY&id=${target.id}&dev=" + java.net.URLEncoder.encode(deviceId(), "UTF-8")
        Thread {
            var done = false
            try {
                val req = okhttp3.Request.Builder().url(url)
                    .post("".toRequestBody(null)).build()
                lobbyHttp.newCall(req).execute().use { res -> done = res.isSuccessful }
            } catch (_: Exception) { }
            runOnUiThread {
                toast(if (done) "「${target.name}」にオーナーを渡したよ" else "渡せなかった。もう一度やってみてね")
                refreshLobbyOwner()
            }
        }.start()
    }

    private fun chooseNewOwner() {
        val others = AppState.members.filter { it.name != AppState.myName }
        if (others.isEmpty()) {
            toast("ほかに入っている人がいないよ"); return
        }
        val names = others.map { it.name }.toTypedArray<CharSequence>()
        android.app.AlertDialog.Builder(this)
            .setTitle("👑 だれにオーナーを渡す？")
            .setItems(names) { _, which ->
                val target = others[which]
                android.app.AlertDialog.Builder(this)
                    .setTitle("オーナーを渡す")
                    .setMessage("「${target.name}」にオーナーを渡すよ。\n渡したあとは、自分はふつうのメンバーになるよ。いい？")
                    .setPositiveButton("渡す") { _, _ -> VoiceService.instance?.giveOwner(target.id) }
                    .setNegativeButton("やめる", null)
                    .show()
            }
            .setNegativeButton("やめる", null)
            .show()
    }

    private fun updateOwnerUi() {
        tvBridgeToggle.text = (if (bridgeChoice) "☑" else "☐") + " 配信用：このスマホは連携だけ（オーナーだけ・声は別のスマホ）"
    }

    /** 入る前の画面に、部屋1〜20を並べておく（Discord と同じ見た目） */
    private fun buildRoomsPreview() {
        val box = findViewById<LinearLayout>(R.id.llRoomsPreview)
        box.removeAllViews()
        for (room in 1..ROOMS) {
            val t = TextView(this)
            t.text = "🔊  🎧▮部屋$room"
            t.textSize = 15f
            t.setPadding(dp(8), dp(7), dp(8), dp(7))
            t.setTextColor(Color.parseColor("#80848E"))
            box.addView(t)
        }
    }

    private fun render() {
        val s = AppState
        val hasName = prefs.getString("displayName", "").orEmpty().isNotBlank()
        namePanel.visibility = if (!s.running && !hasName) View.VISIBLE else View.GONE
        setupPanel.visibility = if (s.running || !hasName) View.GONE else View.VISIBLE
        findViewById<TextView>(R.id.tvMyName).text = "👤 " + prefs.getString("displayName", "").orEmpty() + "　（タップで名前を変える）"
        callPanel.visibility = if (s.running) View.VISIBLE else View.GONE
        // 入る前の画面の右上（オーナーだけ「オーナーを渡す」）
        findViewById<Button>(R.id.btnGiveOwnerLobby).visibility = if (!s.running && lobbyIsOwner) View.VISIBLE else View.GONE
        findViewById<TextView>(R.id.tvLobbyOwner).text = when {
            lobbyIsOwner -> "👑 あなたがオーナー"
            lobbyOwnerName != null -> "👑 オーナー: $lobbyOwnerName"
            !lobbyHasOwner -> "👑 まだオーナーなし（最初に入った人がオーナー）"
            else -> ""
        }
        tvStatus.text = s.status

        if (!s.running) return

        val roomName = when {
            s.bridgeOnly -> "連携だけ"
            s.mcLinked && s.mySlot > 0 && !s.optOut -> "部屋${s.mySlot}"
            else -> "近接VC待機所"
        }
        tvRoom.text = (if (s.isHost) "👑 " else "") + roomName + "  ›"
        // オーナーだけ: 右上の「オーナーを渡す」とマイクラのコマンド（待機所でも部屋でも出る）
        btnCopyCmd.visibility = if (s.isHost) View.VISIBLE else View.GONE
        findViewById<Button>(R.id.btnGiveOwner).visibility = if (s.isHost && !s.bridgeOnly) View.VISIBLE else View.GONE

        var card = when {
            !s.mcLinked && s.isHost && s.bridgeOpen -> "🟡 マイクラとつながった。位置を取得中…"
            !s.mcLinked && s.isHost -> "⚪ 今は待機所でふつうの通話\n上の「⛏ マイクラのコマンドをコピー」 → マイクラのチャットに貼って送信すると、ワールドに入った人が部屋に移動するよ"
            !s.mcLinked -> "⚪ 近接VC待機所にいるよ（ふつうの通話）\n運営がマイクラで準備すると、ワールドに入った人から部屋に移動するよ"
            s.optOut -> "⏸ 通話を抜けてるよ（「通話に戻る」で戻れる）"
            s.mySlot > 0 -> "🟢 部屋${s.mySlot} にいるよ：近くの人ほど大きく聞こえる"
            else -> "🟡 近接VC待機所にいるよ：待機所の人どうしでふつうに話せる\nマイクラのワールドに入ると、空いてる部屋に自動で移動するよ"
        }
        if (s.bridgeOnly) {
            card = "🔗 連携だけモード：このスマホはマイクもスピーカーも使っていないよ（配信アプリがマイクを使える）\n" +
                "声は別のスマホで、同じ名前「${s.myName}」・同じマイクラの名前で「入る」してね\n\n" +
                when {
                    s.mcLinked -> "🟢 マイクラと連携中"
                    s.bridgeOpen -> "🟡 マイクラとつながった。位置を取得中…"
                    else -> "⚪ 上の「⛏ マイクラのコマンドをコピー」→ マイクラのチャットに貼って送信"
                }
        }
        if (s.isHost && s.bridgeInfo.isNotEmpty()) card += "\n\n" + s.bridgeInfo
        tvMc.text = card

        // 下のボタン（押すたびに切り替え。オフのときは赤い斜線のアイコン）
        btnMute.setImageResource(if (s.muted || s.deafened) R.drawable.ic_mic_off else R.drawable.ic_mic)
        btnDeafen.setImageResource(if (s.deafened) R.drawable.ic_headset_off else R.drawable.ic_headset)
        btnOptOut.visibility = if (s.mcLinked && !s.bridgeOnly) View.VISIBLE else View.GONE
        val voiceBtns = if (s.bridgeOnly) View.GONE else View.VISIBLE
        btnMute.visibility = voiceBtns
        btnDeafen.visibility = voiceBtns
        btnOptOut.text = if (s.optOut) "通話に戻る" else "通話を抜ける"

        // 短い説明（上のバーの下）
        var sub = card.lineSequence().first()
        if (s.isHost && s.bridgeInfo.isNotEmpty()) sub += "\n" + s.bridgeInfo.lineSequence().first()
        if (!s.mcLinked && !s.bridgeOpen) {
            sub += if (s.isHost) "\n⛏ 上のボタンでコマンドをコピー → マイクラのチャットに貼って送信"
            else {
                // マイクラのコマンドはオーナーだけ。だれがオーナーか分かるようにする
                val owner = s.members.firstOrNull { it.host }?.name
                "\n⛏ マイクラのコマンドはオーナー" + (if (owner != null) "（$owner）" else "") + "だけが使えるよ"
            }
        }
        tvSub.text = sub

        // ⌄ で「タイル」と「チャンネル一覧」を切り替え
        listPanel.visibility = if (showList) View.VISIBLE else View.GONE
        llTiles.visibility = if (showList) View.GONE else View.VISIBLE
        if (showList) renderChannels() else renderTiles()
    }

    /** 真ん中のタイル: 自分と、今声が聞こえる相手（Discord の通話画面みたいに） */
    private fun renderTiles() {
        val s = AppState
        val me = s.members.firstOrNull { it.name == s.myName }
        val others = s.members.filter { it.name != s.myName && (s.bridgeOnly || it.gain > 0.01f) && !it.out }
        val people = (if (me != null && !s.bridgeOnly) listOf(me) else emptyList()) + others
        llTiles.removeAllViews()
        if (people.isEmpty()) {
            val t = TextView(this)
            t.text = "まだ誰の声も聞こえないよ"
            t.setTextColor(Color.parseColor("#80848E"))
            t.setPadding(dp(8), dp(40), dp(8), dp(40))
            llTiles.addView(t)
            return
        }
        val cols = if (people.size == 1) 1 else 2
        val h = when {
            people.size == 1 -> dp(360)
            people.size == 2 -> dp(220)
            people.size <= 4 -> dp(180)
            else -> dp(150)
        }
        var i = 0
        while (i < people.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val rowLp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, h)
            rowLp.setMargins(0, if (i == 0) 0 else dp(10), 0, 0)
            llTiles.addView(row, rowLp)
            // 2人のときは縦に並べる（Discord と同じ）
            val perRow = if (people.size == 2) 1 else cols
            for (c in 0 until perRow) {
                if (i >= people.size) {
                    row.addView(View(this), LinearLayout.LayoutParams(0, h, 1f))
                    continue
                }
                val m = people[i++]
                val isMe = m.name == s.myName
                val talking = if (isMe) s.selfTalking else m.id in s.talking
                val tile = LinearLayout(this)
                tile.orientation = LinearLayout.VERTICAL
                tile.gravity = android.view.Gravity.CENTER
                tile.setBackgroundResource(if (talking) R.drawable.tile_talking else R.drawable.tile)
                val lp = LinearLayout.LayoutParams(0, h, 1f)
                lp.setMargins(if (c == 0) 0 else dp(10), 0, 0, 0)
                row.addView(tile, lp)

                // アイコン（名前の1文字目）
                val size = if (people.size == 1) dp(110) else dp(72)
                val av = TextView(this)
                av.text = m.name.take(1).uppercase()
                av.gravity = android.view.Gravity.CENTER
                av.setTextColor(Color.WHITE)
                av.textSize = if (people.size == 1) 44f else 28f
                av.setTypeface(null, Typeface.BOLD)
                av.setBackgroundResource(AVATARS[Math.floorMod(m.name.hashCode(), AVATARS.size)])
                tile.addView(av, LinearLayout.LayoutParams(size, size))

                // 名前（下の黒い札）
                val chip = TextView(this)
                val sb = StringBuilder()
                if (m.host) sb.append("👑 ")
                sb.append(m.name)
                if (isMe && s.deafened) sb.append("  🎧✕") else if (isMe && s.muted) sb.append("  🎤✕")
                if (!isMe && s.mcLinked && m.slot > 0) m.distance?.let { sb.append("  ${it.roundToInt()}m") }
                chip.text = sb.toString()
                chip.setTextColor(Color.parseColor(if (talking) "#23A55A" else "#F2F3F5"))
                chip.textSize = 15f
                chip.setTypeface(null, Typeface.BOLD)
                chip.setBackgroundResource(R.drawable.name_chip)
                chip.setPadding(dp(14), dp(6), dp(14), dp(6))
                val clp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                clp.setMargins(0, dp(14), 0, 0)
                tile.addView(chip, clp)
            }
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    /** Discord みたいなボイスチャンネル一覧（近接VC待機所 ＋ 部屋1〜20） */
    private fun renderChannels() {
        val s = AppState
        // 部屋ごとに人を分ける（0 = 近接VC待機所）
        val byRoom = HashMap<Int, MutableList<Member>>()
        for (m in s.members) {
            val room = if (s.mcLinked && m.slot in 1..ROOMS) m.slot else 0
            byRoom.getOrPut(room) { ArrayList() }.add(m)
        }
        val myRoom = s.members.firstOrNull { it.name == s.myName }?.let { if (s.mcLinked && it.slot in 1..ROOMS) it.slot else 0 }

        llChannels.removeAllViews()
        for (room in 0..ROOMS) {
            val title = if (room == 0) "🎤▮近接VC待機所" else "🎧▮部屋$room"
            val people = byRoom[room].orEmpty()
            val head = TextView(this)
            head.text = "🔊  $title" + if (room > 0 && people.isNotEmpty()) "   1/1" else ""
            head.textSize = 15f
            head.setPadding(dp(8), dp(7), dp(8), dp(7))
            val mine = room == myRoom
            head.setTextColor(if (mine || people.isNotEmpty()) Color.parseColor("#F2F3F5") else Color.parseColor("#80848E"))
            if (mine) head.setBackgroundResource(R.drawable.channel_selected)
            llChannels.addView(head)

            for (m in people) {
                val me = m.name == s.myName
                val talking = if (me) s.selfTalking else m.id in s.talking
                val row = TextView(this)
                val sb = StringBuilder()
                sb.append(if (talking) "🟢 " else "⚫ ")
                sb.append(m.name)
                if (m.host) sb.append(" 👑")
                if (me && s.bridgeOnly) {
                    sb.append("（声は別のスマホ）")
                } else if (me) {
                    sb.append("（自分）")
                    if (s.deafened) sb.append("  🎧✕") else if (s.muted) sb.append("  🎤✕")
                    else sb.append("  ").append("■".repeat(s.micLevel)).append("□".repeat(5 - s.micLevel))
                } else if (m.out) {
                    sb.append("  （抜けてる）")
                } else if (s.mcLinked && room > 0) {
                    val d = m.distance
                    sb.append(
                        when {
                            d == null -> ""
                            m.gain <= 0.01f -> "  ${d.roundToInt()}m・聞こえない"
                            else -> "  ${d.roundToInt()}m"
                        }
                    )
                }
                row.text = sb.toString()
                row.textSize = 14f
                row.setPadding(dp(40), dp(3), dp(8), dp(3))
                row.setTextColor(Color.parseColor(if (talking) "#23A55A" else "#DBDEE1"))
                if (talking) row.setTypeface(null, Typeface.BOLD)
                llChannels.addView(row)
            }
        }
    }

    private fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("shabekura", text))
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
