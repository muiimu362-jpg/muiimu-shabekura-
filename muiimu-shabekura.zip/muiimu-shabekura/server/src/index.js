// むいいむ しゃべくら 中継サーバー (Cloudflare Workers + Durable Objects)
import { DurableObject } from "cloudflare:workers";
import { WEB_HTML, MANIFEST, ICON_SVG } from "./web.js";

// これより遠い人には音声そのものを送らない（ブロック）
const SERVER_CUTOFF = 26;
// ホストから座標が届かなくなったら、通話を止めるまでの時間
const POS_TIMEOUT_MS = 5000;
// 部屋の数（通話1 = 運営、通話2〜MAX_SLOT = プレイヤー。1部屋1人）
const MAX_SLOT = 20;

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/ws") {
      if (request.headers.get("Upgrade") !== "websocket") {
        return new Response("websocket only", { status: 426 });
      }
      const code = (url.searchParams.get("room") || "").toUpperCase();
      if (!/^[A-Z0-9]{6}$/.test(code)) return new Response("bad room", { status: 400 });
      const stub = env.ROOM.get(env.ROOM.idFromName(code));
      return stub.fetch(request);
    }

    // 通話に入る前の画面用: 自分がオーナーか・今いる人（「オーナーを渡す」に使う）
    if (url.pathname === "/api/state" || url.pathname === "/api/give") {
      const code = (url.searchParams.get("room") || "").toUpperCase();
      if (!/^[A-Z0-9]{6}$/.test(code)) return new Response("bad room", { status: 400 });
      const stub = env.ROOM.get(env.ROOM.idFromName(code));
      return stub.fetch(request);
    }

    if (url.pathname === "/manifest.json") {
      return new Response(MANIFEST, { headers: { "content-type": "application/manifest+json" } });
    }
    if (url.pathname === "/icon.svg") {
      return new Response(ICON_SVG, { headers: { "content-type": "image/svg+xml" } });
    }
    if (url.pathname === "/health") {
      return new Response("むいいむ しゃべくら server OK", {
        headers: { "content-type": "text/plain; charset=utf-8" },
      });
    }
    // それ以外は Web 版（iPhone・PC 用）を返す
    return new Response(WEB_HTML, {
      headers: { "content-type": "text/html; charset=utf-8" },
    });
  },
};

export class Room extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.positions = {}; // name -> {x,y,z,d,r}
    this.lastPosAt = 0;
    this.mcOnline = false;
    this.slots = new Map();   // name -> 部屋番号
    this.optOut = new Set();  // 「通話を抜ける」を押した人
  }

  // オーナーは「端末ID」で覚える。新しい版（BUILD_ID が変わる）になったらリセット
  async ownerDev() {
    const build = (this.env && this.env.BUILD_ID) || "dev";
    if ((await this.ctx.storage.get("ownerBuild")) !== build) return null;
    return (await this.ctx.storage.get("ownerDev")) || null;
  }

  async setOwnerDev(dev) {
    const build = (this.env && this.env.BUILD_ID) || "dev";
    await this.ctx.storage.put("ownerDev", dev);
    await this.ctx.storage.put("ownerBuild", build);
  }

  openSockets(except) {
    return this.ctx
      .getWebSockets()
      .filter((s) => s !== except && s.readyState === 1);
  }

  // 通話に入っていなくても使える（オーナーかどうか・オーナーを渡す）
  async api(url, request) {
    const json = (o, st) => new Response(JSON.stringify(o), {
      status: st || 200,
      headers: { "content-type": "application/json; charset=utf-8", "access-control-allow-origin": "*", "cache-control": "no-store" },
    });
    const dev = (url.searchParams.get("dev") || "").slice(0, 64);
    const owner = await this.ownerDev();
    const isOwner = !!dev && dev === owner;
    const people = [];
    let ownerName = null;
    for (const s of this.openSockets()) {
      const b = s.deserializeAttachment();
      if (!b || b.bridge) continue;
      if (owner && b.dev === owner) ownerName = b.name;
      if (b.dev !== dev) people.push({ id: b.id, name: b.name });
    }
    if (url.pathname === "/api/give") {
      if (request.method !== "POST") return json({ ok: false, error: "POST only" }, 405);
      // オーナー以外は渡せない
      if (!isOwner) return json({ ok: false, error: "not owner" }, 403);
      const id = Number(url.searchParams.get("id"));
      if (!people.some((x) => x.id === id)) return json({ ok: false, error: "no such member" }, 404);
      await this.giveOwner(id);
      return json({ ok: true });
    }
    return json({ isOwner, hasOwner: !!owner, ownerName, members: isOwner ? people : [] });
  }

  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api/")) return this.api(url, request);
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    this.ctx.acceptWebSocket(server);

    const name = (url.searchParams.get("name") || "").trim().slice(0, 40);
    // マイクラの名前（なくても OK。入れた人だけマイクラの位置と結びつく）
    const mc = (url.searchParams.get("mc") || "").trim().slice(0, 40);
    if (!name) {
      server.close(4001, "no name");
      return new Response(null, { status: 101, webSocket: client });
    }
    // 「連携だけ」の接続（マイクラの位置を送るだけ。声は別のスマホ）
    const bridge = url.searchParams.get("role") === "bridge";
    // 端末ID。新しい版になってから一番最初に入った人の端末がオーナー
    const dev = (url.searchParams.get("dev") || "").slice(0, 64);
    let owner = await this.ownerDev();
    if (!owner && dev && !bridge) {
      owner = dev;
      await this.setOwnerDev(dev);
    }
    const isHost = !!dev && dev === owner;
    if (bridge && !isHost) {
      server.close(4003, "host only");
      return new Response(null, { status: 101, webSocket: client });
    }

    // 同じ名前・同じ役割で入り直したら古い接続を切る（連携だけ と 声 は同じ名前でも両立できる）
    const used = new Set();
    for (const s of this.openSockets(server)) {
      const a = s.deserializeAttachment();
      if (!a) continue;
      if (a.name === name && !!a.bridge === bridge) {
        try { s.close(4009, "replaced"); } catch (_) {}
      } else {
        used.add(a.id);
      }
    }
    let id = 1;
    while (used.has(id) && id < 250) id++;
    if (used.size >= 249) {
      server.close(4010, "room full");
      return new Response(null, { status: 101, webSocket: client });
    }

    server.serializeAttachment({ id, name, isHost, bridge, dev, mc });
    server.send(JSON.stringify({ t: "hello", id, host: isHost, bridge }));
    if (!bridge) this.optOut.delete(name);
    this.updateSlots();
    this.broadcastMembers();
    return new Response(null, { status: 101, webSocket: client });
  }

  posActive() {
    return this.mcOnline && Date.now() - this.lastPosAt < POS_TIMEOUT_MS;
  }

  // 聞こえるかどうか
  // ・運営が /connect する前 → 全員ふつうの通話
  // ・ワールドの外にいる人どうし → ふつうの通話
  // ・ワールドの中にいる人どうし → 近ければ聞こえる（部屋番号は違っても OK）
  // ・「通話を抜ける」中の人 → 誰とも話さない
  // その人のマイクラでの位置（マイクラの名前を入れていない人は無し）
  posOf(a) {
    return a && a.mc ? this.positions[a.mc] : undefined;
  }

  // a, b は接続の情報（名前・マイクラの名前など）
  canHear(a, b) {
    if (this.optOut.has(a.name) || this.optOut.has(b.name)) return false;
    if (!this.posActive()) return true;
    const inA = this.slots.has(a.name), inB = this.slots.has(b.name);
    if (!inA && !inB) return !this.posOf(a) && !this.posOf(b);
    if (!inA || !inB) return false;
    const pa = this.posOf(a);
    const pb = this.posOf(b);
    if (!pa || !pb) return false;
    if (pa.d !== pb.d) return false;
    const dx = pa.x - pb.x, dy = pa.y - pb.y, dz = pa.z - pb.z;
    return dx * dx + dy * dy + dz * dz <= SERVER_CUTOFF * SERVER_CUTOFF;
  }

  // 声で参加している人（「連携だけ」の接続は入れない）
  memberAttachments(except) {
    const list = [];
    for (const s of this.openSockets(except)) {
      const a = s.deserializeAttachment();
      if (a && !a.bridge) list.push(a);
    }
    return list.sort((x, y) => x.id - y.id);
  }

  // 「連携だけ」の接続をしているホストの名前（小文字）
  bridgeNames(except) {
    const set = new Set();
    for (const s of this.openSockets(except)) {
      const a = s.deserializeAttachment();
      if (a && a.bridge) set.add(a.name.toLowerCase());
    }
    return set;
  }

  // 運営として扱うか（ホストの鍵で入った人、または「連携だけ」と同じ名前の声担当）
  isOperator(a, bridgeNames) {
    return a.isHost || bridgeNames.has(a.name.toLowerCase());
  }

  // ワールドにいる人に部屋番号を割り当てる。変わったらみんなに知らせる
  updateSlots(except) {
    const members = this.memberAttachments(except);
    const bn = this.bridgeNames(except);
    const next = new Map();
    if (this.posActive()) {
      const eligible = (a) => !!this.posOf(a) && !this.optOut.has(a.name);
      // 運営は通話1
      for (const a of members) {
        if (this.isOperator(a, bn) && eligible(a) && ![...next.values()].includes(1)) next.set(a.name, 1);
      }
      // すでに部屋がある人はそのまま
      for (const a of members) {
        if (next.has(a.name) || !eligible(a)) continue;
        const old = this.slots.get(a.name);
        if (old && old !== 1 && ![...next.values()].includes(old)) next.set(a.name, old);
      }
      // 新しく入った人は空いている一番小さい番号へ
      for (const a of members) {
        if (next.has(a.name) || !eligible(a)) continue;
        const used = new Set(next.values());
        for (let n = 2; n <= MAX_SLOT; n++) {
          if (!used.has(n)) { next.set(a.name, n); break; }
        }
      }
    }
    let changed = next.size !== this.slots.size;
    if (!changed) {
      for (const [k, v] of next) if (this.slots.get(k) !== v) { changed = true; break; }
    }
    this.slots = next;
    if (changed) this.broadcastMembers(except);
  }

  broadcastText(obj, except) {
    const msg = JSON.stringify(obj);
    for (const s of this.openSockets(except)) {
      try { s.send(msg); } catch (_) {}
    }
  }

  broadcastMembers(except) {
    const bn = this.bridgeNames(except);
    const list = this.memberAttachments(except).map((a) => ({
      id: a.id,
      name: a.name,
      host: this.isOperator(a, bn),
      slot: this.slots.get(a.name) || 0,
      out: this.optOut.has(a.name),
      mc: a.mc || "",
      inWorld: !!this.posOf(a),
    }));
    this.broadcastText({ t: "members", list, mc: this.posActive(), max: MAX_SLOT, bridges: [...bn] }, except);
  }

  async webSocketMessage(ws, message) {
    const a = ws.deserializeAttachment();
    if (!a) return;

    if (typeof message === "string") {
      let m;
      try { m = JSON.parse(message); } catch (_) { return; }
      if (m.t === "pos" && a.isHost && m.p && typeof m.p === "object") {
        this.positions = m.p;
        this.lastPosAt = Date.now();
        const wasActive = this.mcOnline;
        this.mcOnline = true;
        this.broadcastText({ t: "pos", p: m.p });
        this.updateSlots();
        if (!wasActive) this.broadcastMembers();
      } else if (m.t === "mc" && a.isHost) {
        this.mcOnline = !!m.on;
        if (!m.on) this.positions = {};
        this.broadcastText({ t: "mc", on: !!m.on });
        this.updateSlots();
        this.broadcastMembers();
      } else if (m.t === "optout" && !a.bridge) {
        // 「通話を抜ける」/「通話に戻る」
        if (m.on) this.optOut.add(a.name); else this.optOut.delete(a.name);
        this.updateSlots();
        this.broadcastMembers();
      } else if (m.t === "giveOwner" && a.isHost && !a.bridge) {
        // オーナーを渡す（今のオーナーだけができる）
        await this.giveOwner(m.id);
      } else if (m.t === "ping") {
        ws.send(JSON.stringify({ t: "pong" }));
      }
      return;
    }

    // 音声フレーム: 先頭1バイトに話している人のIDを付けて、聞こえる範囲の人にだけ送る
    if (a.bridge) return; // 「連携だけ」の接続は声を送らない
    const data = new Uint8Array(message);
    if (data.length === 0 || data.length > 4000) return;
    const out = new Uint8Array(data.length + 1);
    out[0] = a.id;
    out.set(data, 1);
    for (const s of this.openSockets(ws)) {
      const b = s.deserializeAttachment();
      if (!b || b.bridge) continue; // 「連携だけ」の接続には声を流さない
      if (this.canHear(a, b)) {
        try { s.send(out); } catch (_) {}
      }
    }
  }

  async giveOwner(targetId) {
    let target = null;
    for (const s of this.openSockets()) {
      const b = s.deserializeAttachment();
      if (b && !b.bridge && b.id === targetId && b.dev) target = b;
    }
    if (!target) return;
    await this.setOwnerDev(target.dev);
    // 全員の「オーナーかどうか」を更新して知らせる
    for (const s of this.openSockets()) {
      const b = s.deserializeAttachment();
      if (!b) continue;
      b.isHost = b.dev === target.dev;
      s.serializeAttachment(b);
      if (b.bridge && !b.isHost) {
        // 前のオーナーの「連携だけ」は終わり
        try { s.close(4011, "owner changed"); } catch (_) {}
        continue;
      }
      try { s.send(JSON.stringify({ t: "owner", host: b.isHost, ownerName: target.name })); } catch (_) {}
    }
    // 前のオーナーのマイクラ連携は止まるので、ふつうの通話に戻る（新しいオーナーが /connect すると再開）
    this.mcOnline = false;
    this.positions = {};
    this.broadcastText({ t: "mc", on: false });
    this.updateSlots();
    this.broadcastMembers();
  }

  async webSocketClose(ws, code, reason) {
    try { ws.close(code, reason); } catch (_) {}
    this.updateSlots(ws);
    this.broadcastMembers(ws);
  }

  async webSocketError(ws) {
    this.updateSlots(ws);
    this.broadcastMembers(ws);
  }
}
