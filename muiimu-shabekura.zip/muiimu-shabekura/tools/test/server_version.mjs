import worker from "./idx.mjs";
globalThis.Response=class{constructor(b,o){this.body=b;this.headers=(o&&o.headers)||{};this.status=(o&&o.status)||200;}};
let fails=0; const ok=(c,m)=>{ if(!c){fails++; console.log("FAIL:",m);} };
const env={BUILD_ID:"20261127999999"};
const v=await worker.fetch({url:"https://x/api/version",headers:{get:()=>null}}, env);
ok(JSON.parse(v.body).build==="20261127999999" && v.headers["cache-control"]==="no-store", "版の番号を返す");
const h=await worker.fetch({url:"https://x/",headers:{get:()=>null}}, env);
ok(h.body.includes('var BUILD = "20261127999999"') && !h.body.includes("__BUILD_ID__") && h.headers["cache-control"]==="no-store", "ページに版の番号が入る・キャッシュしない");
console.log(fails?"FAILED "+fails:"ALL OK");
