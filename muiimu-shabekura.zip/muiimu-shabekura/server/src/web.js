// iPhone・PC 用の Web 版（サーバーから配る）
// 注意: このファイルの中のスクリプトではバッククォートと「ドル記号+波かっこ」を使わないこと
// Android 用 APK の直接ダウンロード先（GitHub のリリース）
const APK_URL = "https://github.com/muiimu362-jpg/muiimu-shabekura-/releases/latest/download/MuiimuShabekura.apk";
const WEB_HTML_RAW = `<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="しゃべくら">
<meta name="theme-color" content="#2E5E2A">
<link rel="manifest" href="/manifest.json">
<link rel="apple-touch-icon" href="/icon.svg">
<title>むいいむ しゃべくら</title>
<style>
  * { box-sizing: border-box; }
  body { margin:0; background:#2B2D31; color:#DBDEE1;
    font-family: -apple-system, "Hiragino Sans", "Noto Sans JP", sans-serif; }
  main { max-width: 480px; margin: 0 auto; padding: 20px 16px calc(24px + env(safe-area-inset-bottom)); }
  h1 { color:#F2F3F5; font-size:22px; margin:8px 0 2px; }
  .sub { color:#80848E; font-size:12px; margin-bottom:14px; }
  label { display:block; color:#B5BAC1; font-weight:700; font-size:12px; margin-top:16px; }
  input { width:100%; font-size:16px; padding:12px; border:0; border-radius:6px; margin-top:6px; background:#1E1F22; color:#F2F3F5; }
  button { width:100%; font-size:15px; padding:13px; border:0; border-radius:8px; margin-top:10px;
    background:#5865F2; color:#fff; font-weight:700; }
  button.sec { background:#383A40; color:#DBDEE1; font-weight:500; }
  button.red { background:#DA373C; color:#fff; }
  .row { display:flex; gap:6px; } .row button { flex:1; font-size:12px; padding:12px 2px; white-space:nowrap; }
  .room { font-size:16px; font-weight:700; color:#F2F3F5; }
  .mc { margin-top:8px; padding:12px; border-radius:8px; background:#232428; font-size:13px; line-height:1.6; }
  .ch { padding:7px 8px; font-size:15px; color:#80848E; border-radius:6px; }
  .ch.has { color:#F2F3F5; } .ch.mine { background:#404249; color:#F2F3F5; }
  .ch .cnt { float:right; font-size:12px; color:#80848E; }
  .mem { padding:3px 8px 3px 40px; font-size:14px; color:#DBDEE1; }
  .mem.talk { color:#23A55A; font-weight:700; }
  #status { color:#949BA4; margin-top:16px; min-height:1.2em; }
  .note { color:#6D6F78; font-size:12px; margin-top:12px; line-height:1.6; }
  @keyframes bob { from { transform: translateY(0); } to { transform: translateY(-8px); } }
  .hidden { display:none !important; }
  .topbar { display:flex; align-items:center; gap:8px; }
  .ib { width:44px; height:44px; padding:10px; margin:0; border-radius:14px; background:#1E1F22; flex:none; }
  .ib svg, .bb svg { width:100%; height:100%; }
  .pill { height:44px; line-height:44px; padding:0 14px; border-radius:14px; background:#1E1F22; color:#F2F3F5; font-weight:700; font-size:17px; cursor:pointer; white-space:nowrap; }
  .ownerbtn { width:44px; height:44px; margin:0 0 0 8px; padding:0; border-radius:14px; background:#1E1F22; color:#F0B232; font-size:20px; flex:none; }
  .memcount { width:auto; height:44px; margin:0 0 0 8px; padding:0 12px; border-radius:14px; background:#1E1F22; color:#fff; font-size:15px; font-weight:700; flex:none; }
  .mcnt { margin-left:4px; }
  .mrow { padding:6px 0; font-size:16px; color:#F2F3F5; }
  .mrow.off { color:#80848E; }
  .mhead { color:#949BA4; font-size:13px; font-weight:700; padding:12px 0 6px; }
  .subline { color:#B5BAC1; font-size:12px; margin-top:8px; white-space:pre-line; }
  #tiles { margin-top:12px; display:grid; grid-template-columns:1fr 1fr; gap:10px; }
  .tile { background:#45474C; border-radius:20px; display:flex; flex-direction:column; align-items:center; justify-content:center; height:180px; border:3px solid transparent; }
  .tile.one { grid-column:1 / span 2; height:360px; } .tile.wide { grid-column:1 / span 2; height:220px; }
  .tile.talk { border-color:#23A55A; }
  .av { width:72px; height:72px; border-radius:50%; display:flex; align-items:center; justify-content:center; color:#fff; font-weight:700; font-size:28px; }
  .tile.one .av { width:110px; height:110px; font-size:44px; }
  .chip { margin-top:14px; background:rgba(17,18,20,.9); color:#F2F3F5; font-weight:700; font-size:15px; padding:6px 14px; border-radius:12px; }
  .tile.talk .chip { color:#23A55A; }
  .empty { grid-column:1 / span 2; color:#80848E; padding:40px 8px; }
  .invite { display:flex; align-items:center; margin-top:16px; padding:16px; border-radius:22px; background:#0B0C0E; cursor:pointer; }
  .bar { display:flex; gap:12px; margin-top:14px; padding:12px; border-radius:22px; background:#1E1F22; border:1px solid #3A3C42; }
  .bb { flex:1; height:60px; margin:0; padding:14px; border-radius:14px; background:#2B2D31; }
  .bb.red { background:#DA373C; border-radius:18px; }
</style>
</head>
<body>
<main>
  <h1>むいいむ しゃべくら</h1>
  <div class="sub">むいいむ通話 ・ 近づくと聞こえるボイスチャット（Web版）</div>

  <audio id="voiceOut" autoplay playsinline style="display:none"></audio>
  <div id="updateNote" class="hidden" style="position:fixed;left:0;right:0;top:0;background:#DA373C;color:#fff;padding:8px 12px;font-size:13px;z-index:98;text-align:center">新しい版が出たよ！通話を抜けると自動で新しくなるよ</div>
  <div id="guide" class="hidden" style="pointer-events:none;position:absolute;z-index:97;max-width:300px;background:#F0B232;color:#111;border-radius:12px;padding:10px 32px 10px 12px;font-weight:700;font-size:15px;line-height:1.4;box-shadow:0 4px 14px rgba(0,0,0,.5)">
    <div id="guideArrow" style="position:absolute;bottom:-30px;left:14px;font-size:26px;animation:bob .8s ease-in-out infinite alternate">👇</div>
    <div id="guideText"></div>
    <div id="guideClose" style="pointer-events:auto;position:absolute;top:4px;right:8px;font-size:16px;cursor:pointer">✕</div>
  </div>
  <section id="qrPage" class="hidden" style="text-align:center;padding-top:10px">
    <div style="color:#F2F3F5;font-weight:800;font-size:24px">📱 スマホのカメラで読みとってね</div>
    <div style="color:#B5BAC1;margin:6px 0 14px">むいいむ しゃべくら（近くの人の声が聞こえる通話）に参加できるよ</div>
    <canvas id="qrCanvas" style="width:min(80vw,420px);height:auto;border-radius:12px;background:#fff;image-rendering:pixelated"></canvas>
    <div id="qrUrl" style="color:#F2F3F5;margin-top:12px;word-break:break-all;font-size:15px"></div>
    <a id="qrSave" download="shabekura-qr.png"><button class="sec">🖼 QRコードの画像を保存</button></a>
  </section>
<div id="memberPanel" class="hidden" style="position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:96">
    <div style="position:absolute;left:0;right:0;bottom:0;max-height:80vh;overflow:auto;background:#2B2D31;border-radius:16px 16px 0 0;padding:16px 18px 24px">
      <div style="display:flex;align-items:center"><div style="flex:1;color:#F2F3F5;font-weight:800;font-size:18px">👤 メンバー</div><button id="memberClose" class="sec" style="width:auto;margin:0;padding:6px 14px">とじる</button></div>
      <div id="memberList"></div>
    </div>
  </div>
  <div id="copied" class="hidden" style="position:fixed;left:50%;bottom:110px;transform:translateX(-50%);background:#111214;color:#fff;padding:10px 16px;border-radius:20px;font-size:14px;z-index:99">📋 リンクをコピーしたよ！貼り付けて送ってね</div>
  <section id="android" class="hidden">
    <div style="color:#F2F3F5;font-weight:700;font-size:20px;margin-top:18px">どっちで入る？</div>
    <button id="useBrowser">🌐 ブラウザ</button>
    <a id="dlApk" href="__APK_URL__"><button class="sec">📱 アプリ（ダウンロード）</button></a>
    <div class="note">
      ・ブラウザ：押したらすぐ使える。ダウンロードなし。iPhoneもOK。<br>
      ・アプリ：Androidだけ。ダウンロードしたファイルを開いてインストールしてね（「提供元不明のアプリ」の許可を聞かれたら許可）。
    </div>
  </section>

  <section id="namePanel" class="hidden">
    <div class="mc" style="margin-top:20px">
      <div style="color:#F2F3F5;font-weight:700;font-size:18px">名前を決めてください</div>
      <div class="note" style="margin-top:4px">マイクラの名前じゃなくてOK。みんなに表示される名前だよ</div>
      <input id="displayName" autocomplete="off" placeholder="例: むいいむ">
      <button id="randomName" class="sec">🎲 ランダムな名前にする</button>
      <button id="setName">決定</button>
    </div>
  </section>

  <section id="setup" class="hidden">
    <div class="topbar">
      <div id="lobbyOwner" style="flex:1;color:#949BA4;font-size:12px;padding-left:6px"></div>
      <button id="shareLobby" class="ib"><svg viewBox="0 0 24 24"><path fill="#fff" d="M15,12c2.21,0 4,-1.79 4,-4s-1.79,-4 -4,-4 -4,1.79 -4,4 1.79,4 4,4zM6,10V7H4v3H1v2h3v3h2v-3h3v-2H6zM15,14c-2.67,0 -8,1.34 -8,4v2h16v-2c0,-2.66 -5.33,-4 -8,-4z"/></svg></button>
      <button id="membersLobby" class="memcount" title="メンバー"><svg viewBox="0 0 24 24" style="width:20px;height:20px;vertical-align:-4px"><path fill="#fff" d="M12,12c2.21,0 4,-1.79 4,-4s-1.79,-4 -4,-4 -4,1.79 -4,4 1.79,4 4,4zM12,14c-2.67,0 -8,1.34 -8,4v2h16v-2c0,-2.66 -5.33,-4 -8,-4z"/></svg><span class="mcnt">0</span></button>
      <button id="giveOwnerLobby" class="ownerbtn hidden" title="オーナーを渡す">👑</button>
    </div>
    <div id="lobbyPick" class="mc hidden">
      <div style="color:#F2F3F5;font-weight:700">👑 だれにオーナーを渡す？</div>
      <div id="lobbyList"></div>
      <button id="lobbyCancel" class="sec">やめる</button>
    </div>
    <div id="myNameLabel" style="color:#B5BAC1;font-size:13px;padding:6px;cursor:pointer"></div>
    <label>ボイスチャンネル</label>
    <div class="ch mine" id="chLobby" style="cursor:pointer">🔊  🎤▮近接VC待機所　（タップして入る）</div>
    <div id="lobbyPeople"></div>
    <div class="mc hidden" id="joinForm">
      <div style="color:#F2F3F5;font-weight:700;font-size:15px">マイクラの名前（サブの名前）</div>
      <div class="note" style="margin-top:2px">入れるとマイクラと連携して、近くの人の声が聞こえるよ。なくてもOK（待機所でふつうに話せる）。Switch・PS の人は、そのマイクラで表示される名前をそのまま入れてね</div>
      <input id="mcName" autocomplete="off" autocapitalize="off" placeholder="例: gopura777（なくてもOK）">
      <input id="room" type="hidden">
      <button id="join">入る</button>
    </div>
    <div id="roomsPreview"></div>
    <button id="guideOn" class="sec" style="margin-top:14px">❓ やり方を1つずつ見る</button>
  </section>

  <section id="call" class="hidden">
    <div class="topbar">
      <button id="collapse" class="ib"><svg viewBox="0 0 24 24"><path fill="#fff" d="M16.59,8.59L12,13.17 7.41,8.59 6,10l6,6 6,-6z"/></svg></button>
      <div class="pill" id="roomLabel"></div>
      <div style="flex:1"></div>
      <button id="shareTop" class="ib"><svg viewBox="0 0 24 24"><path fill="#fff" d="M15,12c2.21,0 4,-1.79 4,-4s-1.79,-4 -4,-4 -4,1.79 -4,4 1.79,4 4,4zM6,10V7H4v3H1v2h3v3h2v-3h3v-2H6zM15,14c-2.67,0 -8,1.34 -8,4v2h16v-2c0,-2.66 -5.33,-4 -8,-4z"/></svg></button>
      <button id="membersTop" class="memcount" title="メンバー"><svg viewBox="0 0 24 24" style="width:20px;height:20px;vertical-align:-4px"><path fill="#fff" d="M12,12c2.21,0 4,-1.79 4,-4s-1.79,-4 -4,-4 -4,1.79 -4,4 1.79,4 4,4zM12,14c-2.67,0 -8,1.34 -8,4v2h16v-2c0,-2.66 -5.33,-4 -8,-4z"/></svg><span class="mcnt">0</span></button>
      <button id="giveOwner" class="ownerbtn hidden" title="オーナーを渡す">👑</button>
    </div>
    <div id="ownerPick" class="mc hidden">
      <div style="color:#F2F3F5;font-weight:700">👑 だれにオーナーを渡す？</div>
      <div id="ownerList"></div>
      <button id="ownerCancel" class="sec">やめる</button>
    </div>
    <div id="volPick" class="mc hidden">
      <div id="volTitle" style="color:#F2F3F5;font-weight:700"></div>
      <div id="volLabel" style="margin-top:6px"></div>
      <input id="volRange" type="range" min="0" max="100" step="1" value="100" style="width:100%;margin:10px 0">
      <button id="volMute" class="sec">🔇 ミュートする</button>
      <button id="volReset" class="sec">100%に戻す</button>
      <button id="volClose">とじる</button>
    </div>
    <div class="subline" id="sub"></div>
    <button id="hearHelp" class="sec" style="margin:4px 0 0;padding:8px;font-size:13px">🔊 相手の声が聞こえない時はここ</button>
    <div id="tiles"></div>
    <div id="listView" class="hidden">
      <div class="mc" id="mc"></div>
      <label>ボイスチャンネル</label>
      <div id="members"></div>
      <button id="optout" class="sec hidden">通話を抜ける</button>
    </div>
    <div class="invite" id="invite"><svg style="width:30px;height:30px;flex:none" viewBox="0 0 24 24"><path fill="#fff" d="M15,12c2.21,0 4,-1.79 4,-4s-1.79,-4 -4,-4 -4,1.79 -4,4 1.79,4 4,4zM6,10V7H4v3H1v2h3v3h2v-3h3v-2H6zM15,14c-2.67,0 -8,1.34 -8,4v2h16v-2c0,-2.66 -5.33,-4 -8,-4z"/></svg>
      <div style="flex:1;margin-left:14px"><div style="color:#F2F3F5;font-weight:700;font-size:16px">ボイスチャットにメンバーを追加</div>
      <div style="color:#949BA4;font-size:12px">リンクをコピーして友だちに送ろう！</div></div>
      <div style="color:#949BA4;font-size:24px">›</div>
    </div>
    <div class="bar">
      <button id="deafen" class="bb"></button>
      <button id="mute" class="bb"></button>
      <button id="leave" class="bb red" style="flex:1.2"><svg viewBox="0 0 24 24"><path fill="#fff" d="M12,9c-1.6,0 -3.15,0.25 -4.6,0.72v3.1c0,0.39 -0.23,0.74 -0.56,0.9 -0.98,0.49 -1.87,1.12 -2.66,1.85 -0.18,0.18 -0.43,0.28 -0.7,0.28 -0.28,0 -0.53,-0.11 -0.71,-0.29L0.29,13.08c-0.18,-0.17 -0.29,-0.42 -0.29,-0.7 0,-0.28 0.11,-0.53 0.29,-0.71C3.34,8.78 7.46,7 12,7s8.66,1.78 11.71,4.67c0.18,0.18 0.29,0.43 0.29,0.71 0,0.28 -0.11,0.53 -0.29,0.71l-2.48,2.48c-0.18,0.18 -0.43,0.29 -0.71,0.29 -0.27,0 -0.52,-0.11 -0.7,-0.28 -0.79,-0.74 -1.69,-1.36 -2.67,-1.85 -0.33,-0.16 -0.56,-0.5 -0.56,-0.9v-3.1C15.15,9.25 13.6,9 12,9z"/></svg></button>
    </div>
  </section>

  <div id="status"></div>
  <div class="note" id="webNote">
    ・このページは開いたまま（画面をつけたまま）にしてね。別のアプリに切り替えると声が止まります。<br>
    ・iPhoneで同じ端末のマイクラを遊ぶ場合は声が止まるので、Switch・PS・PCで遊ぶときの「横に置く用」に使ってね。<br>
    ・Safariの共有ボタン →「ホーム画面に追加」でアプリみたいに使えます。<br>
    ・イヤホン推奨。
  </div>
</main>

<script>
(function () {
  var RATE = 16000, FRAME = 640, VAD_LEVEL = 280, VAD_HANG = 8;
  var FULL = 1, MAX = 7;
  // ブロックごとの音量: 1=少し大きめ、2=ふつう、3=けっこう聞こえる、4〜5で小さく、6=薄い、7=聞こえない（アプリと同じ）
  var STEPS = [1.25, 1.25, 1, 0.75, 0.5, 0.3, 0.12, 0];
  function gainAt(d) {
    if (d <= 1) return STEPS[1];
    if (d >= 7) return 0;
    var i = Math.floor(d), t = d - i;
    return STEPS[i] * (1 - t) + STEPS[i + 1] * t;
  }
  function $(id) { return document.getElementById(id); }

  // ---- μ-law ----
  var DEC = new Float32Array(256);
  (function () {
    for (var u = 0; u < 256; u++) {
      var x = (~u) & 0xFF, sign = x & 0x80, e = (x >> 4) & 7, m = x & 0x0F;
      var mag = (((m << 3) + 0x84) << e) - 0x84;
      DEC[u] = (sign ? -mag : mag) / 32768;
    }
  })();
  function enc(s) {
    var sign = 0;
    if (s < 0) { s = -s; sign = 0x80; }
    if (s > 32635) s = 32635;
    s += 0x84;
    var e = 7, mask = 0x4000;
    while ((s & mask) === 0 && e > 0) { e--; mask >>= 1; }
    var m = (s >> (e + 3)) & 0x0F;
    return (~(sign | (e << 4) | m)) & 0xFF;
  }

  // ---- 状態 ----
  var ws = null, ctx = null, stream = null, running = false, retry = 0, micProblem = "", master = null, outEl = null, capNode = null, micSrc = null, speakerMode = false;
  var isIOS = /iPhone|iPad|iPod/i.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  var myName = "", myMc = "", room = "", muted = false, deafened = false, mySlot = 0, optOut = false, selfTalking = false, hang = 0;
  var members = {}, positions = {}, mcOn = false, lastPos = 0;
  var speakers = {};
  var inBuf = [], rpos = 0, frame = new Int16Array(FRAME), fpos = 0;
  var wakeLock = null;

  try {
    $("mcName").value = localStorage.getItem("mc") || "";
    $("room").value = localStorage.getItem("room") || "";
  } catch (e) {}
  var qp = new URLSearchParams(location.search).get("room");
  if (qp) $("room").value = qp.toUpperCase();

    var ICON_MIC = '<svg viewBox="0 0 24 24"><path fill="#fff" d="M12,14c1.66,0 3,-1.34 3,-3V5c0,-1.66 -1.34,-3 -3,-3S9,3.34 9,5v6c0,1.66 1.34,3 3,3zM17.3,11c0,3 -2.54,5.1 -5.3,5.1S6.7,14 6.7,11H5c0,3.41 2.72,6.23 6,6.72V21h2v-3.28c3.28,-0.48 6,-3.3 6,-6.72h-1.7z"/></svg>', ICON_MICOFF = '<svg viewBox="0 0 24 24"><path fill="#F23F43" d="M19,11h-1.7c0,0.74 -0.16,1.43 -0.43,2.05l1.23,1.23c0.56,-0.98 0.9,-2.09 0.9,-3.28zM14.98,11.17c0,-0.06 0.02,-0.11 0.02,-0.17V5c0,-1.66 -1.34,-3 -3,-3S9,3.34 9,5v0.18l5.98,5.99zM4.27,3L3,4.27l6.01,6.01V11c0,1.66 1.33,3 2.99,3 0.22,0 0.44,-0.03 0.65,-0.08l1.66,1.66c-0.71,0.33 -1.5,0.52 -2.31,0.52 -2.76,0 -5.3,-2.1 -5.3,-5.1H5c0,3.41 2.72,6.23 6,6.72V21h2v-3.28c0.91,-0.13 1.77,-0.45 2.54,-0.9L19.73,21 21,19.73 4.27,3z"/></svg>', ICON_HEAD = '<svg viewBox="0 0 24 24"><path fill="#fff" d="M12,2C7.03,2 3,6.03 3,11v6.5C3,19.43 4.57,21 6.5,21H9v-8H5v-2c0,-3.87 3.13,-7 7,-7s7,3.13 7,7v2h-4v8h2.5c1.93,0 3.5,-1.57 3.5,-3.5V11c0,-4.97 -4.03,-9 -9,-9z"/></svg>', ICON_HEADOFF = '<svg viewBox="0 0 24 24"><path fill="#F23F43" d="M12,2C7.03,2 3,6.03 3,11v6.5C3,19.43 4.57,21 6.5,21H9v-8H5v-2c0,-3.87 3.13,-7 7,-7s7,3.13 7,7v2h-4v8h2.5c1.93,0 3.5,-1.57 3.5,-3.5V11c0,-4.97 -4.03,-9 -9,-9z"/><path stroke="#1E1F22" stroke-width="4" stroke-linecap="round" d="M3.5,3.5L20.5,20.5"/><path stroke="#F23F43" stroke-width="2" stroke-linecap="round" d="M3.5,3.5L20.5,20.5"/></svg>';
  // 最初の画面: 「ブラウザ」か「アプリ」を選ぶ（どの端末でも）
  var androidPage = true;
  $("setup").classList.add("hidden");
  $("webNote").classList.add("hidden");
  $("android").classList.remove("hidden");
  // ブラウザ: 押した瞬間にブラウザで使える
  $("useBrowser").onclick = function () {
    androidPage = false;
    $("android").classList.add("hidden");
    $("webNote").classList.remove("hidden");
    showStart();
  };

  // 新しい版が出たら: 通話していなければ自動で読み込み直す。通話中なら上にお知らせ
  var BUILD = "__BUILD_ID__";
  function checkVersion() {
    if (BUILD.indexOf("__") === 0) return;
    fetch("/api/version", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (v) {
      if (!v || !v.build || v.build === BUILD) return;
      if (!running) location.reload();
      else $("updateNote").classList.remove("hidden");
    }).catch(function () {});
  }
  setInterval(checkVersion, 60000);

  function setStatus(t) { $("status").textContent = t; }

  // このブラウザの端末ID（オーナーを覚えるのに使う）
  function deviceId() {
    var d = "";
    try { d = localStorage.getItem("dev") || ""; } catch (e) {}
    if (!d) {
      d = "web-" + Math.random().toString(36).slice(2) + Date.now().toString(36);
      try { localStorage.setItem("dev", d); } catch (e) {}
    }
    return d;
  }
  var isOwner = false;
  $("giveOwner").onclick = function () {
    var list = $("ownerList"); list.textContent = "";
    Object.keys(members).forEach(function (id) {
      var x = members[id];
      if (x.name === myName) return;
      var b = document.createElement("button"); b.className = "sec"; b.textContent = x.name;
      b.onclick = function () {
        if (!confirm("「" + x.name + "」にオーナーを渡すよ。渡したあとは、自分はふつうのメンバーになるよ。いい？")) return;
        if (ws && ws.readyState === 1) ws.send(JSON.stringify({ t: "giveOwner", id: Number(id) }));
        $("ownerPick").classList.add("hidden");
      };
      list.appendChild(b);
    });
    if (!list.childNodes.length) list.textContent = "ほかに入っている人がいないよ";
    $("ownerPick").classList.remove("hidden");
  };
  $("ownerCancel").onclick = function () { $("ownerPick").classList.add("hidden"); };

  // 入る前の画面: 右上のシェア（だれでも）と「オーナーを渡す」（オーナーだけ）
  var lobbyMembers = [], lobbyIsOwner = false;
  function lobbyRoom() { return ($("room").value || "MUIIMU").toUpperCase(); }
  var lobbyPeople = [], lobbyResting = [];
  function refreshLobbyOwner() {
    if ($("setup").classList.contains("hidden") && !running) return;
    fetch("/api/state?room=" + encodeURIComponent(lobbyRoom()) + "&dev=" + encodeURIComponent(deviceId()), { cache: "no-store" })
      .then(function (r) { return r.json(); })
      .then(function (m) {
        lobbyIsOwner = !!m.isOwner; lobbyMembers = m.members || [];
        lobbyPeople = m.people || []; lobbyResting = m.resting || [];
        updateMemberCount();
        if (!$("memberPanel").classList.contains("hidden")) renderMembers();
        renderPreview(m.people);
        $("giveOwnerLobby").classList.toggle("hidden", !lobbyIsOwner);
        $("lobbyOwner").textContent = lobbyIsOwner ? "👑 あなたがオーナー" :
          m.ownerName ? ("👑 オーナー: " + m.ownerName) :
          !m.hasOwner ? "👑 まだオーナーなし（最初に入った人がオーナー）" : "";
      }).catch(function () {});
  }
  setInterval(refreshLobbyOwner, 4000);

  // ---- 人のマーク: オンライン（今アプリ・ブラウザを開いてる人）と 休憩中（前に来た人）。Discord と同じ ----
  function onlineList() {
    if (running && Object.keys(members).length) {
      return Object.keys(members).map(function (id) { var x = members[id]; return { name: x.name, slot: mcOn ? (x.slot || 0) : 0, host: !!x.host }; });
    }
    return lobbyPeople;
  }
  function updateMemberCount() {
    var n = onlineList().length;
    document.querySelectorAll(".mcnt").forEach(function (e) { e.textContent = String(n); });
  }
  function ago(ms) {
    var m = Math.floor(ms / 60000);
    if (m < 1) return "さっき"; if (m < 60) return m + "分前"; if (m < 1440) return Math.floor(m / 60) + "時間前";
    return Math.floor(m / 1440) + "日前";
  }
  function renderMembers() {
    var box = $("memberList"); box.textContent = "";
    function head(t) { var d = document.createElement("div"); d.className = "mhead"; d.textContent = t; box.appendChild(d); }
    function row(t, off) { var d = document.createElement("div"); d.className = "mrow" + (off ? " off" : ""); d.textContent = t; box.appendChild(d); }
    var on = onlineList().slice().sort(function (a, b) { return (b.host - a.host) || (a.name < b.name ? -1 : 1); });
    head("オンライン — " + on.length);
    on.forEach(function (p) { row("🟢 " + (p.host ? "👑 " : "") + p.name + "　" + (p.slot ? "部屋" + p.slot : "待機所"), false); });
    var names = {}; on.forEach(function (p) { names[p.name] = 1; });
    var rest = lobbyResting.filter(function (p) { return !names[p.name]; });
    head("休憩中 — " + rest.length);
    var now = Date.now();
    rest.forEach(function (p) { row("⚫ " + p.name + "　" + ago(now - p.last), true); });
  }
  function openMembers() { renderMembers(); $("memberPanel").classList.remove("hidden"); refreshLobbyOwner(); }
  $("membersLobby").onclick = openMembers;
  $("membersTop").onclick = openMembers;
  $("memberClose").onclick = function () { $("memberPanel").classList.add("hidden"); };
  $("memberPanel").onclick = function (e) { if (e.target === $("memberPanel")) $("memberPanel").classList.add("hidden"); };
  $("shareLobby").onclick = function () { shareApp(); };
  $("giveOwnerLobby").onclick = function () {
    var list = $("lobbyList"); list.textContent = "";
    lobbyMembers.forEach(function (x) {
      var b = document.createElement("button"); b.className = "sec"; b.textContent = x.name;
      b.onclick = function () {
        if (!confirm("「" + x.name + "」にオーナーを渡すよ。渡したあとは、自分はふつうのメンバーになるよ。いい？")) return;
        fetch("/api/give?room=" + encodeURIComponent(lobbyRoom()) + "&id=" + x.id + "&dev=" + encodeURIComponent(deviceId()), { method: "POST" })
          .then(function (r) { setStatus(r.ok ? ("「" + x.name + "」にオーナーを渡したよ") : "渡せなかった。もう一度やってみてね"); refreshLobbyOwner(); })
          .catch(function () { setStatus("渡せなかった。もう一度やってみてね"); });
        $("lobbyPick").classList.add("hidden");
      };
      list.appendChild(b);
    });
    if (!list.childNodes.length) list.textContent = "今、通話に入っている人がいないよ。渡したい人に先に入ってもらってね";
    $("lobbyPick").classList.remove("hidden");
  };
  $("volRange").oninput = function () { try { localStorage.setItem("vol_" + volWho, String(this.value)); } catch (e) {} saveVolume(); };
  $("volMute").onclick = function () {
    try { if (localStorage.getItem("mute_" + volWho) === "1") localStorage.removeItem("mute_" + volWho); else localStorage.setItem("mute_" + volWho, "1"); } catch (e) {}
    saveVolume();
  };
  $("volReset").onclick = function () { try { localStorage.removeItem("vol_" + volWho); localStorage.removeItem("mute_" + volWho); } catch (e) {} $("volRange").value = 100; saveVolume(); };
  $("volClose").onclick = function () { $("volPick").classList.add("hidden"); };
  $("lobbyCancel").onclick = function () { $("lobbyPick").classList.add("hidden"); };

  // 一番最初は「名前を決めてください」
  function savedName() { try { return localStorage.getItem("displayName") || ""; } catch (e) { return ""; } }
  // ---- QRコードを作る（外のライブラリなし。バイトモード・誤り訂正M・1〜10型） ----
  var QR = (function () {
    // [誤り訂正の数/ブロック, [ブロック数, データ数], [ブロック数, データ数]]
    var EC_M = [null,
      [10, [1, 16]], [16, [1, 28]], [26, [1, 44]], [18, [2, 32]], [24, [2, 43]],
      [16, [4, 27]], [18, [4, 31]], [22, [2, 38], [2, 39]], [22, [3, 36], [2, 37]], [26, [4, 43], [1, 44]]];
    var ALIGN = [null, [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50]];
    var EXP = new Array(512), LOG = new Array(256);
    (function () { var x = 1; for (var i = 0; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 256) x ^= 0x11D; } for (var j = 255; j < 512; j++) EXP[j] = EXP[j - 255]; })();
    function mul(a, b) { return (a && b) ? EXP[LOG[a] + LOG[b]] : 0; }
    function rsGen(n) { var g = [1]; for (var i = 0; i < n; i++) { var ng = new Array(g.length + 1).fill(0); for (var j = 0; j < g.length; j++) { ng[j] ^= g[j]; ng[j + 1] ^= mul(g[j], EXP[i]); } g = ng; } return g; }
    function rsEc(data, n) {
      var g = rsGen(n), res = data.concat(new Array(n).fill(0));
      for (var i = 0; i < data.length; i++) { var c = res[i]; if (c) for (var j = 0; j < g.length; j++) res[i + j] ^= mul(g[j], c); }
      return res.slice(data.length);
    }
    function utf8(s) { var out = [], e = unescape(encodeURIComponent(s)); for (var i = 0; i < e.length; i++) out.push(e.charCodeAt(i)); return out; }
    function capacity(v) { var e = EC_M[v], n = 0; for (var k = 1; k < e.length; k++) n += e[k][0] * e[k][1]; return n; }
    function make(text) {
      var bytes = utf8(text), v = 1;
      for (; v <= 10; v++) { if (4 + (v < 10 ? 8 : 16) + bytes.length * 8 <= capacity(v) * 8) break; }
      if (v > 10) throw new Error("QR: 長すぎる");
      // データのビット列
      var bits = [];
      function put(val, len) { for (var i = len - 1; i >= 0; i--) bits.push((val >>> i) & 1); }
      put(4, 4); put(bytes.length, v < 10 ? 8 : 16);
      bytes.forEach(function (b) { put(b, 8); });
      var cap = capacity(v) * 8;
      for (var t = 0; t < 4 && bits.length < cap; t++) bits.push(0);
      while (bits.length % 8) bits.push(0);
      var data = [];
      for (var i = 0; i < bits.length; i += 8) { var b = 0; for (var j = 0; j < 8; j++) b = (b << 1) | bits[i + j]; data.push(b); }
      for (var p = 0; data.length < capacity(v); p++) data.push(p % 2 ? 0x11 : 0xEC);
      // ブロックに分けて誤り訂正をつけ、互い違いに並べる
      var e = EC_M[v], blocks = [], ecs = [], pos = 0;
      for (var gi = 1; gi < e.length; gi++) for (var bi = 0; bi < e[gi][0]; bi++) { var blk = data.slice(pos, pos + e[gi][1]); pos += e[gi][1]; blocks.push(blk); ecs.push(rsEc(blk, e[0])); }
      var words = [], maxLen = 0;
      blocks.forEach(function (b) { maxLen = Math.max(maxLen, b.length); });
      for (var k = 0; k < maxLen; k++) blocks.forEach(function (b) { if (k < b.length) words.push(b[k]); });
      for (var k2 = 0; k2 < e[0]; k2++) ecs.forEach(function (c) { words.push(c[k2]); });
      // 模様
      var size = v * 4 + 17, m = [], fn = [];
      for (var y = 0; y < size; y++) { m.push(new Array(size).fill(0)); fn.push(new Array(size).fill(false)); }
      function set(x, y, val) { m[y][x] = val ? 1 : 0; fn[y][x] = true; }
      function finder(cx, cy) {
        for (var dy = -4; dy <= 4; dy++) for (var dx = -4; dx <= 4; dx++) {
          var x = cx + dx, y = cy + dy; if (x < 0 || y < 0 || x >= size || y >= size) continue;
          var d = Math.max(Math.abs(dx), Math.abs(dy)); set(x, y, d !== 2 && d !== 4);
        }
      }
      finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
      for (var i2 = 8; i2 < size - 8; i2++) { set(i2, 6, i2 % 2 === 0); set(6, i2, i2 % 2 === 0); }
      var al = ALIGN[v];
      for (var a = 0; a < al.length; a++) for (var b2 = 0; b2 < al.length; b2++) {
        if ((a === 0 && b2 === 0) || (a === 0 && b2 === al.length - 1) || (a === al.length - 1 && b2 === 0)) continue;
        for (var dy2 = -2; dy2 <= 2; dy2++) for (var dx2 = -2; dx2 <= 2; dx2++) set(al[a] + dx2, al[b2] + dy2, Math.max(Math.abs(dx2), Math.abs(dy2)) !== 1);
      }
      // 形式情報・型番情報の場所を先にとっておく
      for (var f = 0; f < 9; f++) { fn[8][f] = true; fn[f][8] = true; }
      for (var f2 = 0; f2 < 8; f2++) { fn[8][size - 1 - f2] = true; fn[size - 1 - f2][8] = true; }
      set(8, size - 8, 1); // 黒いモジュール
      if (v >= 7) for (var r = 0; r < 6; r++) for (var c = 0; c < 3; c++) { fn[size - 11 + c][r] = true; fn[r][size - 11 + c] = true; }
      // データを置く
      var bitIdx = 0, total = words.length * 8;
      for (var right = size - 1; right >= 1; right -= 2) {
        if (right === 6) right = 5;
        for (var vert = 0; vert < size; vert++) for (var jj = 0; jj < 2; jj++) {
          var x2 = right - jj, upward = ((right + 1) & 2) === 0, y2 = upward ? size - 1 - vert : vert;
          if (fn[y2][x2]) continue;
          if (bitIdx < total) m[y2][x2] = (words[bitIdx >>> 3] >>> (7 - (bitIdx & 7))) & 1;
          bitIdx++;
        }
      }
      var MASKS = [
        function (x, y) { return (x + y) % 2 === 0; }, function (x, y) { return y % 2 === 0; },
        function (x, y) { return x % 3 === 0; }, function (x, y) { return (x + y) % 3 === 0; },
        function (x, y) { return (Math.floor(y / 2) + Math.floor(x / 3)) % 2 === 0; },
        function (x, y) { return (x * y) % 2 + (x * y) % 3 === 0; },
        function (x, y) { return ((x * y) % 2 + (x * y) % 3) % 2 === 0; },
        function (x, y) { return ((x + y) % 2 + (x * y) % 3) % 2 === 0; }];
      function withMask(mi) {
        var mm = m.map(function (row) { return row.slice(); });
        for (var y = 0; y < size; y++) for (var x = 0; x < size; x++) if (!fn[y][x] && MASKS[mi](x, y)) mm[y][x] ^= 1;
        // 形式情報（誤り訂正M=00）
        var d = (0 << 3) | mi, rem = d;
        for (var i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
        var fb = ((d << 10) | rem) ^ 0x5412;
        function bit(i) { return (fb >>> i) & 1; }
        for (var i3 = 0; i3 <= 5; i3++) mm[i3][8] = bit(i3);
        mm[7][8] = bit(6); mm[8][8] = bit(7); mm[8][7] = bit(8);
        for (var i4 = 9; i4 < 15; i4++) mm[8][14 - i4] = bit(i4);
        for (var i5 = 0; i5 < 8; i5++) mm[8][size - 1 - i5] = bit(i5);
        for (var i6 = 8; i6 < 15; i6++) mm[size - 15 + i6][8] = bit(i6);
        mm[size - 8][8] = 1;
        if (v >= 7) {
          var rv = v; for (var k = 0; k < 12; k++) rv = (rv << 1) ^ ((rv >>> 11) * 0x1F25);
          var vb = (v << 12) | rv;
          for (var q = 0; q < 18; q++) { var bb = (vb >>> q) & 1, aa = size - 11 + (q % 3), cc = Math.floor(q / 3); mm[cc][aa] = bb; mm[aa][cc] = bb; }
        }
        return mm;
      }
      function penalty(mm) {
        var s = 0, n = size;
        for (var y = 0; y < n; y++) { var run = 1; for (var x = 1; x < n; x++) { if (mm[y][x] === mm[y][x - 1]) { run++; if (run === 5) s += 3; else if (run > 5) s++; } else run = 1; } }
        for (var x3 = 0; x3 < n; x3++) { var run2 = 1; for (var y3 = 1; y3 < n; y3++) { if (mm[y3][x3] === mm[y3 - 1][x3]) { run2++; if (run2 === 5) s += 3; else if (run2 > 5) s++; } else run2 = 1; } }
        for (var y4 = 0; y4 < n - 1; y4++) for (var x4 = 0; x4 < n - 1; x4++) { var c0 = mm[y4][x4]; if (c0 === mm[y4][x4 + 1] && c0 === mm[y4 + 1][x4] && c0 === mm[y4 + 1][x4 + 1]) s += 3; }
        var dark = 0; for (var y5 = 0; y5 < n; y5++) for (var x5 = 0; x5 < n; x5++) dark += mm[y5][x5];
        s += Math.floor(Math.abs(dark * 20 - n * n * 10) / (n * n)) * 10;
        return s;
      }
      var best = null, bestS = Infinity;
      for (var mi = 0; mi < 8; mi++) { var mm = withMask(mi), sc = penalty(mm); if (sc < bestS) { bestS = sc; best = mm; } }
      return best;
    }
    // canvas に描く（まわりに白い余白4マス）
    function draw(canvas, text, px) {
      var mtx = make(text), n = mtx.length, q = 4, cells = n + q * 2;
      px = px || Math.max(4, Math.floor(480 / cells));
      canvas.width = canvas.height = cells * px;
      var c = canvas.getContext("2d");
      c.fillStyle = "#fff"; c.fillRect(0, 0, canvas.width, canvas.height);
      c.fillStyle = "#000";
      for (var y = 0; y < n; y++) for (var x = 0; x < n; x++) if (mtx[y][x]) c.fillRect((x + q) * px, (y + q) * px, px, px);
      return mtx;
    }
    return { make: make, draw: draw };
  })();

  // ---- QRコードのページ（?qr=1）: 配信画面に出して、スマホのカメラで読んでもらう ----
  if (new URLSearchParams(location.search).get("qr") === "1") {
    ["android", "namePanel", "setup", "call", "webNote"].forEach(function (id) { var e = $(id); if (e) e.classList.add("hidden"); });
    var joinUrl = location.origin + "/";
    QR.draw($("qrCanvas"), joinUrl, 12);
    $("qrUrl").textContent = joinUrl;
    try { $("qrSave").href = $("qrCanvas").toDataURL("image/png"); } catch (e) {}
    $("qrPage").classList.remove("hidden");
    androidPage = false;
    window.__qrPage = true;
  }

  // ---- ランダムな名前（かっこいい名前・そこらへんにいそうな名前） ----
  var NAME_COOL = ["カイト", "レン", "ソラ", "シン", "リク", "ハヤテ", "クロ", "ジン", "ライト", "ゼロ", "ノア", "ルカ", "アオ", "ヒカル", "ユウキ", "ショウ", "レイ", "ミナト", "トワ", "イブキ", "セナ", "ルイ", "カナタ", "アキラ"];
  var NAME_COMMON = ["はると", "そうた", "ゆうま", "ゆいと", "りく", "たける", "こうき", "ひなた", "あおい", "ゆな", "さくら", "りん", "めい", "ひより", "みお", "ことね", "ゆうと", "かいと", "けんた", "しょう", "まな", "なつき", "あやか", "そら"];
  var NAME_PRE = ["黒猫の", "疾風の", "蒼き", "夜の", "伝説の", "無敵の", "はぐれ", "眠れる", "闇の", "炎の", "最強の", "迷子の"];
  function randomName() {
    function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
    var r = Math.random();
    if (r < 0.3) return pick(NAME_COOL);
    if (r < 0.55) return pick(NAME_COMMON);
    if (r < 0.8) return pick(NAME_PRE) + pick(NAME_COOL);
    return pick(Math.random() < 0.5 ? NAME_COOL : NAME_COMMON) + (10 + Math.floor(Math.random() * 90));
  }
  $("randomName").onclick = function () { $("displayName").value = randomName(); updateGuide(); };

  // ---- 初めての人に、やり方を1つずつ教える吹き出し ----
  var guideStep = "";
  function guideOff() { try { return localStorage.getItem("guideOff") === "1"; } catch (e) { return false; } }
  function vis(id) { var e = $(id); return e && !e.classList.contains("hidden") && e.offsetParent !== null; }
  function updateGuide() {
    var g = $("guide"), target = null, text = "";
    if (running && !guideOff()) { try { localStorage.setItem("guideOff", "1"); } catch (e) {} }
    if (!running && !guideOff() && !window.__qrPage) {
      if (vis("android")) { target = "useBrowser"; text = "① まず「🌐 ブラウザ」を押してね（アプリが入ってる人は「アプリ」でもOK）"; }
      else if (vis("namePanel")) {
        if (!$("displayName").value.trim()) { target = "displayName"; text = "② ここに名前を入れてね。適当でOK！思いつかなければ下の「🎲 ランダム」"; }
        else { target = "setName"; text = "③ 「決定」を押してね"; }
      } else if (vis("setup")) {
        if (!vis("joinForm")) { target = "chLobby"; text = "④ ここ「近接VC待機所」をタップ"; }
        else if (!$("mcName").value.trim()) { target = "mcName"; text = "⑤ マイクラで表示されてる自分の名前を入れてね（わからなければ空でもOK → 次は「入る」）"; }
        else { target = "join"; text = "⑥ 「入る」を押したら通話に入れるよ！マイクの許可が出たら「許可」"; }
      }
    }
    if (!target) { g.classList.add("hidden"); guideStep = ""; return; }
    var r = $(target).getBoundingClientRect();
    $("guideText").textContent = text;
    g.classList.remove("hidden");
    var left = Math.max(8, Math.min(r.left + window.scrollX, window.innerWidth - g.offsetWidth - 8));
    g.style.left = left + "px";
    // 吹き出しは押すところの上に出す（下のボタンを隠さない）
    g.style.top = Math.max(4, r.top + window.scrollY - g.offsetHeight - 34) + "px";
    $("guideArrow").style.left = Math.max(6, Math.min(r.left + window.scrollX - left + 10, g.offsetWidth - 34)) + "px";
    if (guideStep !== target) {
      guideStep = target;
      try { $(target).scrollIntoView({ block: "center", behavior: "smooth" }); } catch (e) {}
    }
  }
  setInterval(updateGuide, 300);
  ["displayName", "mcName"].forEach(function (id) { $(id).addEventListener("input", updateGuide); });
  $("guideClose").onclick = function () { try { localStorage.setItem("guideOff", "1"); } catch (e) {} updateGuide(); };
  $("guideOn").onclick = function () { try { localStorage.removeItem("guideOff"); } catch (e) {} guideStep = ""; updateGuide(); };

  function showStart() {
    if (window.__qrPage) return;
    if (androidPage) { $("namePanel").classList.add("hidden"); $("setup").classList.add("hidden"); return; }
    var n = savedName();
    $("namePanel").classList.toggle("hidden", !!n);
    $("setup").classList.toggle("hidden", !n);
    $("myNameLabel").textContent = "👤 " + n + "　（タップで名前を変える）";
    refreshLobbyOwner();
  }
  $("setName").onclick = function () {
    var n = $("displayName").value.trim();
    if (!n) { setStatus("名前を入れてね"); return; }
    try { localStorage.setItem("displayName", n); } catch (e) {}
    setStatus(""); showStart();
  };
  $("myNameLabel").onclick = function () {
    $("displayName").value = savedName();
    try { localStorage.removeItem("displayName"); } catch (e) {}
    showStart();
  };
  showStart();
  $("chLobby").onclick = function () { $("joinForm").classList.toggle("hidden"); $("mcName").focus(); };
  // 入る前の画面: 待機所と部屋1〜20に、今いる人の名前を出す
  function renderPreview(people) {
    people = people || [];
    function line(p) { var d = document.createElement("div"); d.className = "mem"; d.textContent = "⚫ " + p.name + (p.host ? " 👑" : ""); return d; }
    var lb = $("lobbyPeople"); lb.textContent = "";
    people.filter(function (p) { return !p.slot; }).forEach(function (p) { lb.appendChild(line(p)); });
    var box = $("roomsPreview"); box.textContent = "";
    for (var r = 1; r <= 20; r++) {
      var d = document.createElement("div"); d.className = "ch"; d.textContent = "🔊  🎧▮部屋" + r; box.appendChild(d);
      people.filter(function (p) { return p.slot === r; }).forEach(function (p) { box.appendChild(line(p)); });
    }
  }
  renderPreview([]);
  $("join").onclick = function () { join().catch(function (e) { setStatus("開始できませんでした: " + e.message); stop(); }); };
  $("leave").onclick = function () { stop(); setStatus("退出しました"); };
  // 聞こえない時: テストの音を鳴らして、だめならスピーカーモード（エコー消しをやめて大きく出す）に切り替える
  function beep() {
    if (!ctx || !master) return;
    wakeAudio();
    var o = ctx.createOscillator(), g = ctx.createGain();
    o.frequency.value = 880; g.gain.value = 0.25;
    o.connect(g); g.connect(master);
    o.start(); o.stop(ctx.currentTime + 0.35);
  }
  async function useSpeakerMode() {
    if (!ctx || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return;
    try {
      var ns = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: true, autoGainControl: true } });
      try { if (micSrc) micSrc.disconnect(); } catch (e) {}
      try { if (stream) stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
      stream = ns; speakerMode = true;
      if (capNode) { micSrc = ctx.createMediaStreamSource(ns); micSrc.connect(capNode); }
      wakeAudio();
      setStatus("🔊 スピーカーモードにしたよ。相手に自分の声が返る時はイヤホンを使ってね");
    } catch (e) { setStatus("切り替えられなかった（" + (e && e.name) + "）"); }
  }
  $("hearHelp").onclick = function () {
    beep();
    setTimeout(function () {
      if (confirm("今「ピッ」て音、聞こえた？\\n\\n聞こえた → OK\\n聞こえない・小さい → キャンセル（スピーカーモードにする）")) {
        setStatus("音は出てるよ。相手のまわりが緑に光ってるのに聞こえない時は、音量ボタンを上げてね（iPhone はマナーモードも解除）。緑に光らない時は、相手がマイクラで6ブロックより遠いか、待機所と部屋で分かれてるよ");
      } else {
        useSpeakerMode().then(function () { setTimeout(beep, 300); });
      }
    }, 600);
  };
  $("mute").onclick = function () {
    if (!stream) { setStatus("🎧 聞くだけで参加中。" + micProblem); return; }
    muted = !muted; render();
  };
  var showList = false;
  $("collapse").onclick = $("roomLabel").onclick = function () { showList = !showList; render(); };
  // シェア = 招待のリンクをコピーするだけ（LINE や Discord に貼り付けて送る）
  function shareApp() {
    var text = "むいいむ通話に来てね！\\n" + location.origin + "/";
    var done = function () { setStatus("📋 リンクをコピーしたよ！LINE や Discord に貼り付けて送ってね"); alertCopied(); };
    var fallback = function () {
      try {
        var t = document.createElement("textarea"); t.value = text; t.style.position = "fixed"; t.style.opacity = "0";
        document.body.appendChild(t); t.select(); document.execCommand("copy"); document.body.removeChild(t); done();
      } catch (e) { window.prompt("このリンクをコピーしてね", text); }
    };
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, fallback);
      else fallback();
    } catch (e) { fallback(); }
  }
  function alertCopied() {
    var t = $("copied"); if (!t) return;
    t.classList.remove("hidden"); clearTimeout(alertCopied.timer);
    alertCopied.timer = setTimeout(function () { t.classList.add("hidden"); }, 2500);
  }
  $("shareTop").onclick = $("invite").onclick = shareApp;
  $("optout").onclick = function () {
    optOut = !optOut;
    if (ws && ws.readyState === 1) ws.send(JSON.stringify({ t: "optout", on: optOut }));
    render();
  };
  $("deafen").onclick = function () {
    deafened = !deafened;
    for (var id in speakers) speakers[id].next = 0;
    render();
  };

  async function join() {
    myName = savedName().trim();
    myMc = $("mcName").value.trim();
    room = ($("room").value.trim().toUpperCase()) || "MUIIMU";
    if (!myName) { showStart(); setStatus("先に名前を決めてね"); return; }
    if (!/^[A-Z0-9]{6}$/.test(room)) room = "MUIIMU";
    try { localStorage.setItem("mc", myMc); localStorage.setItem("room", room); } catch (e) {}
    // マイクラの名前が空なら呼び名で探す（サーバーと同じ）
    if (!myMc) myMc = myName.slice(0, 40);

    try { if (navigator.audioSession) navigator.audioSession.type = "play-and-record"; } catch (e) {}
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) throw new Error("このブラウザは音が出せないみたい。Chrome か Safari で開いてね");
    ctx = new AC();
    // 読み上げを使えるようにしておく（スマホはボタンを押したときにしか準備できない）
    try { if (window.speechSynthesis) { var u0 = new SpeechSynthesisUtterance(" "); u0.volume = 0; speechSynthesis.speak(u0); } } catch (e) {}
    // 聞こえる声はぜんぶ master に集めて出す
    master = ctx.createGain(); master.gain.value = 1;
    // スマホのブラウザは通話中に音が小さくなりやすいので、割れないように整えてから大きめに出す
    var comp = ctx.createDynamicsCompressor();
    try { comp.threshold.value = -12; comp.knee.value = 6; comp.ratio.value = 4; comp.attack.value = 0.003; comp.release.value = 0.15; } catch (e) {}
    var boost = ctx.createGain(); boost.gain.value = 1.8;
    master.connect(comp); comp.connect(boost);
    var outNode = boost;
    // iPhone はマナーモード（消音スイッチ）だとブラウザの音が消えるので、<audio> を通して鳴らす
    outEl = $("voiceOut");
    var routed = false;
    if (isIOS && ctx.createMediaStreamDestination && outEl) {
      try {
        var dest = ctx.createMediaStreamDestination();
        outNode.connect(dest);
        outEl.srcObject = dest.stream; outEl.muted = false; outEl.volume = 1;
        outEl.play().catch(function () {});
        routed = true;
      } catch (e) { routed = false; }
    }
    if (!routed) outNode.connect(ctx.destination);
    try { await ctx.resume(); } catch (e) {}
    // マイク: だめでも「聞くだけ」で通話に入れるようにする（入れないバグ対策）
    micProblem = "";
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      micProblem = "このブラウザ（Discord や LINE の中のブラウザなど）はマイクが使えないよ。右上の︙から「Chromeで開く」か Safari で開いてね";
    } else {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }
        });
      } catch (e1) {
        try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); }
        catch (e2) {
          micProblem = (e2 && e2.name === "NotAllowedError")
            ? "マイクが許可されてないよ。ブラウザの設定でこのページのマイクを「許可」にしてね"
            : "マイクが使えなかった（" + ((e2 && e2.name) || "エラー") + "）";
        }
      }
    }
    wakeAudio();
    if (stream) {
      var src = ctx.createMediaStreamSource(stream);
      micSrc = src;
      var sink = ctx.createGain(); sink.gain.value = 0;
      var worklet = false;
      if (ctx.audioWorklet && window.AudioWorkletNode) {
        try {
          var code = "class C extends AudioWorkletProcessor{process(i){var c=i[0]&&i[0][0];if(c)this.port.postMessage(c.slice(0));return true}}registerProcessor('cap',C);";
          await ctx.audioWorklet.addModule(URL.createObjectURL(new Blob([code], { type: "application/javascript" })));
          var node = new AudioWorkletNode(ctx, "cap");
          src.connect(node); node.connect(sink); capNode = node;
          node.port.onmessage = function (e) { onMic(e.data); };
          worklet = true;
        } catch (e) { worklet = false; }
      }
      if (!worklet) {
        // 古いブラウザ用
        var sp = ctx.createScriptProcessor(2048, 1, 1);
        sp.onaudioprocess = function (e) { if (ctx) onMic(new Float32Array(e.inputBuffer.getChannelData(0))); };
        src.connect(sp); sp.connect(sink); capNode = sp;
      }
      sink.connect(ctx.destination);
    }

    running = true; retry = 0;
    $("setup").classList.add("hidden");
    $("call").classList.remove("hidden");
    try { keepAwake(); } catch (e) {}
    connect();
    if (!stream) { muted = true; setStatus("🎧 聞くだけで参加中。" + micProblem); }
    render();
  }

  function onMic(chunk) {
    var ratio = ctx.sampleRate / RATE;
    for (var i = 0; i < chunk.length; i++) inBuf.push(chunk[i]);
    while (rpos + 1 < inBuf.length) {
      var k = Math.floor(rpos), t = rpos - k;
      var v = inBuf[k] * (1 - t) + inBuf[k + 1] * t;
      frame[fpos++] = Math.max(-32768, Math.min(32767, Math.round(v * 32767)));
      rpos += ratio;
      if (fpos === FRAME) { fpos = 0; onFrame(); }
    }
    var drop = Math.floor(rpos);
    if (drop > 0) { inBuf = inBuf.slice(drop); rpos -= drop; }
  }

  function onFrame() {
    var sum = 0;
    for (var i = 0; i < FRAME; i++) sum += frame[i] * frame[i];
    var rms = Math.sqrt(sum / FRAME);
    if (rms > VAD_LEVEL) hang = VAD_HANG; else if (hang > 0) hang--;
    selfTalking = !muted && !deafened && hang > 0;
    if (!selfTalking || optOut || !ws || ws.readyState !== 1) return;
    var out = new Uint8Array(FRAME);
    for (var j = 0; j < FRAME; j++) out[j] = enc(frame[j]);
    ws.send(out);
  }

  function connect() {
    if (!running) return;
    var url = location.origin.replace(/^http/, "ws") + "/ws?room=" + encodeURIComponent(room) +
      "&name=" + encodeURIComponent(myName) + "&mc=" + encodeURIComponent(myMc) + "&dev=" + encodeURIComponent(deviceId());
    var s = new WebSocket(url);
    s.binaryType = "arraybuffer";
    ws = s;
    setStatus("接続中…");
    s.onopen = function () { if (ws === s) { retry = 0; setStatus(stream ? "通話中" : ("🎧 聞くだけで参加中。" + micProblem)); } };
    s.onmessage = function (e) {
      if (ws !== s) return;
      if (typeof e.data === "string") onText(e.data);
      else onAudio(new Uint8Array(e.data));
    };
    s.onclose = function (e) {
      if (ws !== s) return;
      if (e.code === 4004) { setStatus("運営がまだ近接VC待機所を開いてないよ（開くまで待ってね）"); stop(); return; }
      if (e.code === 4009) { setStatus("別の端末から同じ名前で入りました"); stop(); return; }
      if (e.code === 4010) { setStatus("通話が満員です"); stop(); return; }
      if (!running) return;
      retry++;
      setStatus("再接続中…");
      setTimeout(connect, Math.min(10000, 1000 * retry));
    };
  }

  function onText(text) {
    var m; try { m = JSON.parse(text); } catch (e) { return; }
    if (m.t === "hello") { isOwner = !!m.host; render(); }
    else if (m.t === "owner") {
      isOwner = !!m.host;
      setStatus(isOwner ? "あなたがオーナーになったよ 👑" : "オーナーが「" + (m.ownerName || "") + "」に変わったよ");
      render();
    }
    else if (m.t === "members") {
      members = {};
      mySlot = 0;
      (m.list || []).forEach(function (x) {
        members[x.id] = x;
        if (x.name === myName) { mySlot = x.slot || 0; optOut = !!x.out; }
      });
      if (m.mc === false) mcOn = false;
      for (var id in speakers) if (!members[id]) delete speakers[id];
      recompute();
    } else if (m.t === "pos") {
      positions = m.p || {}; mcOn = true; lastPos = Date.now(); recompute();
    } else if (m.t === "mc") {
      mcOn = !!m.on; if (!mcOn) positions = {}; recompute();
    } else if (m.t === "chat") {
      speakChat(m);
    }
  }

  function speaker(id) {
    var s = speakers[id];
    if (s) return s;
    var g = ctx.createGain();
    var p = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
    var out = master || ctx.destination;
    if (p) { g.connect(p); p.connect(out); } else g.connect(out);
    s = speakers[id] = { gain: g, pan: p, next: 0, last: 0, g: 1 };
    return s;
  }

  function onAudio(u8) {
    if (u8.length < 2 || !ctx || deafened) return;
    // 電話や別のアプリで止められた音を戻す
    if (ctx.state !== "running") { try { ctx.resume(); } catch (e) {} }
    var id = u8[0], n = u8.length - 1, sr = ctx.sampleRate;
    var outLen = Math.round(n * sr / RATE);
    var buf = ctx.createBuffer(1, outLen, sr);
    var d = buf.getChannelData(0), step = RATE / sr;
    for (var i = 0; i < outLen; i++) {
      var x = i * step, k = Math.floor(x), t = x - k;
      var a = DEC[u8[1 + Math.min(k, n - 1)]], b = DEC[u8[1 + Math.min(k + 1, n - 1)]];
      d[i] = a * (1 - t) + b * t;
    }
    var s = speaker(id);
    var now = ctx.currentTime;
    if (s.next < now + 0.02 || s.next > now + 0.5) s.next = now + 0.1;
    var node = ctx.createBufferSource();
    node.buffer = buf;
    node.connect(s.gain);
    node.start(s.next);
    s.next += buf.duration;
    s.last = Date.now();
  }

  // マイクラのチャットを読み上げる（6ブロックくらいまで。近いほど大きく）
  // ---- 人ごとの音量（アイコン長押し）。0〜100%、ミュート。名前ごとに覚えておく ----
  function volOf(name) {
    try {
      if (localStorage.getItem("mute_" + name) === "1") return 0;
      var v = localStorage.getItem("vol_" + name);
      return v === null ? 1 : Math.max(0, Math.min(100, Number(v))) / 100;
    } catch (e) { return 1; }
  }
  var volWho = null;
  function openVolume(name) {
    volWho = name;
    $("volTitle").textContent = name + " の音量";
    var v = 100; try { var x = localStorage.getItem("vol_" + name); if (x !== null) v = Number(x); } catch (e) {}
    $("volRange").value = v;
    showVolume();
    $("volPick").classList.remove("hidden");
  }
  function showVolume() {
    var muted = false; try { muted = localStorage.getItem("mute_" + volWho) === "1"; } catch (e) {}
    $("volLabel").textContent = muted ? "🔇 ミュート中" : ("🔊 音量: " + $("volRange").value + "%");
    $("volMute").textContent = muted ? "ミュートをやめる" : "🔇 ミュートする";
  }
  function saveVolume() { if (ctx) recompute(); render(); showVolume(); }

  function findPos(name) {
    if (!name) return undefined;
    if (positions[name]) return positions[name];
    var low = name.toLowerCase();
    for (var k in positions) if (k.toLowerCase() === low) return positions[k];
    return undefined;
  }
  function speakChat(m) {
    if (!window.speechSynthesis || !window.SpeechSynthesisUtterance || !ctx || deafened || optOut || !mcOn) return;
    var me = findPos(myMc), from = m.p || findPos(m.mc);
    var r = compute(me, from);
    if (!(r[0] > 0)) return;
    // 読み上げは声より聞き取りにくいので、届く範囲（6ブロックくらい）なら はっきり聞こえる大きさにする
    var vol = Math.min(1, 0.55 + 0.45 * r[0]);
    // 長押しでミュート・音量を下げた人のチャットは、その音量で
    for (var id in members) { var x = members[id]; if (x.mc && x.mc.toLowerCase() === String(m.mc || "").toLowerCase()) { vol *= volOf(x.name); break; } }
    if (vol < 0.02) return;
    try {
      var u = new SpeechSynthesisUtterance(String(m.text || "").slice(0, 120));
      u.lang = "ja-JP"; u.volume = Math.min(1, vol); u.rate = 1.1;
      speechSynthesis.speak(u);
    } catch (e) {}
  }

  function compute(me, o) {
    if (!me || !o || me.d !== o.d) return [0, 0];
    var dx = o.x - me.x, dy = o.y - me.y, dz = o.z - me.z;
    var dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
    var g = gainAt(dist);
    var yaw = (me.r || 0) * Math.PI / 180;
    var rx = -Math.cos(yaw), rz = -Math.sin(yaw);
    var len = Math.sqrt(dx * dx + dz * dz);
    var pan = len < 0.5 ? 0 : ((dx * rx + dz * rz) / len) * 0.8;
    return [g, pan, dist];
  }

  function recompute() {
    if (!ctx) return;
    var me = myMc ? positions[myMc] : undefined;
    for (var id in members) {
      var mem = members[id];
      if (mem.name === myName) continue;
      // サーバーと同じルール
      var other = mem.mc ? positions[mem.mc] : undefined;
      var r;
      if (optOut || mem.out) r = [0, 0];
      else if (!mcOn) r = [1, 0];                                   // /connect 前はふつうの通話
      else if (mySlot > 0 && mem.slot > 0) r = compute(me, other);  // ワールドの中どうしは距離で
      else if (!me && !other && !mem.slot) r = [1, 0];              // ワールドの外どうしはふつうの通話
      else r = [0, 0];
      var full = compute(me, other);
      var s = speaker(id);
      s.g = r[0]; s.dist = full.length > 2 ? full[2] : null;
      // 人ごとの音量（アイコン長押しで決めたもの）をかける
      s.gain.gain.setTargetAtTime(r[0] * volOf(mem.name), ctx.currentTime, 0.05);
      if (s.pan) s.pan.pan.setTargetAtTime(r[1], ctx.currentTime, 0.05);
    }
    render();
  }

  function render() {
    updateMemberCount();
    var roomName = (mcOn && mySlot > 0 && !optOut) ? ("部屋" + mySlot) : "近接VC待機所";
    $("roomLabel").textContent = (isOwner ? "👑 " : "") + roomName + "  ›";
    $("giveOwner").classList.toggle("hidden", !isOwner);
    $("mute").innerHTML = (muted || deafened) ? ICON_MICOFF : ICON_MIC;
    $("deafen").innerHTML = deafened ? ICON_HEADOFF : ICON_HEAD;
    var mc = $("mc");
    if (!mcOn) { mc.textContent = "⚪ 近接VC待機所にいるよ（ふつうの通話）。運営がマイクラで準備すると、ワールドに入った人から部屋に移動するよ"; mc.className = "mc"; }
    else if (optOut) { mc.textContent = "⏸ 通話を抜けてるよ（「通話に戻る」で戻れる）"; mc.className = "mc"; }
    else if (mySlot > 0) { mc.textContent = "🟢 部屋" + mySlot + " にいるよ：近くの人ほど大きく聞こえる"; mc.className = "mc on"; }
    else { mc.textContent = "🟡 近接VC待機所にいるよ：待機所の人どうしでふつうに話せる。マイクラのワールドに入ると、空いてる部屋に自動で移動するよ（名前がマイクラと同じか確認してね）"; mc.className = "mc"; }
    $("optout").classList.toggle("hidden", !mcOn);
    $("optout").textContent = optOut ? "通話に戻る" : "通話を抜ける";
    // Discord みたいなボイスチャンネル一覧（近接VC待機所 ＋ 部屋1〜20）
    var box = $("members");
    box.textContent = "";
    var byRoom = {}, myRoom = 0, now = Date.now();
    Object.keys(members).forEach(function (id) {
      var x = members[id];
      var r = (mcOn && x.slot >= 1 && x.slot <= 20) ? x.slot : 0;
      (byRoom[r] = byRoom[r] || []).push(id);
      if (x.name === myName) myRoom = r;
    });
    for (var r = 0; r <= 20; r++) {
      var people = byRoom[r] || [];
      var head = document.createElement("div");
      head.className = "ch" + (people.length ? " has" : "") + (r === myRoom ? " mine" : "");
      head.textContent = "🔊  " + (r === 0 ? "🎤▮近接VC待機所" : "🎧▮部屋" + r);
      if (r > 0 && people.length) {
        var c = document.createElement("span"); c.className = "cnt"; c.textContent = "1/1"; head.appendChild(c);
      }
      box.appendChild(head);
      people.forEach(function (id) {
        var mem = members[id], me = mem.name === myName, s = speakers[id];
        var talking = me ? selfTalking : (s && now - s.last < 350 && s.g > 0.01);
        var line = (talking ? "🟢 " : "⚫ ") + mem.name + (mem.host ? " 👑" : "");
        if (me) line += "（自分）" + (deafened ? "  🎧✕" : muted ? "  🎤✕" : "");
        else if (mem.out) line += "  （抜けてる）";
        var div = document.createElement("div");
        div.className = "mem" + (talking ? " talk" : "");
        div.textContent = line;
        box.appendChild(div);
      });
    }
      // 上のバーの下の短い説明
    $("sub").textContent = mc.textContent.split("。")[0];
    // ⌄ で「タイル」と「チャンネル一覧」を切り替え
    $("listView").classList.toggle("hidden", !showList);
    $("tiles").classList.toggle("hidden", showList);
    renderTiles(now);
  }

  var AV_COLORS = ["#5865F2", "#EB459E", "#3BA55C", "#FAA61A", "#ED4245", "#9B59B6"];
  function hashName(n) { var h = 0; for (var i = 0; i < n.length; i++) h = (h * 31 + n.charCodeAt(i)) | 0; return Math.abs(h); }
  // 真ん中のタイル: 自分と、今声が聞こえる相手
  var pressingTile = false; // 長押し中はタイルを作り直さない
  function renderTiles(now) {
    if (pressingTile) return;
    var box = $("tiles"); box.textContent = "";
    var people = [];
    Object.keys(members).forEach(function (id) {
      var x = members[id], s = speakers[id];
      if (x.name === myName) people.unshift(id);
      else people.push(id); // 通話にいる人をずっと同じ順番で出す（出たり消えたりしない）
    });
    if (!people.length) { var e = document.createElement("div"); e.className = "empty"; e.textContent = (mcOn && !(mySlot > 0) && !optOut)
      ? "ワールドの中の人の声は、あなたもマイクラのワールドに入って部屋に移動すると聞こえるよ（「マイクラの名前」がゲームの名前と同じか確認してね）"
      : "まだ誰の声も聞こえないよ"; box.appendChild(e); return; }
    people.forEach(function (id) {
      var x = members[id], me = x.name === myName, s = speakers[id];
      var talking = me ? selfTalking : (s && now - s.last < 350 && s.g > 0.01);
      var t = document.createElement("div");
      t.className = "tile" + (people.length === 1 ? " one" : people.length === 2 ? " wide" : "") + (talking ? " talk" : "");
      var av = document.createElement("div"); av.className = "av";
      av.style.background = AV_COLORS[hashName(x.name) % AV_COLORS.length];
      av.textContent = x.name.slice(0, 1).toUpperCase();
      var chip = document.createElement("div"); chip.className = "chip";
      var label = (x.host ? "👑 " : "") + x.name;
      if (me && deafened) label += "  🎧✕"; else if (me && muted) label += "  🎤✕";
      if (!me && volOf(x.name) === 0) label += "  🔇";
      else if (!me && volOf(x.name) < 1) label += "  🔉";
      chip.textContent = label;
      t.appendChild(av); t.appendChild(chip); box.appendChild(t);
      // アイコンを長押し → その人の音量・ミュート
      if (!me) (function (nm, el) {
        var timer = null;
        var startPress = function () { pressingTile = true; timer = setTimeout(function () { timer = null; pressingTile = false; openVolume(nm); }, 500); };
        var cancel = function () { pressingTile = false; if (timer) { clearTimeout(timer); timer = null; } };
        el.addEventListener("touchstart", startPress, { passive: true });
        el.addEventListener("touchend", cancel); el.addEventListener("touchmove", cancel); el.addEventListener("touchcancel", cancel);
        el.addEventListener("mousedown", startPress); el.addEventListener("mouseup", cancel); el.addEventListener("mouseleave", cancel);
        el.addEventListener("contextmenu", function (e) { e.preventDefault(); cancel(); openVolume(nm); });
      })(x.name, t);
    });
  }

  setInterval(function () {
    if (!running) return;
    // オーナーが落ちて位置が止まっても、みんなそのまま（元の通話に戻さない）
    render();
  }, 250);

  async function keepAwake() {
    try { if (navigator.wakeLock) wakeLock = await navigator.wakeLock.request("screen"); } catch (e) {}
  }
  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible" && running) {
      keepAwake();
      wakeAudio();
    }
  });
  // 画面をどこか触ったら音を起こす（スマホのブラウザは触らないと音が出ないことがある）
  function wakeAudio() {
    try { if (ctx && ctx.state !== "running") ctx.resume(); } catch (e) {}
    try { if (outEl && outEl.srcObject && outEl.paused) outEl.play().catch(function () {}); } catch (e) {}
  }
  document.addEventListener("touchend", function () { if (running) wakeAudio(); }, true);
  document.addEventListener("click", function () { if (running) wakeAudio(); }, true);

  function stop() {
    running = false;
    var s = ws; ws = null;
    try { if (s) s.close(1000); } catch (e) {}
    try { if (stream) stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
    try { if (ctx) ctx.close(); } catch (e) {}
    try { if (wakeLock) wakeLock.release(); } catch (e) {}
    try { if (outEl) { outEl.pause(); outEl.srcObject = null; } } catch (e) {}
    try { if (window.speechSynthesis) speechSynthesis.cancel(); } catch (e) {}
    capNode = null; micSrc = null; speakerMode = false;
    if (!$("updateNote").classList.contains("hidden")) setTimeout(function () { location.reload(); }, 300);
    ctx = null; master = null; stream = null; speakers = {}; members = {}; positions = {}; mcOn = false; mySlot = 0; optOut = false;
    inBuf = []; rpos = 0; fpos = 0; selfTalking = false; muted = false; deafened = false;
    showStart();
    $("call").classList.add("hidden");
  }
})();
</script>
</body>
</html>`;

export const WEB_HTML = WEB_HTML_RAW.replace("__APK_URL__", APK_URL);

export const MANIFEST = JSON.stringify({
  name: "むいいむ しゃべくら",
  short_name: "しゃべくら",
  start_url: "/",
  display: "standalone",
  background_color: "#F4F7F2",
  theme_color: "#2E5E2A",
  icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml" }],
});

export const ICON_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 108">
<rect width="108" height="108" rx="22" fill="#7EC8E3"/>
<path fill="#8B5A2B" d="M32,38h44v38h-44z"/>
<path fill="#5DAE3B" d="M32,38h44v12h-44z"/>
<path fill="#4A9130" d="M32,50h6v4h-6zM44,50h6v6h-6zM58,50h6v3h-6zM70,50h6v5h-6z"/>
<path fill="#FFFFFF" d="M56,24h26a6,6 0,0 1,6 6v12a6,6 0,0 1,-6 6h-14l-8,7v-7h-4a6,6 0,0 1,-6 -6v-12a6,6 0,0 1,6 -6z"/>
<path fill="#5DAE3B" d="M61,34h4v4h-4zM67,34h4v4h-4zM73,34h4v4h-4z"/>
</svg>`;
