import com.muiimu.shabekura.StreamFeed
fun main() {
    var fails = 0
    fun ok(c: Boolean, m: String) { if (!c) { fails++; println("FAIL: $m") } else println("OK   $m") }
    val feed = StreamFeed(); feed.start()
    val voice = ShabekuraVoice(); voice.start()
    var t = 0; while (!feed.hasClients && t < 50) { Thread.sleep(100); t++ }
    ok(feed.hasClients, "配信アプリがしゃべくらにつながる")
    Thread.sleep(300)
    ok(voice.connected, "あいさつの行を読んで、しゃべくらだと分かる")
    // 40msごとに 一定の音（左 1000・右 -2000）を 10回送る
    val frame = ShortArray(1280); for (i in 0 until 640) { frame[2*i] = 1000; frame[2*i+1] = -2000 }
    repeat(10) { feed.write(frame, frame.size); Thread.sleep(40) }
    Thread.sleep(200)
    val out = ShortArray(1920 * 5)  // 48kHz ステレオ 100ms
    voice.mixInto(out, out.size)
    val tail = out.copyOfRange(out.size - 200, out.size)
    ok(tail.all { it.toInt() == 1000 || it.toInt() == -2000 }, "48kHz に変えても音の大きさ・左右がそのまま届く")
    ok((0 until 100).all { out[out.size - 200 + 2*it].toInt() == 1000 && out[out.size - 200 + 2*it + 1].toInt() == -2000 }, "左右が入れかわらない")
    // ゲーム音に足す
    val game = ShortArray(1920) { 500 }
    repeat(3) { feed.write(frame, frame.size); Thread.sleep(40) }
    Thread.sleep(100)
    voice.mixInto(game, game.size)
    ok(game[game.size - 2].toInt() == 1500 && game[game.size - 1].toInt() == -1500, "ゲーム音に声を足せる: ${game[game.size-2]}, ${game[game.size-1]}")
    // 配信アプリが読まなくても、しゃべくら側は止まらない（ためすぎたら捨てる）
    val st = System.currentTimeMillis()
    repeat(2000) { feed.write(frame, frame.size) }
    ok(System.currentTimeMillis() - st < 2000, "配信アプリが遅くても、しゃべくらの音は止まらない")
    // しゃべくらを止めて、また始めたら、つながり直す
    feed.stop(); Thread.sleep(800)
    ok(!voice.connected, "しゃべくらが止まったら分かる")
    val feed2 = StreamFeed(); feed2.start()
    t = 0; while (!voice.connected && t < 40) { Thread.sleep(100); t++ }
    ok(voice.connected, "しゃべくらがまた始まったら、自動でつながり直す")
    voice.stop(); feed2.stop()
    println(if (fails == 0) "ALL OK" else "FAILED $fails")
    System.exit(0)
}
