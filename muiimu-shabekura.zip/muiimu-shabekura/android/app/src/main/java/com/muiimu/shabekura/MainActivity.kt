package com.muiimu.shabekura

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import kotlin.math.roundToInt

class MainActivity : Activity() {

    companion object {
        /** みんなが入る「近接VC待機所」（決まったコード） */
        const val LOBBY = "MUIIMU"
        const val APK_URL = "https://github.com/muiimu362-jpg/muiimu-shabekura-/releases/latest/download/MuiimuShabekura.apk"
        const val ROOMS = 20
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var etName: EditText
    private lateinit var etPass: EditText
    private lateinit var setupPanel: LinearLayout
    private lateinit var joinForm: LinearLayout
    private lateinit var tvBridgeToggle: TextView
    private var bridgeChoice = false
    private lateinit var callPanel: LinearLayout
    private lateinit var tvRoom: TextView
    private lateinit var tvMc: TextView
    private lateinit var llChannels: LinearLayout
    private lateinit var tvStatus: TextView
    private lateinit var btnCopyCmd: Button
    private lateinit var btnMute: Button
    private lateinit var btnDeafen: Button
    private lateinit var btnOptOut: Button

    private val listener: () -> Unit = { render() }
    private var pendingStart: (() -> Unit)? = null
    private var linkCode: String? = null   // 招待リンクで別の部屋コードが来たとき

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("shabekura", Context.MODE_PRIVATE)

        etName = findViewById(R.id.etName)
        etPass = findViewById(R.id.etPass)
        setupPanel = findViewById(R.id.setupPanel)
        joinForm = findViewById(R.id.joinForm)
        tvBridgeToggle = findViewById(R.id.tvBridgeToggle)
        callPanel = findViewById(R.id.callPanel)
        tvRoom = findViewById(R.id.tvRoom)
        tvMc = findViewById(R.id.tvMc)
        llChannels = findViewById(R.id.llChannels)
        tvStatus = findViewById(R.id.tvStatus)
        btnCopyCmd = findViewById(R.id.btnCopyCmd)
        btnMute = findViewById(R.id.btnMute)
        btnDeafen = findViewById(R.id.btnDeafen)
        btnOptOut = findViewById(R.id.btnOptOut)

        etName.setText(prefs.getString("name", ""))
        etPass.setText(prefs.getString("pass", ""))

        findViewById<TextView>(R.id.tvVersion).text = "バージョン " + BuildConfig.VERSION_NAME
        if (VoiceService.serverBase().isEmpty()) {
            findViewById<View>(R.id.serverWarn).visibility = View.VISIBLE
        }

        // 近接VC待機所をタップすると、名前とオーナーの入力欄が出る
        findViewById<TextView>(R.id.chLobby).setOnClickListener {
            joinForm.visibility = if (joinForm.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            if (joinForm.visibility == View.VISIBLE) etName.requestFocus()
        }
        // 配信用スイッチは、オーナーのパスワードが入っているときだけ出す
        val watcher = object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: android.text.Editable?) { updateOwnerUi() }
        }
        etPass.addTextChangedListener(watcher)
        tvBridgeToggle.setOnClickListener { bridgeChoice = !bridgeChoice; updateOwnerUi() }
        updateOwnerUi()
        buildRoomsPreview()

        findViewById<Button>(R.id.btnJoin).setOnClickListener {
            val pass = etPass.text.toString()
            if (pass.isNotEmpty()) host(pass, bridgeChoice) else join()
        }
        btnCopyCmd.setOnClickListener {
            copy(McBridge.COMMAND)
            Toast.makeText(this, "コピーしたよ！マイクラのチャットに貼り付けて送信してね", Toast.LENGTH_LONG).show()
        }
        // アプリをシェア（LINE や Discord などに送れる）
        findViewById<Button>(R.id.btnInvite).setOnClickListener {
            val base = VoiceService.serverBase()
            val text = "むいいむ通話に来てね！\n" +
                "アプリを開いて「近接VC待機所」をタップ → マイクラの名前を入れて「入る」だけ！\n" +
                "・ここを押すとアプリが開くよ（入ってない人はダウンロードされる）\n$base/\n" +
                "・アプリのダウンロード: $APK_URL"
            try {
                val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                startActivity(Intent.createChooser(send, "アプリをシェア"))
            } catch (e: Exception) {
                copy(text)
                Toast.makeText(this, "シェアできなかったので、招待メッセージをコピーしたよ", Toast.LENGTH_LONG).show()
            }
        }
        btnMute.setOnClickListener { VoiceService.instance?.setMuted(!AppState.muted) }
        btnDeafen.setOnClickListener { VoiceService.instance?.setDeafened(!AppState.deafened) }
        btnOptOut.setOnClickListener { VoiceService.instance?.setOptOut(!AppState.optOut) }

        findViewById<Button>(R.id.btnLeave).setOnClickListener { VoiceService.stop(this) }

        askPermissions()
        handleLink(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleLink(intent)
    }

    /** 招待リンク（shabekura://join?room=XXXXXX）から開かれたとき */
    private fun handleLink(i: Intent?) {
        val data = i?.data ?: return
        if (data.scheme != "shabekura") return
        val code = data.getQueryParameter("room")?.trim()?.uppercase().orEmpty()
        linkCode = if (Regex("^[A-Z0-9]{6}$").matches(code) && code != LOBBY) code else null
        if (AppState.running) return
        joinForm.visibility = View.VISIBLE
        toast("マイクラの名前を入れて「入る」を押してね")
    }

    override fun onResume() {
        super.onResume()
        AppState.addListener(listener)
        render()
    }

    override fun onPause() {
        AppState.removeListener(listener)
        super.onPause()
    }

    private fun askPermissions() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val start = pendingStart
        pendingStart = null
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            start?.invoke()
        } else if (start != null) {
            toast("マイクの許可がないと通話できないよ（設定 → アプリ → 権限）")
        }
    }

    /** マイクの許可を確認してから通話を始める */
    private fun withMic(action: () -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            action()
        } else {
            pendingStart = action
            askPermissions()
        }
    }

    private fun myName(): String? {
        val name = etName.text.toString().trim()
        if (name.isEmpty()) {
            joinForm.visibility = View.VISIBLE
            toast("マイクラの名前を教えてね"); return null
        }
        prefs.edit().putString("name", name).apply()
        return name
    }

    private fun join() {
        val name = myName() ?: return
        val code = linkCode ?: LOBBY
        withMic { VoiceService.start(this, code, name, null) }
    }

    /** オーナーとして入る（パスワードで待機所を開く） */
    private fun host(pass: String, bridgeOnly: Boolean) {
        val name = myName() ?: return
        val savedRoom = prefs.getString("hostRoom", "").orEmpty()
        val savedKey = prefs.getString("hostKey", "").orEmpty()
        val savedPass = prefs.getString("pass", "").orEmpty()
        if (savedRoom == LOBBY && savedKey.isNotEmpty() && savedPass == pass) {
            // 前に開いたときと同じパスワード → そのまま入る
            withMic { VoiceService.start(this, LOBBY, name, savedKey, bridgeOnly) }
            return
        }
        val base = VoiceService.serverBase()
        if (base.isEmpty()) {
            toast("サーバーのURLが入っていないよ"); return
        }
        toast("オーナーか確認してるよ…")
        Thread {
            try {
                val body = JSONObject().put("password", pass).put("code", LOBBY).toString()
                    .toRequestBody("application/json".toMediaType())
                val req = Request.Builder().url("$base/api/create").post(body).build()
                OkHttpClient().newCall(req).execute().use { res ->
                    val text = res.body?.string().orEmpty()
                    val j = try { JSONObject(text) } catch (_: Exception) { JSONObject() }
                    if (!res.isSuccessful) {
                        val err = if (res.code == 403) "オーナーのパスワードが違うよ（ふつうに入るなら、パスワードは空にしてね）"
                        else j.optString("error", "入れませんでした（${res.code}）")
                        runOnUiThread { toast(err) }
                        return@use
                    }
                    val key = j.getString("hostKey")
                    prefs.edit()
                        .putString("pass", pass)
                        .putString("hostRoom", LOBBY)
                        .putString("hostKey", key)
                        .apply()
                    runOnUiThread {
                        withMic { VoiceService.start(this, LOBBY, name, key, bridgeOnly) }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("サーバーにつながりません: ${e.message}") }
            }
        }.start()
    }

    private fun updateOwnerUi() {
        val owner = etPass.text.toString().isNotEmpty()
        tvBridgeToggle.visibility = if (owner) View.VISIBLE else View.GONE
        tvBridgeToggle.text = (if (bridgeChoice) "☑" else "☐") + " 配信用：このスマホは連携だけ（声は別のスマホ）"
        findViewById<Button>(R.id.btnJoin).text = if (owner) "オーナーとして入る" else "入る"
    }

    /** 入る前の画面に、部屋1〜20を並べておく（Discord と同じ見た目） */
    private fun buildRoomsPreview() {
        val box = findViewById<LinearLayout>(R.id.llRoomsPreview)
        box.removeAllViews()
        for (room in 1..ROOMS) {
            val t = TextView(this)
            t.text = "🔊  🎧▮部屋$room"
            t.textSize = 15f
            t.setPadding(dp(8), dp(7), dp(8), dp(7))
            t.setTextColor(Color.parseColor("#80848E"))
            box.addView(t)
        }
    }

    private fun render() {
        val s = AppState
        setupPanel.visibility = if (s.running) View.GONE else View.VISIBLE
        callPanel.visibility = if (s.running) View.VISIBLE else View.GONE
        tvStatus.text = s.status

        if (!s.running) return

        tvRoom.text = "むいいむ通話" + when {
            s.bridgeOnly -> "（連携だけ）"
            s.isHost -> "（オーナー）"
            else -> ""
        }
        btnCopyCmd.visibility = if (s.isHost) View.VISIBLE else View.GONE
        findViewById<Button>(R.id.btnInvite).visibility = if (s.isHost) View.VISIBLE else View.GONE

        var card = when {
            !s.mcLinked && s.isHost && s.bridgeOpen -> "🟡 マイクラとつながった。位置を取得中…"
            !s.mcLinked && s.isHost -> "⚪ 今は待機所でふつうの通話\n下のボタンでコマンドをコピー → マイクラのチャットに貼って送信すると、ワールドに入った人が部屋に移動するよ"
            !s.mcLinked -> "⚪ 近接VC待機所にいるよ（ふつうの通話）\n運営がマイクラで準備すると、ワールドに入った人から部屋に移動するよ"
            s.optOut -> "⏸ 通話を抜けてるよ（「通話に戻る」で戻れる）"
            s.mySlot > 0 -> "🟢 部屋${s.mySlot} にいるよ：近くの人ほど大きく聞こえる"
            else -> "🟡 近接VC待機所にいるよ：待機所の人どうしでふつうに話せる\nマイクラのワールドに入ると、空いてる部屋に自動で移動するよ"
        }
        if (s.bridgeOnly) {
            card = "🔗 連携だけモード：このスマホはマイクもスピーカーも使っていないよ（配信アプリがマイクを使える）\n" +
                "声は別のスマホで、近接VC待機所をタップ → 名前「${s.myName}」で「入る」してね\n\n" +
                when {
                    s.mcLinked -> "🟢 マイクラと連携中"
                    s.bridgeOpen -> "🟡 マイクラとつながった。位置を取得中…"
                    else -> "⚪ 下のボタンでコマンドをコピー → マイクラのチャットに貼って送信"
                }
        }
        if (s.isHost && s.bridgeInfo.isNotEmpty()) card += "\n\n" + s.bridgeInfo
        tvMc.text = card

        btnMute.text = if (s.muted) "🎤 ミュート解除" else "🎤 ミュート"
        btnDeafen.text = if (s.deafened) "🎧 スピーカー解除" else "🎧 スピーカーミュート"
        btnOptOut.visibility = if (s.mcLinked && !s.bridgeOnly) View.VISIBLE else View.GONE
        val voiceBtns = if (s.bridgeOnly) View.GONE else View.VISIBLE
        btnMute.visibility = voiceBtns
        btnDeafen.visibility = voiceBtns
        btnOptOut.text = if (s.optOut) "通話に戻る" else "通話を抜ける"

        renderChannels()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    /** Discord みたいなボイスチャンネル一覧（近接VC待機所 ＋ 部屋1〜20） */
    private fun renderChannels() {
        val s = AppState
        // 部屋ごとに人を分ける（0 = 近接VC待機所）
        val byRoom = HashMap<Int, MutableList<Member>>()
        for (m in s.members) {
            val room = if (s.mcLinked && m.slot in 1..ROOMS) m.slot else 0
            byRoom.getOrPut(room) { ArrayList() }.add(m)
        }
        val myRoom = s.members.firstOrNull { it.name == s.myName }?.let { if (s.mcLinked && it.slot in 1..ROOMS) it.slot else 0 }

        llChannels.removeAllViews()
        for (room in 0..ROOMS) {
            val title = if (room == 0) "🎤▮近接VC待機所" else "🎧▮部屋$room"
            val people = byRoom[room].orEmpty()
            val head = TextView(this)
            head.text = "🔊  $title" + if (room > 0 && people.isNotEmpty()) "   1/1" else ""
            head.textSize = 15f
            head.setPadding(dp(8), dp(7), dp(8), dp(7))
            val mine = room == myRoom
            head.setTextColor(if (mine || people.isNotEmpty()) Color.parseColor("#F2F3F5") else Color.parseColor("#80848E"))
            if (mine) head.setBackgroundResource(R.drawable.channel_selected)
            llChannels.addView(head)

            for (m in people) {
                val me = m.name == s.myName
                val talking = if (me) s.selfTalking else m.id in s.talking
                val row = TextView(this)
                val sb = StringBuilder()
                sb.append(if (talking) "🟢 " else "⚫ ")
                sb.append(m.name)
                if (m.host) sb.append(" 👑")
                if (me && s.bridgeOnly) {
                    sb.append("（声は別のスマホ）")
                } else if (me) {
                    sb.append("（自分）")
                    if (s.deafened) sb.append("  🎧✕") else if (s.muted) sb.append("  🎤✕")
                    else sb.append("  ").append("■".repeat(s.micLevel)).append("□".repeat(5 - s.micLevel))
                } else if (m.out) {
                    sb.append("  （抜けてる）")
                } else if (s.mcLinked && room > 0) {
                    val d = m.distance
                    sb.append(
                        when {
                            d == null -> ""
                            m.gain <= 0.01f -> "  ${d.roundToInt()}m・聞こえない"
                            else -> "  ${d.roundToInt()}m"
                        }
                    )
                }
                row.text = sb.toString()
                row.textSize = 14f
                row.setPadding(dp(40), dp(3), dp(8), dp(3))
                row.setTextColor(Color.parseColor(if (talking) "#23A55A" else "#DBDEE1"))
                if (talking) row.setTypeface(null, Typeface.BOLD)
                llChannels.addView(row)
            }
        }
    }

    private fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("shabekura", text))
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
