package com.muiimu.shabekura

import android.util.Log
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * 配信アプリに「通話の音（みんなの声＋自分の声）」をそのまま渡す口。
 * スマホの中だけ（127.0.0.1:19132）でつながる。音をスピーカーから流して拾い直さないので、反響（エコー）しない。
 *
 * 送る形: 最初に1行 "SHABEKURA PCM 16000 2 s16le\n"、そのあとはずっと
 *   16kHz・ステレオ・16bit（リトルエンディアン）の音。40msごと（2560バイト）に届く。
 */
class StreamFeed {
    companion object {
        const val PORT = 19132
        const val HEADER = "SHABEKURA PCM 16000 2 s16le\n"
        private const val TAG = "StreamFeed"
    }

    @Volatile private var running = false
    private var server: ServerSocket? = null
    private var acceptThread: Thread? = null
    private val clients = ArrayList<Client>()

    private class Client(val socket: Socket) {
        val queue = ArrayBlockingQueue<ByteArray>(25) // 1秒ぶんまでためる（遅い時は古いのを捨てる）
        @Volatile var alive = true
        val thread = Thread({
            try {
                val out: OutputStream = socket.getOutputStream()
                out.write(HEADER.toByteArray(Charsets.US_ASCII)); out.flush()
                while (alive) {
                    val b = queue.poll(500, TimeUnit.MILLISECONDS) ?: continue
                    out.write(b)
                }
            } catch (_: Exception) {
            } finally {
                alive = false
                try { socket.close() } catch (_: Exception) {}
            }
        }, "stream-feed-client")
    }

    val hasClients: Boolean get() = synchronized(clients) { clients.any { it.alive } }

    fun start() {
        if (running) return
        running = true
        try {
            val s = ServerSocket(PORT, 4, InetAddress.getByName("127.0.0.1"))
            s.reuseAddress = true
            server = s
            acceptThread = Thread({
                while (running) {
                    try {
                        val c = Client(s.accept())
                        c.socket.tcpNoDelay = true
                        synchronized(clients) { clients.removeAll { !it.alive }; clients.add(c) }
                        c.thread.start()
                    } catch (e: Exception) {
                        if (running) Log.w(TAG, "accept", e)
                    }
                }
            }, "stream-feed").also { it.start() }
        } catch (e: Exception) {
            Log.w(TAG, "start", e)
            running = false
        }
    }

    /** 40msぶんの音（ステレオ16bit）を配信アプリへ */
    fun write(stereo: ShortArray, count: Int) {
        if (!hasClients) return
        val bytes = ByteArray(count * 2)
        for (i in 0 until count) {
            val v = stereo[i].toInt()
            bytes[2 * i] = (v and 0xFF).toByte()
            bytes[2 * i + 1] = ((v shr 8) and 0xFF).toByte()
        }
        synchronized(clients) {
            for (c in clients) {
                if (!c.alive) continue
                if (!c.queue.offer(bytes)) { c.queue.poll(); c.queue.offer(bytes) }
            }
        }
    }

    fun stop() {
        running = false
        try { server?.close() } catch (_: Exception) {}
        server = null
        synchronized(clients) {
            for (c in clients) { c.alive = false; try { c.socket.close() } catch (_: Exception) {} }
            clients.clear()
        }
    }
}
