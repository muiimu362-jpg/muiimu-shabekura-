import com.muiimu.shabekura.*
import kotlin.random.Random
val MOVE = System.getenv("MOVE") == "1"
fun main() {
    var allOk = true; var total = 0
    for (sel in SelMode.values()) for (victim in VictimStyle.values()) for (delay in 0..3) {
        total++
        val rnd = Random(sel.ordinal * 100 + victim.ordinal * 10 + delay + 7)
        val cfg = Cfg(sel, victim, true, delay, 0.0, false, "yRot", false, 100)
        val host = P("gopura777", 0.0, 64.0, 0.0, 0, 0.0)
        val sw = P("Sarada Gamer12", 5.0, 64.0, 0.0, 0, 0.0)      // Switch: 空白入りのゲーマータグ
        val sw2 = P("Tomo_Switch", 9.0, 64.0, 0.0, 0, 0.0)         // マイクラの名前を入れずに、呼び名＝ゲーマータグ
        val mc = FakeMc(cfg, rnd, host); mc.players.addAll(listOf(host, sw, sw2))
        var id = 0; val logic = BridgeLogic { "r${id++}" }
        // 「saradagamer12」と空白なしで入力 / 呼び名「Tomo_Switch」 / ワールドにいない日本語の呼び名
        val members = listOf("gopura777", "saradagamer12", "Tomo_Switch", "むいいむの友達")
        var found = 0; var checks = 0; var wrong = 0
        for (tick in 1..100) {
            val now = tick * 200L
            if (MOVE) mc.move()
            for (c in logic.tick(now, members)) mc.receive(c, tick)
            for (r in mc.deliver(tick)) logic.onMessage(r, now)
            val snap = logic.snapshot(now, members, "gopura777")
            if (tick > 10) {
                checks += 3
                for ((m, p) in listOf("gopura777" to host, "saradagamer12" to sw, "Tomo_Switch" to sw2)) {
                    val s = snap[m] ?: continue
                    val all = listOf(host, sw, sw2)
                    val best = all.minByOrNull { (it.x - s.x) * (it.x - s.x) + (it.z - s.z) * (it.z - s.z) }
                    if (best === p) found++ else wrong++
                }
                if (snap["むいいむの友達"] != null) wrong++
            }
        }
        if (found != checks || wrong != 0) { allOk = false; println("NG $sel $victim delay=$delay found=$found/$checks wrong=$wrong") }
    }
    println(if (allOk) "Switch の人（空白入りの名前・呼び名だけ）: 全${total}パターン 100% 見つかった・間違い0" else "見つからないパターンあり")
}
