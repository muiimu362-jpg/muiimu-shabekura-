// むいいむ配信アプリ用: しゃべくらから「みんなの声＋自分の声」を直接もらうクラス
// スマホの中だけ（127.0.0.1:19132）でつながる。スピーカーの音を拾い直さないので反響しない。
//
// しゃべくら側: 通話画面の「📺 配信アプリに声を送る」をオン
//
// 使い方（いちばん簡単: 声だけ配信する）
//   val voice = ShabekuraVoice()
//   voice.start()
//   // 配信の音声エンコーダーが 48kHz・ステレオ・16bit の音をほしいとき:
//   val buf = ShortArray(1920)            // 20ms ぶん
//   java.util.Arrays.fill(buf, 0)
//   voice.mixInto(buf, buf.size)          // 声を足す（まだ届いてない分は無音のまま）
//   audioEncoder.feed(buf, buf.size)
//   ...
//   voice.stop()
//
// ゲーム音もいっしょに配信するとき:
//   InternalAudioCapture(projection, context, gameOnly = true) { pcm, n ->
//       voice.mixInto(pcm, n)              // ゲーム音にみんなの声＋自分の声を足す
//       audioEncoder.feed(pcm, n)
//   }
//   （gameOnly = true で、しゃべくらの音は内部音声から外す。声が2重にならない）

import java.io.DataInputStream
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket

class ShabekuraVoice(
    private val outRate: Int = 48000,
) {
    companion object {
        const val PORT = 19132
        private const val IN_RATE = 16000
    }

    @Volatile private var running = false
    private var thread: Thread? = null
    @Volatile private var socket: Socket? = null

    // 48kHz ステレオの音をためておく輪っか（2秒ぶん）
    private val ring = ShortArray(outRate * 2 * 2)
    private var wpos = 0L
    private var rpos = 0L
    private val lock = Object()

    /** しゃべくらとつながっているか */
    @Volatile var connected = false
        private set

    fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "shabekura-voice").also { it.start() }
    }

    fun stop() {
        running = false
        try { socket?.close() } catch (_: Exception) {}
        thread?.join(1000)
        thread = null
    }

    private fun loop() {
        while (running) {
            try {
                Socket().use { s ->
                    socket = s
                    s.connect(InetSocketAddress("127.0.0.1", PORT), 1000)
                    s.tcpNoDelay = true
                    val inp = DataInputStream(s.getInputStream())
                    val header = readLine(inp)
                    require(header.startsWith("SHABEKURA PCM 16000 2 s16le")) { "しゃべくらじゃない: $header" }
                    connected = true
                    synchronized(lock) { rpos = wpos } // つながったら今から
                    val frame = ByteArray(2560)      // 40ms・16kHz・ステレオ
                    var prevL = 0; var prevR = 0
                    while (running) {
                        inp.readFully(frame)
                        val n = frame.size / 4
                        val step = outRate / IN_RATE  // 48000/16000 = 3
                        synchronized(lock) {
                            for (i in 0 until n) {
                                val l = (frame[4 * i].toInt() and 0xFF) or (frame[4 * i + 1].toInt() shl 8)
                                val r = (frame[4 * i + 2].toInt() and 0xFF) or (frame[4 * i + 3].toInt() shl 8)
                                // 16kHz → 48kHz（あいだをなめらかにつなぐ）
                                for (k in 1..step) {
                                    val t = k.toFloat() / step
                                    put((prevL + (l - prevL) * t).toInt(), (prevR + (r - prevR) * t).toInt())
                                }
                                prevL = l; prevR = r
                            }
                            // ためすぎたら（配信側が読まないとき）古いのを捨てる
                            val max = ring.size / 2
                            if (wpos - rpos > max) rpos = wpos - max / 2
                        }
                    }
                }
            } catch (_: Exception) {
            }
            connected = false
            if (running) try { Thread.sleep(1000) } catch (_: InterruptedException) { break } // しゃべくらを待つ
        }
    }

    private fun put(l: Int, r: Int) {
        val i = ((wpos % (ring.size / 2)) * 2).toInt()
        ring[i] = l.toShort(); ring[i + 1] = r.toShort()
        wpos++
    }

    /**
     * pcm（48kHz・ステレオ・16bit、count は short の数）に、届いている声を足す。
     * 足りないぶんは何もしない（無音のまま）
     */
    fun mixInto(pcm: ShortArray, count: Int) {
        synchronized(lock) {
            val frames = count / 2
            val avail = (wpos - rpos).toInt()
            // 少したまってから流す（とぎれにくくする: 60ms）
            if (avail < outRate * 60 / 1000 && avail < frames) return
            val n = minOf(frames, avail)
            for (f in 0 until n) {
                val i = ((rpos % (ring.size / 2)) * 2).toInt()
                pcm[2 * f] = (pcm[2 * f] + ring[i]).coerceIn(-32768, 32767).toShort()
                pcm[2 * f + 1] = (pcm[2 * f + 1] + ring[i + 1]).coerceIn(-32768, 32767).toShort()
                rpos++
            }
        }
    }

    private fun readLine(inp: InputStream): String {
        val sb = StringBuilder()
        while (sb.length < 200) {
            val c = inp.read()
            if (c < 0 || c == '\n'.code) break
            sb.append(c.toChar())
        }
        return sb.toString()
    }
}
