import { Room } from "./idx.mjs";
class WS { constructor(){this.readyState=1;this.sent=[];this.att=null;} send(m){this.sent.push(m)} close(c){this.readyState=3;this.closed=c} serializeAttachment(a){this.att=a} deserializeAttachment(){return this.att} }
globalThis.WebSocketPair=function(){ return {0:new WS(),1:new WS()}; }; globalThis.Response=class{constructor(b,o){}};
let fails=0; const ok=(c,m)=>{ if(!c){fails++; console.log("FAIL:",m);} };
const store=new Map(); const sockets=[];
const r=new Room({getWebSockets:()=>sockets,acceptWebSocket:w=>sockets.push(w),storage:{get:async k=>store.get(k),put:async(k,v)=>store.set(k,v)}},{BUILD_ID:"v1"});
const join=async(n,dev,mc="")=>{ await r.fetch({url:`https://x/ws?room=MUIIMU&name=${encodeURIComponent(n)}&dev=${dev}&mc=${encodeURIComponent(mc)}`}); return sockets.at(-1); };
const members=(w)=>JSON.parse(w.sent.filter(x=>typeof x==="string"&&x.includes('"members"')).at(-1)).list;
const host=await join("むいいむ","A","gopura777");
const sw=await join("Tomo_Switch","B");          // Switch の人: マイクラの名前を入れず、呼び名＝ゲーマータグ
const ph=await join("見学","C");                  // ワールドにいない人
ok(members(host).find(m=>m.name==="Tomo_Switch").mc==="Tomo_Switch", "マイクラの名前が空なら呼び名で探す");
await r.webSocketMessage(host, JSON.stringify({t:"pos", p:{gopura777:{x:0,y:64,z:0,d:0,r:0}, Tomo_Switch:{x:3,y:64,z:0,d:0,r:0}}}));
const L=members(host);
ok(L.find(m=>m.name==="むいいむ").slot===1, "オーナーは部屋1");
ok(L.find(m=>m.name==="Tomo_Switch").slot===2, "Switch の人も部屋2に移動: "+JSON.stringify(L));
ok(!L.find(m=>m.name==="見学").slot, "ワールドにいない人は待機所のまま");
console.log(fails?"FAILED "+fails:"ALL OK");
